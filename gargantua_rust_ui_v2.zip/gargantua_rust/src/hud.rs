use crate::game::{GameState, ModuleStatus};
use crate::render::Framebuffer;

const CYAN: u32 = 0x45D9D2;
const CYAN_DIM: u32 = 0x1A7978;
const WHITE: u32 = 0xD7E5E5;
const MUTED: u32 = 0x779293;
const GREEN: u32 = 0x36D58A;
const AMBER: u32 = 0xF4B942;
const ORANGE: u32 = 0xF07836;
const RED: u32 = 0xF04455;
const PANEL: u32 = 0x06171B;
const GRID: u32 = 0x16454A;

pub fn draw_hud(frame: &mut Framebuffer, game: &GameState) {
    let w = frame.width as i32;
    let h = frame.height as i32;
    let margin = 12;

    // Panel 1: módulos, pequeño y pegado al borde superior derecho.
    draw_module_panel(frame, game, w - 264 - margin, margin, 264, 122);

    // Panel 2: telemetría en la esquina inferior derecha.
    draw_telemetry_panel(frame, game, w - 292 - margin, h - 130 - margin, 292, 130);

    // Panel 3: secuencia de maniobra abajo, centrada, sin invadir el campo central.
    draw_maneuver_panel(frame, game, (w - 370) / 2, h - 88 - margin, 370, 88);

    // Instrumento de gravedad a la izquierda, separado del resto del HUD.
    draw_gravity_gauge(frame, game, 142, (h * 62 / 100).clamp(300, h - 150));

    // El diagnóstico avanzado solo ocupa la franja superior central al pulsar TAB.
    if game.show_diagnostics {
        draw_diagnostics(frame, game, 302, margin, 430, 82);
    }

    if game.notice_seconds > 0.0 {
        let notice_w = (game.notice.len() as i32 * 8 + 22).min((w - 24).max(80));
        let nx = margin;
        let ny = h - 28 - margin;
        frame.alpha_rect(nx, ny, notice_w, 22, 0x071A20, 0.92);
        frame.rect(nx, ny, notice_w, 22, if game.lost { RED } else { CYAN_DIM });
        frame.text(nx + 9, ny + 7, &game.notice, if game.lost { RED } else { CYAN }, 1);
    }

    if game.won || game.lost {
        let title = if game.won { "ESCAPE SUCCESSFUL" } else { "MISSION FAILED" };
        let color = if game.won { GREEN } else { RED };
        let w = title.len() as i32 * 16 + 36;
        let x = (frame.width as i32 - w) / 2;
        let yy = frame.height as i32 / 2 - 28;
        frame.alpha_rect(x, yy, w, 58, 0x061318, 0.95);
        frame.rect(x, yy, w, 58, color);
        frame.text(x + 18, yy + 14, title, color, 2);
        frame.text(x + 18, yy + 38, "PRESS R TO RESTART", WHITE, 1);
    }
}

fn draw_module_panel(frame: &mut Framebuffer, game: &GameState, x: i32, y: i32, w: i32, h: i32) {
    panel(frame, x, y, w, h);
    frame.text(x + 9, y + 7, "MODULE STATUS // SYS", CYAN, 1);
    let online = if game.lost { "FAIL" } else if game.won { "ESCAPE" } else { "ONLINE" };
    let status_color = if game.lost { RED } else if game.won { GREEN } else { GREEN };
    frame.text(x + w - online.len() as i32 * 8 - 9, y + 7, online, status_color, 1);
    frame.line(x + 7, y + 21, x + w - 7, y + 21, GRID);

    for (i, module) in game.modules.iter().enumerate() {
        let row_y = y + 27 + i as i32 * 29;
        let (state, state_color) = match module.status {
            ModuleStatus::Attached if i == 2 => ("ACTIVE", GREEN),
            ModuleStatus::Attached => ("ATTACHED", CYAN),
            ModuleStatus::Detaching => ("DETACHING", AMBER),
            ModuleStatus::Detached => ("RELEASED", MUTED),
        };
        let label = match i { 0 => "01 LANDER", 1 => "02 RANGER 2", _ => "03 ENDURANCE" };
        draw_schematic(frame, x + 10, row_y + 5, i, module.status == ModuleStatus::Detached);
        frame.text(x + 43, row_y, label, if module.status == ModuleStatus::Detached { MUTED } else { WHITE }, 1);
        frame.text(x + w - state.len() as i32 * 8 - 9, row_y, state, state_color, 1);
        let fuel = format!("FUEL {:02.0}%", module.fuel_percent);
        frame.text(x + 43, row_y + 12, &fuel, MUTED, 1);
        bar(frame, x + 125, row_y + 14, w - 137, 4, module.fuel_percent, if module.status == ModuleStatus::Detached { MUTED } else { CYAN });
        if i < 2 { frame.line(x + 8, row_y + 25, x + w - 8, row_y + 25, 0x102E32); }
    }
}

fn draw_telemetry_panel(frame: &mut Framebuffer, game: &GameState, x: i32, y: i32, w: i32, h: i32) {
    panel(frame, x, y, w, h);
    frame.text(x + 9, y + 7, "FLIGHT TELEMETRY", CYAN, 1);
    frame.text(x + w - 9 - game.stage_label().len() as i32 * 8, y + 7, &game.stage_label(), MUTED, 1);
    frame.line(x + 7, y + 21, x + w - 7, y + 21, GRID);

    let metrics = [
        ("VELOCITY", game.speed, 100.0, format!("{:05.1}", game.speed), CYAN),
        ("POWER", game.engine_power, 100.0, format!("{:05.1}", game.engine_power), CYAN),
        ("TOTAL FUEL", game.total_fuel_percent(), 100.0, format!("{:05.1}", game.total_fuel_percent()), CYAN),
        ("SHIP MASS", game.attached_mass(), 240.0, format!("{:05.1}T", game.attached_mass()), CYAN),
        ("GRAVITY", game.gravity_proximity, 100.0, format!("{:05.1}", game.gravity_proximity), risk_color(game.gravity_proximity)),
        ("ESCAPE", game.escape_progress, 100.0, format!("{:05.1}", game.escape_progress), CYAN),
    ];
    let col_w = (w - 24) / 2;
    for (i, (label, value, max, number, color)) in metrics.iter().enumerate() {
        let col = i % 2;
        let row = i / 2;
        let xx = x + 9 + col as i32 * (col_w + 6);
        let yy = y + 29 + row as i32 * 29;
        frame.text(xx, yy, label, MUTED, 1);
        frame.text(xx + col_w - number.len() as i32 * 8, yy, number, WHITE, 1);
        bar(frame, xx, yy + 12, col_w - 5, 4, *value / *max * 100.0, *color);
    }
}

fn draw_maneuver_panel(frame: &mut Framebuffer, game: &GameState, x: i32, y: i32, w: i32, h: i32) {
    panel(frame, x, y, w, h);
    frame.text(x + 9, y + 7, "SEPARATION SEQUENCE", CYAN, 1);
    let stage = game.stage_label();
    frame.text(x + w - stage.len() as i32 * 8 - 9, y + 7, &stage, MUTED, 1);
    frame.line(x + 7, y + 21, x + w - 7, y + 21, GRID);

    let labels = ["LANDER", "RANGER 2", "ENDURANCE"];
    let gap = 4;
    let cell_w = (w - 24 - gap * 2) / 3;
    for i in 0..3 {
        let xx = x + 9 + i as i32 * (cell_w + gap);
        let state = game.modules[i].status;
        let color = match state {
            ModuleStatus::Detached => MUTED,
            ModuleStatus::Detaching => AMBER,
            ModuleStatus::Attached if game.selected_module == i => CYAN,
            ModuleStatus::Attached => CYAN_DIM,
        };
        frame.alpha_rect(xx, y + 27, cell_w, 17, 0x0A2529, 0.84);
        frame.rect(xx, y + 27, cell_w, 17, color);
        frame.text(xx + 5, y + 32, labels[i], if game.selected_module == i { WHITE } else { MUTED }, 1);
    }
    let next = game.next_action();
    let next_color = if game.current_window() { GREEN } else { AMBER };
    frame.text(x + 9, y + 53, next, next_color, 1);
}

fn draw_gravity_gauge(frame: &mut Framebuffer, game: &GameState, cx: i32, cy: i32) {
    let radius = 50;
    let color = risk_color(game.gravity_proximity);
    let mut previous: Option<(i32, i32)> = None;
    for degree in 205..336 {
        let a = (degree as f32).to_radians();
        let p = (cx + (a.cos() * radius as f32) as i32, cy + (a.sin() * radius as f32) as i32);
        if let Some(prev) = previous { frame.line(prev.0, prev.1, p.0, p.1, 0x18373E); }
        previous = Some(p);
    }
    let needle_angle = (205.0 + game.gravity_proximity * 1.3).clamp(205.0, 335.0).to_radians();
    frame.line(cx, cy, cx + (needle_angle.cos() * 39.0) as i32, cy + (needle_angle.sin() * 39.0) as i32, color);
    frame.circle(cx, cy, 4, CYAN);
    frame.text(cx - 44, cy + 61, "GRAVITY FIELD", MUTED, 1);
    frame.text(cx - 15, cy + 74, &format!("{:03.0}%", game.gravity_proximity), color, 1);
}

fn draw_diagnostics(frame: &mut Framebuffer, game: &GameState, x: i32, y: i32, w: i32, h: i32) {
    panel(frame, x, y, w, h);
    frame.text(x + 9, y + 7, "FLIGHT DIAGNOSTICS // LIVE", CYAN, 1);
    frame.text(x + 9, y + 25, &format!("TRJ {:+05.1} DEG   ATT {:+05.1} DEG   HORIZON {:05.1}", game.trajectory_angle, game.orientation, game.distance_to_horizon), WHITE, 1);
    let status = game.separation_window_status();
    let color = if game.current_window() { GREEN } else if status.contains("MISSED") { RED } else { AMBER };
    frame.text(x + 9, y + 43, &status, color, 1);
    frame.text(x + 9, y + 60, "SPACE RELEASE  |  SHIFT BOOST  |  R RESTART", MUTED, 1);
}

fn panel(frame: &mut Framebuffer, x: i32, y: i32, w: i32, h: i32) {
    frame.alpha_rect(x, y, w, h, PANEL, 0.78);
    frame.rect(x, y, w, h, CYAN_DIM);
}

fn draw_schematic(frame: &mut Framebuffer, x: i32, y: i32, module: usize, released: bool) {
    let c = if released { 0x3B5557 } else { CYAN_DIM };
    match module {
        0 => {
            frame.line(x + 4, y + 1, x + 18, y + 1, c);
            frame.line(x + 4, y + 1, x + 11, y + 17, c);
            frame.line(x + 18, y + 1, x + 11, y + 17, c);
            frame.line(x + 7, y + 7, x + 15, y + 7, c);
            frame.circle(x + 11, y + 9, 2, c);
        }
        1 => {
            frame.rect(x + 2, y + 5, 23, 8, c);
            frame.line(x + 2, y + 5, x - 2, y + 1, c);
            frame.line(x + 25, y + 5, x + 29, y + 1, c);
            frame.line(x + 2, y + 13, x - 2, y + 17, c);
            frame.line(x + 25, y + 13, x + 29, y + 17, c);
        }
        _ => {
            frame.circle(x + 13, y + 9, 10, c);
            frame.circle(x + 13, y + 9, 5, c);
            frame.line(x + 13, y - 2, x + 13, y + 20, c);
            frame.line(x + 2, y + 9, x + 24, y + 9, c);
        }
    }
}

fn bar(frame: &mut Framebuffer, x: i32, y: i32, w: i32, h: i32, value: f32, color: u32) {
    frame.fill_rect(x, y, w, h, 0x153B3E);
    let filled = ((w as f32) * value.clamp(0.0, 100.0) / 100.0) as i32;
    frame.fill_rect(x, y, filled, h, color);
    // Segmentos discretos para conservar la estética de instrumental.
    let mut sx = x + 11;
    while sx < x + w {
        frame.fill_rect(sx, y, 1, h, 0x082126);
        sx += 12;
    }
}

fn risk_color(value: f32) -> u32 {
    if value < 35.0 { CYAN } else if value < 58.0 { AMBER } else if value < 78.0 { ORANGE } else { RED }
}
