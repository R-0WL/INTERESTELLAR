mod game;
mod hud;
mod model;
mod render;

use game::{GameState, ModuleStatus};
use glam::{Mat4, Quat, Vec3};
use minifb::{Key, KeyRepeat, UseGPU, Window, WindowOptions};
use model::Model;
use render::Framebuffer;
use std::collections::HashMap;
use std::time::Instant;

const WIDTH: usize = 1024;
const HEIGHT: usize = 576;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("GARGANTUA // CPU FRAMEBUFFER RENDERER");
    println!("Loading GLB assets...");

    let mut models = HashMap::<&'static str, Model>::new();
    models.insert("blackhole", Model::load("assets/blackhole.glb", "Gargantua", 8_500)?);
    models.insert("endurance", Model::load("assets/interstellar__endurance.glb", "Endurance", 6_000)?);
    models.insert("ranger", Model::load("assets/ranger_ship_of_interstellar_free.glb", "Ranger 2", 2_200)?);
    models.insert("lander", Model::load("assets/lander.glb", "Lander", 1_500)?);

    for model in models.values() {
        println!("  {}: {} triangles / {} textures", model.name, model.triangles.len(), model.textures.len());
    }

    let options = WindowOptions {
        use_gpu: UseGPU::Disabled,
        ..WindowOptions::default()
    };
    let mut window = Window::new(
        "GARGANTUA // ORBITAL ESCAPE",
        WIDTH,
        HEIGHT,
        options,
    )?;
    window.set_target_fps(60);

    let mut frame = Framebuffer::new(WIDTH, HEIGHT);
    let mut game = GameState::new();
    let mut last_frame = Instant::now();

    while window.is_open() && !window.is_key_down(Key::Escape) {
        let now = Instant::now();
        let dt = now.duration_since(last_frame).as_secs_f32();
        last_frame = now;

        for key in window.get_keys_pressed(KeyRepeat::No) {
            game.handle_key(key);
        }
        let mut held = Vec::with_capacity(6);
        for key in [Key::W, Key::S, Key::A, Key::D, Key::Q, Key::E] {
            if window.is_key_down(key) { held.push(key); }
        }
        game.update(dt, &held);

        render_world(&mut frame, &models, &game);
        hud::draw_hud(&mut frame, &game);
        draw_help(&mut frame);

        window.update_with_buffer(&frame.color, WIDTH, HEIGHT)?;
    }
    Ok(())
}

fn render_world(frame: &mut Framebuffer, models: &HashMap<&'static str, Model>, game: &GameState) {
    frame.clear(0x02050B);
    draw_starfield(frame);

    let camera_position = Vec3::new(0.0, 8.0, 112.0);
    let camera_target = Vec3::new(0.0, 0.0, -18.0);
    let view = Mat4::look_at_rh(camera_position, camera_target, Vec3::Y);
    let projection = Mat4::perspective_rh(52.0_f32.to_radians(), WIDTH as f32 / HEIGHT as f32, 0.1, 500.0);
    let view_projection = projection * view;

    if let Some(blackhole) = models.get("blackhole") {
        // Perfil de Gargantúa: el GLB ya orienta el disco en su plano orbital.
        // Evitamos la rotación extra que lo mostraba de frente y desplazamos
        // el conjunto a la izquierda para abrir espacio visual a Endurance.
        let transform = Mat4::from_scale_rotation_translation(
            Vec3::splat(21.0),
            Quat::IDENTITY,
            Vec3::new(-38.0, 0.0, -28.0),
        );
        frame.draw_model(blackhole, transform, view_projection);
    }

    // Composición en tercios: Endurance ocupa la zona derecha del plano,
    // Gargantúa permanece a la izquierda. El offset es solo de cámara/arte.
    let ship_position = game.ship_position + Vec3::new(22.0, 0.0, 0.0);

    // El casco principal conserva su modelo; los módulos siguen siendo objetos independientes.
    for module in &game.modules {
        let world_position = match module.status {
            ModuleStatus::Attached | ModuleStatus::Detaching => ship_position + module.attached_offset,
            ModuleStatus::Detached => module.detached_position + Vec3::new(22.0, 0.0, 0.0),
        };
        let rotation = match module.model_key {
            "endurance" => Quat::from_rotation_y(std::f32::consts::FRAC_PI_2)
                * Quat::from_rotation_z(game.orientation.to_radians() * 0.18),
            "ranger" => Quat::from_rotation_y(0.35) * Quat::from_rotation_z(-0.12),
            _ => Quat::from_rotation_y(-0.35),
        };
        let scale = Vec3::splat(module.scale);
        let transform = Mat4::from_scale_rotation_translation(scale, rotation, world_position);
        if let Some(model) = models.get(module.model_key) {
            frame.draw_model(model, transform, view_projection);
        }
    }

}

fn draw_starfield(frame: &mut Framebuffer) {
    // Patrón determinista: no hace falta RNG ni memoria adicional por frame.
    for i in 0..210usize {
        let x = ((i * 197 + 73) % WIDTH) as i32;
        let y = ((i * 113 + i * i * 7 + 29) % HEIGHT) as i32;
        let brightness = 95 + ((i * 31) % 130) as u32;
        let color = (brightness << 16) | ((brightness / 3) << 8) | (brightness / 2);
        frame.pixel(x, y, color);
        if i % 29 == 0 { frame.pixel(x + 1, y, 0x668A9A); }
    }
}

fn draw_help(frame: &mut Framebuffer) {
    let x = 12;
    let y = 12;
    let w = 280;
    let h = 82;
    frame.alpha_rect(x, y, w, h, 0x06171C, 0.78);
    frame.rect(x, y, w, h, 0x16454A);
    frame.text(x + 10, y + 8, "GARGANTUA // FLIGHT DIRECTOR", 0x45D9D2, 1);
    frame.text(x + 10, y + 26, "W/S POWER     A/D TRAJECTORY", 0xA8C2C2, 1);
    frame.text(x + 10, y + 39, "Q/E ATTITUDE  SPACE RELEASE", 0xA8C2C2, 1);
    frame.text(x + 10, y + 52, "SHIFT BOOST   1-3 MODULE", 0xA8C2C2, 1);
    frame.text(x + 10, y + 65, "TAB DIAGNOSTICS   R RESTART", 0x45D9D2, 1);
}
