# UI / framing update

## Changes in this iteration

- Reframed Gargantua in profile: removed the additional 90-degree rotation, lowered the camera to a near-plane view, and moved the black hole left.
- Shifted Endurance and its attached/released modules into the right side of the composition.
- Replaced the large lower-right HUD block with compact, independent instruments:
  - flight controls: upper-left;
  - module status and fuel: upper-right;
  - gravity gauge: left side;
  - flight telemetry: lower-right;
  - separation sequence: lower-center;
  - advanced diagnostics: upper-center, visible with `TAB`.
- Added `R` to reset the complete flight state, including after mission success or failure.
- Added a unit test for the restart key.

## Deferred

Visual detachment transitions remain intentionally deferred to the final implementation stage. The existing module states and individual release logic are unchanged.

## Validation note

This package was reviewed statically and the ZIP archive was integrity-checked. It could not be compiled in the build environment because Rust/Cargo are not installed there. Run `cargo +stable test` and `cargo +stable run --release` on the target PC.
