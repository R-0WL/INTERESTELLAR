# Escala y Gargantúa — v6

## Escala de los cuerpos

`PLANET_SCALE` pasa de `4.0` a `15.0` respecto de los radios base. Se aplica a los ocho planetas, el Sol, Gargantúa y el agujero de gusano. La nave no cambia de tamaño.

La escala orbital pasa de `1 UA = 8,000` a `1 UA = 30,000` unidades. Esto mantiene las proporciones aproximadas entre semiejes orbitales y conserva holguras grandes entre planetas. El spawn inicial se desplazó al corredor entre Tierra y Venus para evitar aparecer dentro de alguno de los dos cuerpos ampliados.

La órbita de la Luna se amplió a 6,500 unidades para que no intersecte la Tierra ampliada.

## Agujero de gusano junto a Saturno

El agujero de gusano mantiene su posición relativa a Saturno, ahora con desplazamiento `(18,000, 3,900, 0)`. Este punto queda fuera del límite exterior de los anillos de Saturno, incluso con la nueva escala.

## Gargantúa

Gargantúa tiene radio `185 * 15 = 2,775` unidades y ahora se representa con `blackhole.obj`, convertido del GLB homónimo adjunto. El objeto importado reemplaza la esfera procedural y aporta la geometría del agujero negro y sus capas de acreción.

Las órbitas de los planetas del segundo sistema quedan muy alejadas del centro:

| Planeta | Radio orbital |
|---|---:|
| Miller | 85,000 |
| Mann | 155,000 |
| Edmund | 235,000 |

La salida del agujero de gusano está a 275,000 unidades del centro, fuera de la órbita de Edmund. La entrada al sistema permite acercarse desde el planeta exterior hacia Gargantúa. Los periodos de esos tres cuerpos mantienen una relación tipo Kepler entre sus radios orbitales.

El archivo `blackhole.obj` se genera a partir de `blackhole.glb` mediante `tools/convert_glb_assets.py`; el ejecutable usa el OBJ ya preparado y no necesita dependencias Python para cargarlo.

## Renderizado y visibilidad

Se amplió el plano lejano de la proyección a 1,500,000 unidades, las estrellas de fondo se sitúan a 1,300,000 y se actualizaron los límites de renderizado de cuerpos y asteroides para que Neptuno y el sistema exterior no desaparezcan por distancia.

## Pruebas añadidas/actualizadas

- Escala visual 15x para Tierra, Sol, agujero de gusano y Gargantúa.
- Separación nave-planetas en el punto de inicio.
- Separación de los cuerpos de Gargantúa respecto del volumen central.
- Salida del agujero de gusano fuera de la órbita exterior.
- Offset fijo del agujero de gusano respecto a Saturno.
