# Actualización visual de modelos y velocidad

## Modelos sustituidos

- **Trayecto del Sistema Solar:** la nave usa `endurance + ranger + ranger.glb`.
- **Después del agujero de gusano:** la nave cambia a `ranger_ship_of_interstellar_free.glb`.
- **Gargantúa:** se usa `blackhole.glb` en lugar de la esfera procedural.
- **Acoplamiento de Endurance:** el aro procedural se sustituye por `endurance + ranger.glb`.
- **Cinturón de asteroides:** 900 instancias del modelo `Asteroid.glb`, con tamaños y proporciones independientes. Hay fragmentos pequeños, medianos y algunos grandes; se eliminaron las dos guías circulares que delimitaban el cinturón.

Los GLB se convierten a OBJ compactos con `tools/convert_glb_assets.py`, porque el cargador del renderizador por software consume OBJ. El juego carga los OBJ ya incluidos y no necesita instalar bibliotecas Python para ejecutarse. Para regenerarlos se requieren `trimesh`, `numpy` y `scipy`.

## Anillos visibles

Se eliminaron los aros de la Tierra, el Sol, Urano y el agujero de gusano. Saturno conserva sus anillos y Gargantúa mantiene la geometría de acreción incluida en su modelo.

## Velocidad

- `W + Shift`: boost normal, máximo **1000 unidades/s**.
- `W + Shift + B`: superboost, máximo **2500 unidades/s**.
- `B` sin `Shift` no activa el superboost.

Los límites están aplicados tanto a la velocidad escalar como al vector de velocidad, y el HUD refleja el límite nuevo.
