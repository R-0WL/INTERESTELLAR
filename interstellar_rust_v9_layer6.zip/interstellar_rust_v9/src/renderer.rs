//! CPU triangle rasterizer.
//!
//! This module owns the complete rendering path:
//! model transform -> view transform -> perspective projection -> viewport
//! -> barycentric triangle fill -> depth test -> fragment/material function.
//! No GPU rendering API or scene-graph engine is used.

use crate::framebuffer::{color_from_f32, Framebuffer};
use crate::game::{Game, PlanetKind, SpaceBody, AU_SCALE, ASTEROID_BELT_INNER_AU, ASTEROID_BELT_OUTER_AU, GARGANTUA_DISK_RADIUS};
use crate::math::{cross, distance, dot, length, normalize, smoothstep, vec3, Mat4, Vec3};
use crate::mesh::Mesh;
use image::GenericImageView;
use std::collections::HashMap;
use std::path::{Path, PathBuf};

#[derive(Clone, Copy, PartialEq, Eq)]
enum ShaderKind {
    Solid,
    Mercury,
    Venus,
    Earth,
    Moon,
    Mars,
    Jupiter,
    Saturn,
    Uranus,
    Neptune,
    Miller,
    Mann,
    Edmund,
    Sun,
    Ring,
    Wormhole,
    AccretionDisc,
    Rock,
    Atmosphere,
    Clouds,
    Corona,
}

#[derive(Clone, Copy)]
struct Material {
    base_color: Vec3,
    shader: ShaderKind,
    emissive: f32,
    specular: f32,
    alpha: f32,
    texture: Option<TextureKind>,
    detailed: bool,
    normal_strength: f32,
    displacement: f32,
}

impl Material {
    fn new(color: Vec3, shader: ShaderKind) -> Self {
        Self {
            base_color: color, shader, emissive: 0.0, specular: 0.18, alpha: 1.0,
            texture: None, detailed: false, normal_strength: 0.0, displacement: 0.0,
        }
    }

    fn emissive(mut self, amount: f32) -> Self {
        self.emissive = amount;
        self
    }

    fn specular(mut self, amount: f32) -> Self {
        self.specular = amount;
        self
    }

    fn alpha(mut self, amount: f32) -> Self {
        self.alpha = amount.clamp(0.0, 1.0);
        self
    }

    fn texture(mut self, texture: TextureKind) -> Self {
        self.texture = Some(texture);
        self
    }

    fn detailed(mut self, enabled: bool) -> Self {
        self.detailed = enabled;
        self
    }

    fn normal_strength(mut self, amount: f32) -> Self {
        self.normal_strength = amount.max(0.0);
        self
    }

    fn displacement(mut self, amount: f32) -> Self {
        self.displacement = amount.max(0.0);
        self
    }
}

#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
enum TextureKind {
    Sun, Mercury, Venus, Earth, Moon, Mars, Jupiter, Saturn, Uranus, Neptune,
    Miller, Mann, Edmund, Wormhole,
}

impl TextureKind {
    fn filename(self) -> &'static str {
        match self {
            Self::Sun => "Sun.jpg", Self::Mercury => "mercury.jpg", Self::Venus => "venus.jpg",
            Self::Earth => "Earth.jpg", Self::Moon => "Moon.jpg", Self::Mars => "mars.jpg",
            Self::Jupiter => "jupiter.jpg", Self::Saturn => "saturn.jpg", Self::Uranus => "uranus.jpg",
            Self::Neptune => "neptune.jpg", Self::Miller => "miller.jpg", Self::Mann => "mann.jpg",
            Self::Edmund => "edmund.jpg", Self::Wormhole => "wormhole.jpeg",
        }
    }
}

struct Texture {
    width: usize,
    height: usize,
    pixels: Vec<[u8; 3]>,
}

impl Texture {
    fn load(path: &Path) -> Result<Self, String> {
        let image = image::open(path)
            .map_err(|error| format!("{}: {error}", path.display()))?
            .to_rgb8();
        let (width, height) = image.dimensions();
        let pixels = image.as_raw().chunks_exact(3)
            .map(|pixel| [pixel[0], pixel[1], pixel[2]])
            .collect();
        Ok(Self { width: width as usize, height: height as usize, pixels })
    }

    #[inline]
    fn sample(&self, u: f32, v: f32) -> Vec3 {
        if self.width == 0 || self.height == 0 || self.pixels.is_empty() {
            return vec3(1.0, 1.0, 1.0);
        }
        let x = u.rem_euclid(1.0) * (self.width.saturating_sub(1)) as f32;
        let y = v.clamp(0.0, 1.0) * (self.height.saturating_sub(1)) as f32;
        let x0 = x.floor() as usize;
        let y0 = y.floor() as usize;
        let x1 = (x0 + 1).min(self.width - 1);
        let y1 = (y0 + 1).min(self.height - 1);
        let tx = x - x0 as f32;
        let ty = y - y0 as f32;
        let a = self.pixels[y0 * self.width + x0];
        let b = self.pixels[y0 * self.width + x1];
        let c = self.pixels[y1 * self.width + x0];
        let d = self.pixels[y1 * self.width + x1];
        let channel = |index: usize| {
            let top = a[index] as f32 + (b[index] as f32 - a[index] as f32) * tx;
            let bottom = c[index] as f32 + (d[index] as f32 - c[index] as f32) * tx;
            (top + (bottom - top) * ty) / 255.0
        };
        vec3(channel(0), channel(1), channel(2))
    }
}

#[derive(Clone, Copy)]
struct Nebula {
    direction: Vec3,
    color: Vec3,
    radius: i32,
    seed: f32,
    galaxy: bool,
}

#[derive(Clone, Copy)]
struct ScreenVertex {
    x: f32,
    y: f32,
    z: f32,
    inv_w: f32,
    world_over_w: Vec3,
    normal_over_w: Vec3,
    uv_over_w: [f32; 2],
}

#[derive(Clone, Copy)]
struct Star {
    direction: Vec3,
    color: u32,
    radius: i32,
}

/// Imported scene objects prepared from the supplied GLB assets.
#[derive(Default)]
pub struct ImportedModels {
    pub solar_ship: Option<Mesh>,
    pub wormhole_ship: Option<Mesh>,
    pub gargantua: Option<Mesh>,
    pub endurance: Option<Mesh>,
    pub asteroid: Option<Mesh>,
}

pub struct Renderer {
    width: usize,
    height: usize,
    sphere: Mesh,
    detail_sphere: Mesh,
    textures: HashMap<TextureKind, Texture>,
    nebulae: Vec<Nebula>,
    solar_ship: Mesh,
    wormhole_ship: Mesh,
    gargantua_model: Option<Mesh>,
    endurance_model: Option<Mesh>,
    asteroid_model: Mesh,
    cube: Mesh,
    rock: Mesh,
    torus: Mesh,
    ring: Mesh,
    stars: Vec<Star>,
    asteroids: Vec<(Vec3, Vec3, f32)>,
}

impl Renderer {
    pub fn new(width: usize, height: usize, imported_sphere: Option<Mesh>, models: ImportedModels) -> Self {
        let sphere = imported_sphere.unwrap_or_else(|| Mesh::uv_sphere(32, 56));
        // Layer 6 has a dedicated dense sphere. Its vertices are displaced by
        // deterministic multi-octave noise immediately before projection.
        let detail_sphere = Mesh::uv_sphere(112, 224);
        let stars = make_stars(4200);
        let nebulae = make_nebulae();
        let asteroids = make_asteroids();
        let mut textures = HashMap::new();
        for kind in [
            TextureKind::Sun, TextureKind::Mercury, TextureKind::Venus, TextureKind::Earth,
            TextureKind::Moon, TextureKind::Mars, TextureKind::Jupiter, TextureKind::Saturn,
            TextureKind::Uranus, TextureKind::Neptune, TextureKind::Miller, TextureKind::Mann,
            TextureKind::Edmund, TextureKind::Wormhole,
        ] {
            let path = PathBuf::from("assets/textures").join(kind.filename());
            match Texture::load(&path) {
                Ok(texture) => { textures.insert(kind, texture); }
                Err(error) => eprintln!("Aviso: no se pudo cargar la textura {}", error),
            }
        }
        Self {
            width,
            height,
            sphere,
            detail_sphere,
            textures,
            nebulae,
            solar_ship: models.solar_ship.unwrap_or_else(Mesh::spaceship),
            wormhole_ship: models.wormhole_ship.unwrap_or_else(Mesh::spaceship),
            gargantua_model: models.gargantua,
            endurance_model: models.endurance,
            asteroid_model: models.asteroid.unwrap_or_else(Mesh::octahedron),
            cube: Mesh::cube(),
            rock: Mesh::octahedron(),
            torus: Mesh::torus(1.0, 0.12, 64, 10),
            ring: Mesh::ring(1.0, 2.5, 96),
            stars,
            asteroids,
        }
    }

    pub fn render(&self, framebuffer: &mut Framebuffer, game: &Game) {
        self.render_with_layer(framebuffer, game, 6);
    }

    /// Layer 6 enables image textures, height-derived normal mapping,
    /// transparent cloud/atmosphere shells and displaced high-density spheres.
    pub fn render_with_layer(&self, framebuffer: &mut Framebuffer, game: &Game, shader_layer: u8) {
        let layer6 = shader_layer.clamp(1, 6) == 6;
        framebuffer.clear_vertical_gradient(0x02040B, 0x080D1A);
        let (eye, target) = game.camera();
        let view = Mat4::look_at(eye, target, game.camera_up());
        let projection = Mat4::perspective(
            62.0_f32.to_radians(),
            self.width as f32 / self.height as f32,
            0.1,
            3_000_000.0,
        );
        let view_projection = projection * view;

        self.render_nebula_sky(framebuffer, eye, view_projection);
        self.render_stars(framebuffer, eye, view_projection);
        self.render_space_bodies(framebuffer, game, eye, view_projection, layer6);
        if !game.destroyed && !game.is_overview() {
            self.render_ship(framebuffer, game, eye, view_projection);
        }
        if !game.is_overview() {
            self.render_speed_effect(framebuffer, game);
        }
    }

    /// Screen-space radial streaks inspired by the supplied hyperspace reference.
    /// Regular Shift boost is intentionally faint; Shift+B produces the full warp tunnel.
    fn render_speed_effect(&self, fb: &mut Framebuffer, game: &Game) {
        if !game.boost_active {
            return;
        }

        let superboost = game.superboost_active;
        let ray_count = if superboost { 220 } else { 18 };
        let center_x = self.width as f32 * 0.5;
        let center_y = self.height as f32 * 0.5;
        let max_radius = (center_x * center_x + center_y * center_y).sqrt() * 1.08;
        let golden_angle = 2.399_963_1_f32;

        for index in 0..ray_count {
            let seed = index as f32 * 91.731 + 17.17;
            let random_a = (seed.sin() * 43_758.547).fract().abs();
            let random_b = ((seed + 31.416).sin() * 24_634.635).fract().abs();
            let angle = index as f32 * golden_angle
                + game.clock * if superboost { 0.055 } else { 0.018 }
                + (random_a - 0.5) * 0.22;
            let (sin_angle, cos_angle) = angle.sin_cos();

            // Leave a dark breathing space around the vanishing point, as in
            // the reference image, so the ship/reticle remain readable.
            let inner_radius = if superboost { 26.0 + random_a * 66.0 } else { 42.0 + random_a * 52.0 };
            let outer_radius = max_radius * if superboost {
                0.30 + random_b * 0.82
            } else {
                0.24 + random_b * 0.52
            };
            let start_x = center_x + cos_angle * inner_radius;
            let start_y = center_y + sin_angle * inner_radius;
            let end_x = center_x + cos_angle * outer_radius;
            let end_y = center_y + sin_angle * outer_radius;

            let color = if index % 7 == 0 {
                0x79BFFF
            } else if index % 5 == 0 {
                0xD9F0FF
            } else {
                0xFFFFFF
            };
            let alpha = if superboost {
                (82.0 + random_a * 135.0) as u8
            } else {
                (7.0 + random_a * 15.0) as u8
            };
            fb.draw_line_blended(
                start_x.round() as i32,
                start_y.round() as i32,
                end_x.round() as i32,
                end_y.round() as i32,
                color,
                alpha,
            );

            // A few streaks get a very thin luminous core, but avoid thick neon bars.
            if superboost && index % 9 == 0 {
                fb.draw_line_blended(
                    start_x.round() as i32 + 1,
                    start_y.round() as i32,
                    end_x.round() as i32 + 1,
                    end_y.round() as i32,
                    0xB8DCFF,
                    (alpha / 2).max(24),
                );
            }
        }
    }

    fn render_nebula_sky(&self, fb: &mut Framebuffer, eye: Vec3, vp: Mat4) {
        for nebula in &self.nebulae {
            let anchor = eye + nebula.direction * 1_250_000.0;
            let Some((cx, cy, _)) = project_point(anchor, vp, self.width, self.height) else { continue; };
            if nebula.galaxy {
                self.draw_spiral_galaxy(fb, cx, cy, nebula.radius, nebula.color, nebula.seed);
            } else {
                self.draw_nebula_cloud(fb, cx, cy, nebula.radius, nebula.color, nebula.seed);
            }
        }
    }

    fn draw_nebula_cloud(&self, fb: &mut Framebuffer, cx: i32, cy: i32, radius: i32, color: Vec3, seed: f32) {
        for oy in -radius..=radius {
            for ox in -radius..=radius {
                let nx = ox as f32 / radius.max(1) as f32;
                let ny = oy as f32 / radius.max(1) as f32;
                let r2 = nx * nx + ny * ny * 0.72;
                if r2 >= 1.0 { continue; }
                let turbulence = noise3(vec3(nx * 7.0 + seed, ny * 7.0, seed * 0.37));
                let filaments = (noise3(vec3(nx * 15.0, ny * 13.0, seed + 4.0)) * 0.65 + turbulence * 0.35).clamp(0.0, 1.0);
                let alpha = ((1.0 - r2).powf(1.7) * (0.035 + filaments * 0.095) * 255.0) as u8;
                if alpha > 0 {
                    let tint = color * (0.45 + filaments * 0.65);
                    fb.blend_pixel(cx + ox, cy + oy, color_from_f32(tint.x, tint.y, tint.z), alpha);
                }
            }
        }
    }

    fn draw_spiral_galaxy(&self, fb: &mut Framebuffer, cx: i32, cy: i32, radius: i32, color: Vec3, seed: f32) {
        for oy in -radius..=radius {
            for ox in -radius..=radius {
                let nx = ox as f32 / radius.max(1) as f32;
                let ny = oy as f32 / radius.max(1) as f32;
                let r = (nx * nx + ny * ny * 0.28).sqrt();
                if r >= 1.0 { continue; }
                let angle = ny.atan2(nx);
                let arm = (angle * 2.0 - r * 15.0 + seed).sin().abs();
                let core = (-r * 7.5).exp();
                let dust = noise3(vec3(nx * 12.0, ny * 12.0, seed));
                let alpha = ((core * 0.18 + (1.0 - r) * (1.0 - arm).powf(2.0) * 0.085)
                    * (0.55 + dust * 0.45) * 255.0) as u8;
                if alpha > 0 {
                    let tint = color * (0.45 + core * 1.4 + dust * 0.35);
                    fb.blend_pixel(cx + ox, cy + oy, color_from_f32(tint.x, tint.y, tint.z), alpha);
                }
            }
        }
    }

    fn render_stars(&self, framebuffer: &mut Framebuffer, eye: Vec3, view_projection: Mat4) {
        for star in &self.stars {
            // Place each star far from the camera along a fixed direction. This
            // keeps the background stable while avoiding an enormous world mesh.
            let position = eye + star.direction * 1_300_000.0;
            if let Some((x, y, depth)) = project_point(position, view_projection, self.width, self.height) {
                if star.radius <= 1 {
                    framebuffer.set_pixel_depth(x, y, depth, star.color);
                } else {
                    for oy in -star.radius..=star.radius {
                        for ox in -star.radius..=star.radius {
                            if ox * ox + oy * oy <= star.radius * star.radius {
                                framebuffer.set_pixel_depth(x + ox, y + oy, depth, star.color);
                            }
                        }
                    }
                }
            }
        }
    }

    fn render_space_bodies(&self, framebuffer: &mut Framebuffer, game: &Game, eye: Vec3, vp: Mat4, layer6: bool) {
        // Orbital paths are drawn first so planet meshes naturally cover the
        // parts of the lines that pass behind their surfaces in the Z-buffer.
        if !game.crossed_wormhole {
            self.render_solar_orbits(framebuffer, game, vp);
        } else {
            self.render_gargantua_orbits(framebuffer, game, vp);
        }

        let body_cull_distance = if game.is_overview() { 2_900_000.0 } else { 1_500_000.0 };
        for body in &game.bodies {
            if !game.body_is_visible(body) {
                continue;
            }
            if distance(body.position, eye) > body_cull_distance {
                continue;
            }
            self.render_body(framebuffer, body, game.clock, eye, vp, layer6);
        }

        if !game.crossed_wormhole {
            let belt_marker = game.bodies.iter().find(|body| body.kind == PlanetKind::AsteroidBelt);
            let sun = game.bodies.iter().find(|body| body.kind == PlanetKind::Sun);
            if let (Some(marker), Some(sun)) = (belt_marker, sun) {
                // Asteroids are distributed across the complete 360-degree belt.
                // The belt marker is retained only for navigation and visibility.
                let belt_cull_distance = if game.is_overview() { 2_900_000.0 } else { 400_000.0 };
                if distance(marker.position, eye) < belt_cull_distance {
                    self.render_asteroid_belt(framebuffer, sun.position, eye, vp, game.clock, belt_cull_distance, layer6);
                }
            }
        }
    }

    /// Draw circular orbital guides around the Sun. Planet radii use compressed
    /// AU units but preserve each planet's approximate semi-major-axis ratio.
    fn render_solar_orbits(&self, fb: &mut Framebuffer, game: &Game, vp: Mat4) {
        let Some(sun) = game.bodies.iter().find(|body| body.kind == PlanetKind::Sun) else {
            return;
        };

        for (kind, color) in [
            (PlanetKind::Mercury, 0x8B7A65),
            (PlanetKind::Venus, 0xB58B55),
            (PlanetKind::Earth, 0x285A78),
            (PlanetKind::Mars, 0x765344),
            (PlanetKind::Jupiter, 0x78634A),
            (PlanetKind::Saturn, 0x756C50),
            (PlanetKind::Uranus, 0x4F8790),
            (PlanetKind::Neptune, 0x3D5F9B),
        ] {
            if let Some(planet) = game.bodies.iter().find(|body| body.kind == kind) {
                let offset = planet.position - sun.position;
                let radius = (offset.x * offset.x + offset.z * offset.z).sqrt();
                let axis_u = normalize(vec3(offset.x, 0.0, offset.z));
                let mut axis_v = normalize(cross(vec3(0.0, 1.0, 0.0), axis_u));
                if length(axis_v) < 0.001 {
                    axis_v = normalize(cross(vec3(1.0, 0.0, 0.0), axis_u));
                }
                self.draw_orbit_line(fb, sun.position, axis_u, axis_v, radius, color, vp, 180);
            }
        }

        // The asteroid field is shown as individual rocks, without circular
        // guide lines that could make the belt look like a solid ring again.

        // Earth's Moon is the only moon currently represented as a world in
        // this journey, so its guide is centered on Earth rather than the Sun.
        if let (Some(earth), Some(moon)) = (
            game.bodies.iter().find(|body| body.kind == PlanetKind::Earth),
            game.bodies.iter().find(|body| body.kind == PlanetKind::Moon),
        ) {
            let offset = moon.position - earth.position;
            let radius = (offset.x * offset.x + offset.z * offset.z).sqrt();
            let axis_u = normalize(vec3(offset.x, 0.0, offset.z));
            let mut axis_v = normalize(cross(vec3(0.0, 1.0, 0.0), axis_u));
            if length(axis_v) < 0.001 {
                axis_v = normalize(cross(vec3(1.0, 0.0, 0.0), axis_u));
            }
            self.draw_orbit_line(fb, earth.position, axis_u, axis_v, radius, 0x697987, vp, 96);
        }
    }

    /// Draw the three known planets around Gargantua in the second-system view.
    fn render_gargantua_orbits(&self, fb: &mut Framebuffer, game: &Game, vp: Mat4) {
        let Some(center_body) = game.bodies.iter().find(|body| body.kind == PlanetKind::Gargantua) else {
            return;
        };
        for (kind, color) in [
            (PlanetKind::MillerWater, 0x28677C),
            (PlanetKind::MannIce, 0x71899A),
            (PlanetKind::EdmundHabitable, 0x526A4B),
        ] {
            if let Some(planet) = game.bodies.iter().find(|body| body.kind == kind) {
                let offset = planet.position - center_body.position;
                let radius = (offset.x * offset.x + offset.z * offset.z).sqrt();
                let axis_u = normalize(vec3(offset.x, 0.0, offset.z));
                let mut axis_v = normalize(cross(vec3(0.0, 1.0, 0.0), axis_u));
                if length(axis_v) < 0.001 {
                    axis_v = normalize(cross(vec3(1.0, 0.0, 0.0), axis_u));
                }
                self.draw_orbit_line(fb, center_body.position, axis_u, axis_v, radius, color, vp, 150);
            }
        }
    }

    fn draw_orbit_line(
        &self,
        fb: &mut Framebuffer,
        center: Vec3,
        axis_u: Vec3,
        axis_v: Vec3,
        radius: f32,
        color: u32,
        vp: Mat4,
        segments: usize,
    ) {
        if radius <= 1.0 || segments < 3 {
            return;
        }
        let mut previous: Option<(i32, i32, f32)> = None;
        for index in 0..=segments {
            let angle = index as f32 / segments as f32 * std::f32::consts::TAU;
            let point = center + axis_u * (radius * angle.cos()) + axis_v * (radius * angle.sin());
            let current = project_point(point, vp, self.width, self.height);
            if let (Some((x0, y0, _)), Some((x1, y1, _))) = (previous, current) {
                fb.draw_line(x0, y0, x1, y1, color);
            }
            previous = current;
        }
    }

    fn render_body(&self, fb: &mut Framebuffer, body: &SpaceBody, time: f32, eye: Vec3, vp: Mat4, layer6: bool) {
        let position = body.position;
        let radius = body.radius;
        let sphere = if layer6 { &self.detail_sphere } else { &self.sphere };
        match body.kind {
            PlanetKind::Earth => {
                let rotation = Mat4::rotation_y(time * 0.018);
                let model = Mat4::translation(position) * rotation * Mat4::scale(vec3(radius, radius, radius));
                let material = material_for(body.kind, layer6).displacement(if layer6 { 0.0025 } else { 0.0 });
                self.draw_mesh(fb, sphere, model, material, eye, vp, time);
                if layer6 {
                    let clouds = Mat4::translation(position) * Mat4::rotation_y(time * 0.024 + 0.7)
                        * Mat4::scale(vec3(radius * 1.009, radius * 1.009, radius * 1.009));
                    self.draw_mesh(fb, sphere, clouds, Material::new(vec3(0.76, 0.86, 0.96), ShaderKind::Clouds)
                        .alpha(0.34), eye, vp, time);
                    let atmosphere = Mat4::translation(position) * Mat4::scale(vec3(radius * 1.035, radius * 1.035, radius * 1.035));
                    self.draw_mesh(fb, sphere, atmosphere, Material::new(vec3(0.22, 0.54, 1.0), ShaderKind::Atmosphere)
                        .alpha(0.16).emissive(0.15), eye, vp, time);
                }
            }
            PlanetKind::Sun => {
                let model = Mat4::translation(position) * Mat4::scale(vec3(radius, radius, radius));
                let sun_material = Material::new(vec3(1.0, 0.68, 0.25), ShaderKind::Sun).emissive(1.8)
                    .texture(TextureKind::Sun).detailed(layer6).normal_strength(if layer6 { 1.8 } else { 0.0 });
                self.draw_mesh(fb, sphere, model, sun_material, eye, vp, time);
                if layer6 {
                    // The translucent shell is drawn after the photosphere so
                    // its prominences never depth-occlude the solar surface.
                    let corona = Mat4::translation(position) * Mat4::rotation_y(time * 0.03)
                        * Mat4::scale(vec3(radius * 1.075, radius * 1.075, radius * 1.075));
                    self.draw_mesh(fb, sphere, corona, Material::new(vec3(1.0, 0.35, 0.08), ShaderKind::Corona)
                        .alpha(0.28).emissive(0.65), eye, vp, time);
                }
            }
            PlanetKind::Mercury | PlanetKind::Venus | PlanetKind::Moon | PlanetKind::Mars |
            PlanetKind::Jupiter | PlanetKind::Uranus | PlanetKind::Neptune |
            PlanetKind::MillerWater | PlanetKind::MannIce | PlanetKind::EdmundHabitable => {
                let rotation = Mat4::rotation_y(time * if body.kind == PlanetKind::Jupiter { 0.035 } else { 0.012 });
                let model = Mat4::translation(position) * rotation * Mat4::scale(vec3(radius, radius, radius));
                let displacement = if !layer6 { 0.0 } else { match body.kind {
                    PlanetKind::Mercury | PlanetKind::Moon | PlanetKind::Mars | PlanetKind::MannIce => 0.014,
                    PlanetKind::MillerWater => 0.0015, PlanetKind::EdmundHabitable => 0.004,
                    _ => 0.001,
                }};
                self.draw_mesh(fb, sphere, model, material_for(body.kind, layer6).displacement(displacement), eye, vp, time);
                if layer6 && body.kind == PlanetKind::EdmundHabitable {
                    let clouds = Mat4::translation(position) * Mat4::rotation_y(time * 0.020 + 1.1)
                        * Mat4::scale(vec3(radius * 1.010, radius * 1.010, radius * 1.010));
                    self.draw_mesh(fb, sphere, clouds, Material::new(vec3(0.76, 0.86, 0.91), ShaderKind::Clouds)
                        .alpha(0.30), eye, vp, time);
                    let atmosphere = Mat4::translation(position)
                        * Mat4::scale(vec3(radius * 1.032, radius * 1.032, radius * 1.032));
                    self.draw_mesh(fb, sphere, atmosphere, Material::new(vec3(0.45, 0.75, 0.94), ShaderKind::Atmosphere)
                        .alpha(0.15).emissive(0.12), eye, vp, time);
                }
            }
            PlanetKind::Saturn => {
                let model = Mat4::translation(position)
                    * Mat4::rotation_y(time * 0.012)
                    * Mat4::scale(vec3(radius, radius, radius));
                self.draw_mesh(fb, sphere, model, material_for(body.kind, layer6), eye, vp, time);
                let rings = Mat4::translation(position)
                    * Mat4::rotation_x(1.13)
                    * Mat4::rotation_z(0.14)
                    * Mat4::scale(vec3(radius * 1.0, radius * 1.0, radius * 0.16));
                self.draw_mesh(fb, &self.ring, rings, Material::new(vec3(0.72, 0.61, 0.43), ShaderKind::Ring).specular(0.35), eye, vp, time);
            }
            PlanetKind::Wormhole => {
                // The anomaly is kept as one luminous spherical body; no outer rings.
                let model = Mat4::translation(position)
                    * Mat4::rotation_y(time * 0.08)
                    * Mat4::scale(vec3(radius, radius, radius));
                let wormhole_material = Material::new(vec3(0.12, 0.36, 0.62), ShaderKind::Wormhole)
                    .emissive(0.48).specular(1.35).texture(TextureKind::Wormhole).detailed(layer6)
                    .normal_strength(if layer6 { 1.5 } else { 0.0 });
                self.draw_mesh(fb, sphere, model, wormhole_material, eye, vp, time);
            }
            PlanetKind::Docking => {
                if let Some(endurance) = &self.endurance_model {
                    // This imported Endurance + Ranger model replaces the old docking torus.
                    let model = Mat4::translation(position)
                        * Mat4::rotation_y(time * 0.035 + std::f32::consts::FRAC_PI_2)
                        * Mat4::scale(vec3(radius * 1.4, radius * 1.4, radius * 1.4));
                    self.draw_mesh(fb, endurance, model,
                        Material::new(vec3(0.66, 0.70, 0.76), ShaderKind::Solid).specular(0.82),
                        eye, vp, time);
                } else {
                    let model = Mat4::translation(position) * Mat4::rotation_z(time * 0.08) * Mat4::scale(vec3(radius * 1.4, radius * 1.4, radius * 0.3));
                    self.draw_mesh(fb, &self.torus, model, Material::new(vec3(0.62, 0.72, 0.78), ShaderKind::Solid).specular(0.75), eye, vp, time);
                }
            }
            PlanetKind::Gargantua => {
                // The normalized OBJ's outer disk radius is 1.0. Set that edge
                // 1,600 world units inside Miller's orbit, making Gargantua
                // colossally large while keeping a narrow, intentional gap.
                // SpaceBody.radius tracks the matching 0.425 event-horizon ratio.
                let model_scale = GARGANTUA_DISK_RADIUS;
                let black_hole = Mat4::translation(position)
                    * Mat4::rotation_y(time * 0.006)
                    * Mat4::scale(vec3(model_scale, model_scale, model_scale));
                if let Some(model) = &self.gargantua_model {
                    // Use the supplied Gargantua GLB mesh instead of the procedural sphere.
                    self.draw_mesh(fb, model, black_hole,
                        Material::new(vec3(0.18, 0.13, 0.22), ShaderKind::Solid).specular(0.42),
                        eye, vp, time);
                } else {
                    self.draw_mesh(fb, &self.sphere, black_hole,
                        Material::new(vec3(0.004, 0.003, 0.008), ShaderKind::Solid), eye, vp, time);
                    let disk = Mat4::translation(position)
                        * Mat4::rotation_x(0.32)
                        * Mat4::rotation_z(time * 0.04)
                        * Mat4::scale(vec3(radius * 0.42, radius * 0.42, radius * 0.08));
                    self.draw_mesh(fb, &self.ring, disk,
                        Material::new(vec3(1.0, 0.47, 0.17), ShaderKind::AccretionDisc).emissive(0.85), eye, vp, time);
                    let outer = Mat4::translation(position)
                        * Mat4::rotation_x(0.32)
                        * Mat4::scale(vec3(radius * 0.62, radius * 0.62, radius * 0.05));
                    self.draw_mesh(fb, &self.ring, outer,
                        Material::new(vec3(0.35, 0.24, 0.62), ShaderKind::AccretionDisc).emissive(0.18), eye, vp, time);
                }
            }
            PlanetKind::AsteroidBelt => {}
        }
    }

    fn render_asteroid_belt(
        &self, fb: &mut Framebuffer, sun: Vec3, eye: Vec3, vp: Mat4, time: f32, max_distance: f32, layer6: bool,
    ) {
        // Each rock follows its own Keplerian speed: inner asteroids orbit
        // faster than outer ones instead of rotating as a rigid disc.
        for (offset, size, rotation) in &self.asteroids {
            let orbital_radius_au = (offset.x * offset.x + offset.z * offset.z).sqrt() / AU_SCALE;
            let orbital_period = 300.0 * orbital_radius_au.max(0.1).powf(1.5);
            let angle = time * (std::f32::consts::TAU / orbital_period);
            let (sin_angle, cos_angle) = angle.sin_cos();
            let rotated = vec3(
                offset.x * cos_angle + offset.z * sin_angle,
                offset.y,
                -offset.x * sin_angle + offset.z * cos_angle,
            );
            let position = sun + rotated;
            if distance(position, eye) > max_distance {
                continue;
            }
            let model = Mat4::translation(position)
                * Mat4::rotation_y(*rotation + time * 0.025)
                * Mat4::rotation_x(*rotation * 0.7 + time * 0.013)
                * Mat4::scale(*size);
            self.draw_mesh(fb, &self.asteroid_model, model,
                Material::new(vec3(0.37, 0.34, 0.31), ShaderKind::Rock).detailed(layer6), eye, vp, time);
        }
    }

    fn render_ship(&self, fb: &mut Framebuffer, game: &Game, eye: Vec3, vp: Mat4) {
        // These imported GLBs use different local axes. Endurance's ring lies
        // in the YZ plane, so it needs a quarter-turn to face the chase camera.
        // Ranger's aft engine is on its -Z end, so a half-turn brings that rear
        // face toward the camera. Only the mesh orientation changes; flight
        // direction, yaw, pitch, and thrust remain in the game's own basis.
        let (ship_mesh, ship_scale, local_yaw) = if game.crossed_wormhole {
            (&self.wormhole_ship, 4.8, std::f32::consts::PI)
        } else {
            (&self.solar_ship, 5.0, std::f32::consts::FRAC_PI_2)
        };
        let model = Mat4::translation(game.position)
            * Mat4::rotation_y(game.yaw)
            * Mat4::rotation_x(game.pitch)
            * Mat4::rotation_y(local_yaw)
            * Mat4::scale(vec3(ship_scale, ship_scale, ship_scale));
        self.draw_mesh(fb, ship_mesh, model,
            Material::new(vec3(0.72, 0.79, 0.83), ShaderKind::Solid).specular(0.82),
            eye, vp, game.clock);

        // Engine plumes stay restrained during normal boost; superboost gets
        // a longer and brighter exhaust to reinforce the stronger warp tunnel.
        let right = game.right();
        let up = game.up();
        let backward = -game.forward();
        let exhaust_length = if game.superboost_active {
            2.6
        } else if game.boost_active {
            0.68
        } else if game.speed > 180.0 {
            0.85
        } else {
            0.55
        };
        let exhaust_glow = if game.superboost_active { 1.35 } else if game.boost_active { 0.32 } else { 0.55 };
        for side in [-0.42, 0.42] {
            let center = game.position + right * side + backward * 3.15;
            let exhaust_model = Mat4::translation(center)
                * Mat4::rotation_y(game.yaw)
                * Mat4::rotation_x(game.pitch)
                * Mat4::scale(vec3(0.12, 0.12, exhaust_length));
            let _ = up; // Kept explicit to show the ship's local basis.
            self.draw_mesh(fb, &self.torus, exhaust_model, Material::new(vec3(0.20, 0.78, 1.0), ShaderKind::Wormhole).emissive(exhaust_glow), eye, vp, game.clock);
        }
    }

    /// Transform and rasterize a complete indexed triangle mesh.
    fn draw_mesh(
        &self,
        fb: &mut Framebuffer,
        mesh: &Mesh,
        model: Mat4,
        material: Material,
        eye: Vec3,
        vp: Mat4,
        time: f32,
    ) {
        if mesh.vertices.is_empty() || mesh.triangles.is_empty() {
            return;
        }
        let mvp = vp * model;
        let mut transformed: Vec<Option<ScreenVertex>> = Vec::with_capacity(mesh.vertices.len());
        for vertex in &mesh.vertices {
            let mut local_position = vertex.position;
            if material.displacement > 0.0 {
                let direction = normalize(local_position);
                let broad = noise3(direction * 5.2);
                let medium = noise3(direction * 13.7) * 0.38;
                let fine = noise3(direction * 31.0) * 0.16;
                let ridge = (broad * 0.72 + medium + fine - 0.62) * material.displacement;
                local_position = direction * (length(local_position) + ridge);
            }
            let world = model.transform_point(local_position);
            let normal = model.transform_direction(vertex.normal);
            let clip = mvp.transform_vec4([local_position.x, local_position.y, local_position.z, 1.0]);
            if clip[3] <= 0.1 || clip[3].is_nan() {
                transformed.push(None);
                continue;
            }
            let inv_w = 1.0 / clip[3];
            let ndc_x = clip[0] * inv_w;
            let ndc_y = clip[1] * inv_w;
            let ndc_z = clip[2] * inv_w;
            let screen_x = (ndc_x * 0.5 + 0.5) * self.width as f32;
            let screen_y = (0.5 - ndc_y * 0.5) * self.height as f32;
            transformed.push(Some(ScreenVertex {
                x: screen_x,
                y: screen_y,
                z: ndc_z,
                inv_w,
                world_over_w: world * inv_w,
                normal_over_w: normal * inv_w,
                uv_over_w: [vertex.uv[0] * inv_w, vertex.uv[1] * inv_w],
            }));
        }

        for triangle in &mesh.triangles {
            let Some(a) = transformed[triangle[0]] else { continue };
            let Some(b) = transformed[triangle[1]] else { continue };
            let Some(c) = transformed[triangle[2]] else { continue };
            self.rasterize_triangle(fb, a, b, c, material, eye, time);
        }
    }

    fn rasterize_triangle(
        &self,
        fb: &mut Framebuffer,
        a: ScreenVertex,
        b: ScreenVertex,
        c: ScreenVertex,
        material: Material,
        eye: Vec3,
        time: f32,
    ) {
        let area = edge(a.x, a.y, b.x, b.y, c.x, c.y);
        if area.abs() < 0.0001 {
            return;
        }

        let min_x = a.x.min(b.x).min(c.x).floor().max(0.0) as i32;
        let max_x = a.x.max(b.x).max(c.x).ceil().min((self.width - 1) as f32) as i32;
        let min_y = a.y.min(b.y).min(c.y).floor().max(0.0) as i32;
        let max_y = a.y.max(b.y).max(c.y).ceil().min((self.height - 1) as f32) as i32;
        if min_x > max_x || min_y > max_y {
            return;
        }

        for y in min_y..=max_y {
            for x in min_x..=max_x {
                let px = x as f32 + 0.5;
                let py = y as f32 + 0.5;
                let w0 = edge(b.x, b.y, c.x, c.y, px, py) / area;
                let w1 = edge(c.x, c.y, a.x, a.y, px, py) / area;
                let w2 = edge(a.x, a.y, b.x, b.y, px, py) / area;
                if w0 < -0.0001 || w1 < -0.0001 || w2 < -0.0001 {
                    continue;
                }

                let depth = w0 * a.z + w1 * b.z + w2 * c.z;
                if !(0.0..=1.0).contains(&depth) {
                    continue;
                }
                let reciprocal_w = w0 * a.inv_w + w1 * b.inv_w + w2 * c.inv_w;
                if reciprocal_w.abs() < 1.0e-8 {
                    continue;
                }
                let correction = 1.0 / reciprocal_w;
                let world_position = (a.world_over_w * w0 + b.world_over_w * w1 + c.world_over_w * w2) * correction;
                let normal = normalize((a.normal_over_w * w0 + b.normal_over_w * w1 + c.normal_over_w * w2) * correction);
                let uv = [
                    (a.uv_over_w[0] * w0 + b.uv_over_w[0] * w1 + c.uv_over_w[0] * w2) * correction,
                    (a.uv_over_w[1] * w0 + b.uv_over_w[1] * w1 + c.uv_over_w[1] * w2) * correction,
                ];
                let color = self.fragment(material, uv, world_position, normal, eye, time);
                let pixel_alpha = self.fragment_alpha(material, uv, normal, time);
                if pixel_alpha < 0.999 {
                    if pixel_alpha > 0.015 {
                        fb.blend_pixel_depth(x, y, depth, color, (pixel_alpha * 255.0) as u8);
                    }
                } else {
                    fb.set_pixel_depth(x, y, depth, color);
                }
            }
        }
    }

    /// CPU fragment shader: image material, procedural normal mapping and lighting.
    fn fragment(&self, material: Material, uv: [f32; 2], position: Vec3, normal: Vec3, eye: Vec3, time: f32) -> u32 {
        let geometric_normal = if length(normal) > 0.1 { normalize(normal) } else { vec3(0.0, 1.0, 0.0) };
        let n = self.map_normal(material, uv, geometric_normal, time);
        let albedo = self.sample_material(material, uv, n, position, time);
        let light_direction = normalize(vec3(-0.42, 0.72, 0.55));
        let diffuse = dot(n, light_direction).max(0.0);
        let view_direction = normalize(eye - position);
        let half_vector = normalize(light_direction + view_direction);
        let mut specular = dot(n, half_vector).max(0.0).powf(26.0) * material.specular;
        if material.shader == ShaderKind::Wormhole {
            let fresnel = (1.0 - dot(n, view_direction).abs()).clamp(0.0, 1.0).powf(3.2);
            specular += fresnel * 0.72;
        }
        let illumination = 0.22 + diffuse * 0.82;
        let color = match material.shader {
            ShaderKind::Atmosphere => {
                let rim = (1.0 - dot(n, view_direction).abs()).clamp(0.0, 1.0).powf(2.4);
                material.base_color * (0.12 + rim * 1.55)
            }
            ShaderKind::Clouds => albedo * (0.45 + diffuse * 0.55),
            ShaderKind::Corona => albedo * (0.42 + diffuse * 0.82 + material.emissive),
            _ => albedo * (illumination + material.emissive) + vec3(specular, specular, specular),
        };
        color_from_f32(color.x, color.y, color.z)
    }

    fn sample_material(&self, material: Material, uv: [f32; 2], normal: Vec3, position: Vec3, time: f32) -> Vec3 {
        let procedural = sample_material_procedural(material, uv, normal, position, time);
        if !material.detailed { return procedural; }
        if material.shader == ShaderKind::Atmosphere { return material.base_color; }
        if material.shader == ShaderKind::Clouds {
            let drift = noise3(normal * 23.0 + vec3(time * 0.035, 0.0, time * 0.012));
            let filaments = (noise3(normal * 47.0 + vec3(0.0, time * 0.025, 0.0)) * 0.72 + drift * 0.48);
            let density = ((filaments - 0.49) * 3.2).clamp(0.0, 1.0);
            return vec3(0.72, 0.82, 0.94) * (0.42 + density * 0.8);
        }
        let Some(kind) = material.texture else { return procedural; };
        let Some(texture) = self.textures.get(&kind) else { return procedural; };
        let texel = texture.sample(uv[0], uv[1]);
        match material.shader {
            ShaderKind::Miller => {
                let wave_a = (uv[1] * 128.0 + time * 0.10 + (uv[0] * 17.0).sin() * 2.2).sin();
                let wave_b = (uv[1] * 71.0 - time * 0.073 + (uv[0] * 9.0).cos()).sin();
                let crest = (wave_a * 0.55 + wave_b * 0.45).max(0.0);
                texel * 0.74 + procedural * 0.10 + vec3(0.08, 0.12, 0.16) * crest
            }
            ShaderKind::Mann => texel * 0.86 + procedural * 0.14 + vec3(0.015, 0.025, 0.045) * noise3(normal * 34.0),
            ShaderKind::Wormhole => {
                let swirl = noise3(normal * 12.0 + vec3(time * 0.04, time * 0.025, 0.0));
                let radial = ((uv[0] - 0.5).powi(2) + (uv[1] - 0.5).powi(2)).sqrt();
                let spiral = ((uv[0] - 0.5).atan2(uv[1] - 0.5) * 3.0 + radial * 38.0 + time * 0.22).sin().abs();
                let galaxy_core = (1.0 - radial * 2.1).clamp(0.0, 1.0);
                let nebula = vec3(0.12 + swirl.abs() * 0.18 + spiral * 0.08,
                    0.26 + swirl.abs() * 0.30 + spiral * 0.12,
                    0.52 + swirl.abs() * 0.36 + galaxy_core * 0.20);
                texel * 0.42 + nebula * 0.58
            }
            ShaderKind::Sun => {
                let pulse = 0.96 + 0.04 * (time * 1.6 + uv[1] * 8.0).sin();
                texel * pulse + vec3(0.07, 0.025, 0.004) * noise3(normal * 31.0 + vec3(time * 0.02, 0.0, 0.0))
            }
            ShaderKind::Earth | ShaderKind::Edmund => texel * 0.91 + procedural * 0.09,
            _ => texel * 0.90 + procedural * 0.10,
        }
    }

    fn fragment_alpha(&self, material: Material, uv: [f32; 2], normal: Vec3, time: f32) -> f32 {
        match material.shader {
            ShaderKind::Clouds => {
                let broad = noise3(normal * 15.0 + vec3(time * 0.018, 0.0, 0.0));
                let fine = noise3(normal * 41.0 + vec3(0.0, time * 0.027, 0.0));
                material.alpha * smoothstep(0.44, 0.68, broad * 0.58 + fine * 0.42)
            }
            ShaderKind::Corona => {
                let plasma = noise3(normal * 24.0 + vec3(time * 0.075, time * 0.035, 0.0));
                let arcs = (uv[0] * 38.0 + uv[1] * 8.0 + time * 0.16 + plasma * 5.0).sin().abs();
                material.alpha * smoothstep(0.30, 0.82, plasma * 0.72 + arcs * 0.28)
            }
            _ => material.alpha,
        }
    }

    /// Height differences from the diffuse map are converted to a tangent-space
    /// normal perturbation here, in the CPU fragment stage (no GPU dependency).
    fn map_normal(&self, material: Material, uv: [f32; 2], n: Vec3, time: f32) -> Vec3 {
        if !material.detailed || material.normal_strength <= 0.0 { return n; }
        let Some(kind) = material.texture else { return n; };
        let Some(texture) = self.textures.get(&kind) else { return n; };
        let du = 1.0 / texture.width.max(1) as f32;
        let dv = 1.0 / texture.height.max(1) as f32;
        let luminance = |u: f32, v: f32| {
            let color = texture.sample(u, v);
            color.x * 0.299 + color.y * 0.587 + color.z * 0.114
        };
        let mut dx = luminance(uv[0] + du, uv[1]) - luminance(uv[0] - du, uv[1]);
        let mut dy = luminance(uv[0], uv[1] + dv) - luminance(uv[0], uv[1] - dv);
        if material.shader == ShaderKind::Miller {
            let phase_a = uv[1] * 128.0 + uv[0].sin() * 7.0 + time * 0.11;
            let phase_b = uv[1] * 71.0 - uv[0].cos() * 4.0 - time * 0.075;
            dx += phase_a.cos() * 0.16 + phase_b.sin() * 0.08;
            dy += phase_a.sin() * 0.20 + phase_b.cos() * 0.10;
        }
        let mut tangent = normalize(cross(vec3(0.0, 1.0, 0.0), n));
        if length(tangent) < 0.01 { tangent = normalize(cross(vec3(1.0, 0.0, 0.0), n)); }
        let bitangent = normalize(cross(n, tangent));
        normalize(n - tangent * (dx * material.normal_strength) - bitangent * (dy * material.normal_strength))
    }
}

fn material_for(kind: PlanetKind, layer6: bool) -> Material {
    let mut material = match kind {
        PlanetKind::Mercury => Material::new(vec3(0.48, 0.46, 0.43), ShaderKind::Mercury),
        PlanetKind::Venus => Material::new(vec3(0.86, 0.64, 0.34), ShaderKind::Venus),
        PlanetKind::Earth => Material::new(vec3(0.22, 0.48, 0.78), ShaderKind::Earth).specular(0.38),
        PlanetKind::Moon => Material::new(vec3(0.55, 0.57, 0.58), ShaderKind::Moon),
        PlanetKind::Mars => Material::new(vec3(0.72, 0.29, 0.14), ShaderKind::Mars),
        PlanetKind::Jupiter => Material::new(vec3(0.72, 0.48, 0.31), ShaderKind::Jupiter),
        PlanetKind::Saturn => Material::new(vec3(0.77, 0.66, 0.45), ShaderKind::Saturn),
        PlanetKind::Uranus => Material::new(vec3(0.40, 0.74, 0.77), ShaderKind::Uranus).specular(0.3),
        PlanetKind::Neptune => Material::new(vec3(0.16, 0.29, 0.76), ShaderKind::Neptune).specular(0.42),
        PlanetKind::MillerWater => Material::new(vec3(0.05, 0.39, 0.67), ShaderKind::Miller).specular(0.75),
        PlanetKind::MannIce => Material::new(vec3(0.76, 0.84, 0.91), ShaderKind::Mann).specular(0.4),
        PlanetKind::EdmundHabitable => Material::new(vec3(0.28, 0.47, 0.27), ShaderKind::Edmund),
        _ => Material::new(vec3(0.6, 0.6, 0.6), ShaderKind::Solid),
    };
    if layer6 {
        let texture = match kind {
            PlanetKind::Mercury => Some(TextureKind::Mercury), PlanetKind::Venus => Some(TextureKind::Venus),
            PlanetKind::Earth => Some(TextureKind::Earth), PlanetKind::Moon => Some(TextureKind::Moon),
            PlanetKind::Mars => Some(TextureKind::Mars), PlanetKind::Jupiter => Some(TextureKind::Jupiter),
            PlanetKind::Saturn => Some(TextureKind::Saturn), PlanetKind::Uranus => Some(TextureKind::Uranus),
            PlanetKind::Neptune => Some(TextureKind::Neptune), PlanetKind::MillerWater => Some(TextureKind::Miller),
            PlanetKind::MannIce => Some(TextureKind::Mann), PlanetKind::EdmundHabitable => Some(TextureKind::Edmund),
            _ => None,
        };
        if let Some(texture) = texture {
            material = material.texture(texture).detailed(true).normal_strength(3.6);
        }
    }
    material
}

fn sample_material_procedural(material: Material, uv: [f32; 2], normal: Vec3, position: Vec3, time: f32) -> Vec3 {
    let u = uv[0];
    let v = uv[1];
    match material.shader {
        ShaderKind::Solid => material.base_color,
        ShaderKind::Mercury => {
            let crater = noise3(normal * 31.0) + noise3(normal * 12.0) * 0.35;
            let shade = 0.68 + crater * 0.42;
            vec3(0.43, 0.42, 0.40) * shade
        }
        ShaderKind::Venus => {
            let cloud = (v * 52.0 + (u * 13.0).sin() * 3.2 + time * 0.025).sin();
            let turbulence = noise3(normal * 18.0) * 0.12;
            vec3(0.78 + cloud * 0.08 + turbulence,
                 0.57 + cloud * 0.07 + turbulence,
                 0.30 + cloud * 0.035)
        }
        ShaderKind::Earth => {
            let continents = noise3(normal * 5.2) + 0.38 * noise3(normal * 12.0);
            if continents > 0.68 {
                vec3(0.19, 0.39 + normal.y.max(0.0) * 0.10, 0.20)
            } else {
                vec3(0.035, 0.19 + normal.y * 0.035, 0.48 + normal.y.max(0.0) * 0.13)
            }
        }
        ShaderKind::Moon => {
            let craters = noise3(normal * 27.0);
            let shade = 0.72 + craters * 0.5;
            vec3(0.48, 0.50, 0.51) * shade
        }
        ShaderKind::Mars => {
            let variation = noise3(normal * 18.0);
            vec3(0.52 + variation * 0.24, 0.19 + variation * 0.12, 0.085 + variation * 0.05)
        }
        ShaderKind::Jupiter => {
            let band = (v * 78.0 + (u * 9.0).sin() * 1.8).sin();
            let cloud = (band * 0.16 + noise3(normal * 15.0) * 0.10).clamp(-0.3, 0.3);
            let storm_distance = ((u - 0.72).powi(2) * 2.0 + (v - 0.56).powi(2) * 7.0).sqrt();
            if storm_distance < 0.09 {
                vec3(0.72, 0.20, 0.10)
            } else {
                vec3(0.69 + cloud, 0.43 + cloud * 0.8, 0.27 + cloud * 0.6)
            }
        }
        ShaderKind::Saturn => {
            let band = (v * 95.0 + (u * 7.0).sin()).sin() * 0.08;
            vec3(0.72 + band, 0.61 + band, 0.42 + band * 0.65)
        }
        ShaderKind::Uranus => {
            let band = (v * 25.0 + (u * 4.0).sin() * 0.3).sin() * 0.035;
            vec3(0.35 + band, 0.68 + band, 0.73 + band)
        }
        ShaderKind::Neptune => {
            let band = (v * 38.0 + (u * 8.0).sin() * 0.8).sin() * 0.07;
            let storm = ((u - 0.65).powi(2) * 2.0 + (v - 0.42).powi(2) * 5.0).sqrt();
            if storm < 0.10 { vec3(0.08, 0.15, 0.46) }
            else { vec3(0.10 + band, 0.24 + band, 0.67 + band) }
        }
        ShaderKind::Miller => {
            let wave = (v * 68.0 + time * 0.04 + (u * 8.0).sin()).sin();
            vec3(0.025, 0.25 + wave.abs() * 0.12, 0.47 + wave * 0.09)
        }
        ShaderKind::Mann => {
            let ice = noise3(normal * 21.0);
            let blue = (ice - 0.5).abs() * 0.16;
            vec3(0.70 + blue, 0.81 + blue, 0.91 + blue)
        }
        ShaderKind::Edmund => {
            let variation = noise3(normal * 13.0);
            if variation > 0.58 {
                vec3(0.38, 0.45, 0.22)
            } else {
                vec3(0.16, 0.36 + variation * 0.08, 0.19)
            }
        }
        ShaderKind::Sun => {
            let pulse = 0.92 + 0.08 * (time * 1.7 + v * 12.0).sin();
            vec3(1.0, 0.58 * pulse, 0.16 * pulse)
        }
        ShaderKind::Ring => {
            let stripe = (v * 90.0).sin() * 0.08;
            let radius_pattern = (u * 9.0).sin() * 0.04;
            vec3(0.73 + stripe, 0.63 + stripe + radius_pattern, 0.47 + stripe)
        }
        ShaderKind::Wormhole => {
            let pulse = 0.72 + 0.28 * (time * 2.4 + u * 18.0).sin().abs();
            vec3(0.20 * pulse, 0.68 * pulse, 1.0 * pulse)
        }
        ShaderKind::AccretionDisc => {
            let band = (v * 42.0 + time * 0.3 + u * 6.0).sin();
            let heat = (0.76 + band * 0.18).clamp(0.2, 1.0);
            vec3(1.0 * heat, 0.34 + 0.34 * heat, 0.10 + 0.18 * heat)
        }
        ShaderKind::Rock => {
            let variation = noise3(position * 0.055) + noise3(position * 0.17) * 0.28;
            material.base_color * (0.62 + variation * 0.72)
        }
        ShaderKind::Atmosphere => material.base_color,
        ShaderKind::Clouds => {
            let drift = noise3(normal * 23.0 + vec3(time * 0.035, 0.0, time * 0.012));
            vec3(0.72, 0.82, 0.94) * (0.35 + drift.clamp(0.0, 1.0) * 0.65)
        }
        ShaderKind::Corona => {
            let filament = noise3(normal * 31.0 + vec3(time * 0.08, time * 0.035, 0.0));
            let arcs = (uv[0] * 35.0 + noise3(normal * 12.0) * 4.0 + time * 0.18).sin().abs();
            let plasma = (filament * 0.72 + arcs * 0.28).clamp(0.0, 1.0);
            vec3(1.0, 0.28 + plasma * 0.36, 0.045 + plasma * 0.12)
        }

    }
}

fn edge(ax: f32, ay: f32, bx: f32, by: f32, px: f32, py: f32) -> f32 {
    (px - ax) * (by - ay) - (py - ay) * (bx - ax)
}

fn project_point(point: Vec3, vp: Mat4, width: usize, height: usize) -> Option<(i32, i32, f32)> {
    let clip = vp.transform_vec4([point.x, point.y, point.z, 1.0]);
    if clip[3] <= 0.1 {
        return None;
    }
    let inv_w = 1.0 / clip[3];
    let ndc_x = clip[0] * inv_w;
    let ndc_y = clip[1] * inv_w;
    let ndc_z = clip[2] * inv_w;
    if !(-1.2..=1.2).contains(&ndc_x) || !(-1.2..=1.2).contains(&ndc_y) {
        return None;
    }
    let x = ((ndc_x * 0.5 + 0.5) * width as f32) as i32;
    let y = ((0.5 - ndc_y * 0.5) * height as f32) as i32;
    Some((x, y, ndc_z))
}

fn make_stars(count: usize) -> Vec<Star> {
    let mut rng = SimpleRng::new(1901);
    let mut stars = Vec::with_capacity(count);
    for _ in 0..count {
        let z = rng.range(-1.0, 1.0);
        let angle = rng.range(0.0, std::f32::consts::TAU);
        let radial = (1.0 - z * z).max(0.0).sqrt();
        let direction = vec3(radial * angle.cos(), z, radial * angle.sin());
        let roll = rng.next();
        let color = if roll > 0.94 {
            0xBBDFFF
        } else if roll > 0.78 {
            0xFFE7C3
        } else {
            0xFFFFFF
        };
        stars.push(Star {
            direction,
            color,
            radius: if rng.next() > 0.985 { 2 } else { 1 },
        });
    }
    stars
}

fn make_nebulae() -> Vec<Nebula> {
    vec![
        Nebula { direction: normalize(vec3(-0.62, 0.24, -0.74)), color: vec3(0.24, 0.28, 0.92), radius: 145, seed: 2.1, galaxy: false },
        Nebula { direction: normalize(vec3(0.38, 0.48, -0.79)), color: vec3(0.72, 0.19, 0.54), radius: 125, seed: 5.7, galaxy: false },
        Nebula { direction: normalize(vec3(0.82, -0.19, -0.54)), color: vec3(0.12, 0.48, 0.68), radius: 110, seed: 8.4, galaxy: false },
        Nebula { direction: normalize(vec3(-0.18, -0.58, -0.79)), color: vec3(0.66, 0.31, 0.17), radius: 92, seed: 11.2, galaxy: false },
        Nebula { direction: normalize(vec3(-0.88, -0.12, 0.42)), color: vec3(0.20, 0.36, 0.82), radius: 80, seed: 14.8, galaxy: false },
        Nebula { direction: normalize(vec3(0.15, 0.82, 0.55)), color: vec3(0.42, 0.18, 0.72), radius: 118, seed: 18.0, galaxy: false },
        Nebula { direction: normalize(vec3(0.72, 0.18, 0.67)), color: vec3(0.82, 0.52, 0.24), radius: 56, seed: 4.3, galaxy: true },
        Nebula { direction: normalize(vec3(-0.32, 0.12, 0.94)), color: vec3(0.36, 0.68, 0.92), radius: 43, seed: 9.1, galaxy: true },
    ]
}

fn make_asteroids() -> Vec<(Vec3, Vec3, f32)> {
    let mut rng = SimpleRng::new(7331);
    let mut rocks = Vec::with_capacity(900);
    let inner = ASTEROID_BELT_INNER_AU * AU_SCALE;
    let outer = ASTEROID_BELT_OUTER_AU * AU_SCALE;
    let golden_angle = 2.399_963_1_f32;

    // Even angular spacing with a little deterministic jitter avoids the
    // accidental clumps and empty sectors of a small random sample.
    for index in 0..900 {
        let angle = index as f32 * golden_angle + rng.range(-0.045, 0.045);
        // Uniform density by annular area rather than by radius.
        let radius = (inner * inner + rng.next() * (outer * outer - inner * inner)).sqrt();
        let y = rng.range(-180.0, 180.0);
        let position = vec3(angle.cos() * radius, y, angle.sin() * radius);
        // Most rocks remain small, with a few medium and very large bodies
        // breaking up the silhouette of the belt.
        let size = if index % 83 == 0 {
            rng.range(68.0, 110.0)
        } else if index % 13 == 0 {
            rng.range(34.0, 58.0)
        } else {
            rng.range(8.0, 24.0)
        };
        let shape = vec3(
            size * rng.range(0.72, 1.28),
            size * rng.range(0.58, 1.08),
            size * rng.range(0.70, 1.35),
        );
        let rotation = rng.range(0.0, std::f32::consts::TAU);
        rocks.push((position, shape, rotation));
    }
    rocks
}

struct SimpleRng {
    state: u64,
}

impl SimpleRng {
    fn new(seed: u64) -> Self { Self { state: seed.max(1) } }

    fn next(&mut self) -> f32 {
        self.state ^= self.state << 13;
        self.state ^= self.state >> 7;
        self.state ^= self.state << 17;
        (self.state as u32) as f32 / u32::MAX as f32
    }

    fn range(&mut self, min: f32, max: f32) -> f32 {
        min + (max - min) * self.next()
    }
}

fn hash3(x: i32, y: i32, z: i32) -> f32 {
    let mut n = x.wrapping_mul(374761393)
        .wrapping_add(y.wrapping_mul(668265263))
        .wrapping_add(z.wrapping_mul(2147483647));
    n = (n ^ (n >> 13)).wrapping_mul(1274126177);
    let value = n ^ (n >> 16);
    (value as u32) as f32 / u32::MAX as f32
}

fn fade(value: f32) -> f32 { value * value * (3.0 - 2.0 * value) }

fn noise3(point: Vec3) -> f32 {
    let x0 = point.x.floor() as i32;
    let y0 = point.y.floor() as i32;
    let z0 = point.z.floor() as i32;
    let fx = fade(point.x - x0 as f32);
    let fy = fade(point.y - y0 as f32);
    let fz = fade(point.z - z0 as f32);

    let c000 = hash3(x0, y0, z0);
    let c100 = hash3(x0 + 1, y0, z0);
    let c010 = hash3(x0, y0 + 1, z0);
    let c110 = hash3(x0 + 1, y0 + 1, z0);
    let c001 = hash3(x0, y0, z0 + 1);
    let c101 = hash3(x0 + 1, y0, z0 + 1);
    let c011 = hash3(x0, y0 + 1, z0 + 1);
    let c111 = hash3(x0 + 1, y0 + 1, z0 + 1);

    let x00 = c000 + (c100 - c000) * fx;
    let x10 = c010 + (c110 - c010) * fx;
    let x01 = c001 + (c101 - c001) * fx;
    let x11 = c011 + (c111 - c011) * fx;
    let y0_value = x00 + (x10 - x00) * fy;
    let y1_value = x01 + (x11 - x01) * fy;
    y0_value + (y1_value - y0_value) * fz
}


#[cfg(test)]
mod asteroid_tests {
    use super::*;

    #[test]
    fn gargantua_disk_stops_1600_units_before_millers_orbit() {
        use crate::game::{GARGANTUA_DISK_ORBIT_GAP, GARGANTUA_DISK_RADIUS, GARGANTUA_MILLER_ORBIT};
        assert!((GARGANTUA_MILLER_ORBIT - GARGANTUA_DISK_RADIUS - GARGANTUA_DISK_ORBIT_GAP).abs() < 0.001);
    }

    #[test]
    fn inner_asteroids_have_shorter_periods_than_outer_asteroids() {
        let period = |radius_au: f32| 300.0 * radius_au.powf(1.5);
        assert!(period(ASTEROID_BELT_INNER_AU) < period(ASTEROID_BELT_OUTER_AU));
    }

    #[test]
    fn asteroid_field_covers_the_full_orbital_annulus() {
        let asteroids = make_asteroids();
        assert_eq!(asteroids.len(), 900);
        let inner = ASTEROID_BELT_INNER_AU * AU_SCALE;
        let outer = ASTEROID_BELT_OUTER_AU * AU_SCALE;
        let mut angular_bins = [0usize; 36];

        for (offset, _, _) in asteroids {
            let radius = (offset.x * offset.x + offset.z * offset.z).sqrt();
            assert!(radius >= inner && radius <= outer);
            let angle = offset.z.atan2(offset.x).rem_euclid(std::f32::consts::TAU);
            let bin = ((angle / std::f32::consts::TAU) * angular_bins.len() as f32) as usize;
            angular_bins[bin.min(angular_bins.len() - 1)] += 1;
        }

        // Every ten-degree sector must contain rocks; the belt cannot collapse
        // into the short visible arc from the previous implementation.
        assert!(angular_bins.iter().all(|count| *count >= 10));
    }
}
