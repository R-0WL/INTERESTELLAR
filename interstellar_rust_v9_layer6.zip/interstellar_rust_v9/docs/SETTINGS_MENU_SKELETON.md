# Esqueleto del menú de configuración

## Acceso

- Antes de iniciar: opción `CONFIGURACION` en el menú principal.
- Durante la exploración: botón de engranaje debajo del minimapa o tecla `G`.
- `Backspace` vuelve a la pantalla desde la que se abrió la configuración.

## Opciones almacenadas en la sesión

| Opción | Valores | Estado inicial |
|---|---|---|
| Música | Activada / desactivada | Activada |
| Diálogos visibles | Activados / desactivados | Activados |
| Efectos | Activados / desactivados | Activados |
| Renderización | Capas de shader 1 a 6 | Capa 6 — Ultra detalle |

La capa 6 es el perfil predeterminado de alto detalle. Las capas 1 a 5 conservan el sombreado procedural de base; la capa 6 activa texturas, normal mapping en CPU, esferas subdivididas, desplazamiento por ruido, nubes y atmósferas animadas, corona solar y cielo profundo procedural. Los controles de música, diálogos y efectos siguen siendo opciones independientes del renderizador.

## Controles

- `Up` / `Down`: seleccionar opción.
- `Left` / `Right`: cambiar el valor.
- `Enter`: alternar una opción o avanzar a la siguiente capa.
- `Backspace`: regresar.
