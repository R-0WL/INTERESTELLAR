# Capa 6 — Texturas y sombreado de alto detalle

La capa 6 es el preset de mayor calidad del renderizador por software. Se selecciona por defecto y también se puede forzar con `--shader-layer 6` o `--layer 6`. Gargantúa y las naves se han dejado sin cambios visuales intencionados.

## Integración

- **Mapas de color:** los JPEG/PNG suministrados se copian a `assets/textures/` y se cargan al iniciar. Se usan los mapas de Sol, Mercurio, Venus, Tierra, Luna, Marte, Júpiter, Saturno, Urano, Neptuno, Miller, Mann, Edmund y el agujero de gusano. El muestreo equirectangular tiene interpolación bilineal y repetición horizontal de UV.
- **Normal mapping en CPU:** el renderer estima un mapa de altura a partir de la luminancia del mapa de color, calcula diferencias en U/V y perturba la normal geométrica en una base tangente local antes de calcular la iluminación. No requiere GPU ni archivos de normales adicionales.
- **Geometría procedural:** la capa 6 usa una esfera UV dedicada de 112×224 segmentos (más de 25.000 vértices) y desplaza los vértices de superficies rocosas mediante ruido multi-octava antes de transformarlos y rasterizarlos.
- **Shaders animados:** las nubes de Tierra y Edmund derivan de ruido multicapa dependiente del tiempo; tienen su propia cáscara transparente. Miller combina su mapa oceánico con normales de onda animadas y bandas de cresta para que se perciban olas. Mann usa el mapa frío y variación de hielo/roca.
- **Sol:** su mapa de color se combina con una corona procedural animada de filamentos de plasma que sobresale del disco visible.
- **Agujero de gusano:** el mapa suministrado se mezcla con espirales y ruido de nebulosa que rotan en el tiempo; Fresnel y especular alto refuerzan el aspecto de esfera de cristal.
- **Cielo profundo:** el fondo combina 4.200 estrellas con cúmulos de nebulosa y pequeñas galaxias espirales ancladas a direcciones celestes para que el fondo permanezca estable al mover la cámara.
- **Cinturón de asteroides:** mantiene las rocas orbitales independientes y añade variación de grano/relieve procedural al shader de roca.

## Resolución real

No se ha interpolado artificialmente a 16K. Los mapas originales proporcionados alcanzan aproximadamente 3890×2160 (Tierra); varias superficies de Miller, Mann y Edmund tienen fuentes bastante menores. La ventana y las capturas siguen renderizándose a 1000×640. Escalar un mapa pequeño a 16K no crea detalle físico nuevo, y renderizar un framebuffer 16K con este rasterizador CPU requeriría una ampliación sustancial de memoria y tiempo de cómputo. Por eso esta entrega conserva los píxeles de origen disponibles y prioriza el detalle que sí puede aportar el renderizador: filtrado, relieve, subdivisión, desplazamiento y capas atmosféricas.

Resoluciones de los mapas integrados:

| Cuerpo | Resolución fuente |
|---|---:|
| Sol | 3840×2160 |
| Mercurio | 2048×1152 |
| Venus | 1280×727 |
| Tierra | 3890×2160 |
| Luna | 3840×2160 |
| Marte | 3840×2160 |
| Júpiter | 3840×2160 |
| Saturno | 1920×1075 |
| Urano | 2000×1333 |
| Neptuno | 3584×2048 |
| Miller | 516×387 |
| Mann | 480×640 |
| Edmund | 367×425 |
| Agujero de gusano | 500×333 |

Los cuatro mapas con contenedor original WebP/PNG y extensión `.jpg` se han normalizado a JPEG para que `image` los pueda decodificar de forma coherente; el mapa de Neptuno no tenía transparencia útil (canal alfa totalmente opaco).

## Ejecución

Desde la carpeta `interstellar_rust_v9/`:

```bash
cargo run --release -- --place earth --shader-layer 6
cargo run --release -- --place miller --shader-layer 6
cargo run --release -- --place mann --shader-layer 6
cargo run --release -- --place edmund --shader-layer 6
cargo run --release -- --place wormhole --shader-layer 6
cargo run --release -- --foto all --shader-layer 6
```

La carga de texturas utiliza la crate `image` con decodificación JPEG y PNG. Los mapas faltantes muestran el shader procedural de respaldo y dejan un aviso en consola.
