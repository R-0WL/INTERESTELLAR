# Sistema de superficies esféricas

## Capas de cada planeta

- La esfera exterior conserva el material procedural del planeta y funciona como su atmósfera/silueta a distancia.
- Al entrar con la cámara al radio exterior (`R`), esa capa deja de dibujarse. Se revela la esfera interior con radio `0.84 R`, dejando un margen radial de `0.16 R`.
- Los modelos se apoyan en la esfera interior y quedan dentro del margen de la capa exterior. La orientación local `+Y` de cada OBJ se alinea con la normal radial; por eso los modelos siguen la curvatura y la rotación del planeta. El mayor alcance radial de los prefabs, incluida su geometría local y su escala, se limita conservadoramente a `0.066 R`; junto con el levantamiento de `0.015 R`, el extremo queda por debajo de `0.921 R`, sin tocar la esfera exterior.
- Las instancias se crean una sola vez con una semilla fija (`SURFACE_SEED`). Una retícula de ángulo áureo cubre la esfera; dos octavas del ruido `noise3` modulan la probabilidad de aceptación, y otras muestras de ruido desplazan los puntos sobre sus planos tangentes y varían la escala. El jitter usa un generador determinista. Los mismos datos producen las mismas ubicaciones en cada ejecución.
- Solo se envía al rasterizador el hemisferio orientado hacia la cámara; el Z-buffer de la esfera interior oculta el lado opuesto.

## Modelos de superficie

Los modelos originales de bajo poligonaje se generan con `tools/generate_surface_models.py`: árbol de pino, roca, módulo de aterrizaje lunar, cristales, hábitat, arco rocoso, respiradero volcánico y monumento.

También se incluyen cuatro modelos derivados de la carpeta de recursos entregada: Apollo 14, Apollo 17, cráter Gale y sitio de aterrizaje de Curiosity. Se simplificaron por muestreo espacial determinista para que el renderizador CPU pueda dibujarlos como prefabs. Para repetir esa preparación:

```bash
python3 tools/prepare_supplied_surface_objs.py "/ruta/a/modelos de textura"
```

Todos los OBJ usados en ejecución están dentro de `assets/models/surface/`; el juego no requiere Python ni acceso a los archivos fuente originales.

## Recetas por planeta

| Planeta | Ambientación |
|---|---|
| Tierra | Pinos, rocas, hábitats y monumentos. Las instancias se filtran con la misma máscara de continentes que dibuja la tierra; el océano queda libre. |
| Luna | Rocas, módulo lunar, monumentos y sitios Apollo 14/17. |
| Mercurio | Rocas, respiraderos volcánicos y monolitos. |
| Venus | Rocas, respiraderos volcánicos y cristales cálidos. |
| Marte | Rocas, arcos, respiraderos, cráter Gale y sitio de Curiosity. |
| Miller | Sin modelos de tierra: la esfera completa usa el material procedural de agua. |
| Mann | Rocas heladas, cristales y hábitats cubiertos de hielo. |
| Edmund | Pinos, rocas, hábitats y cristales. |
| Júpiter, Saturno, Urano y Neptuno | Conservan sus bandas gaseosas; no reciben objetos de suelo. |

No se añadieron shaders nuevos ni dependencias de motor gráfico. El material sigue calculándose con el fragment shader CPU ya existente.

## Ajustes principales

- `INNER_SURFACE_RATIO = 0.84`: radio interior relativo a la esfera exterior.
- `SURFACE_SEED`: semilla reproducible de la distribución.
- `MAX_SURFACE_PROP_RADIAL_EXTENT = 0.066`: cota conservadora del alcance radial de los modelos a escala máxima.
- La rotación de los props usa la misma matriz de giro aplicada a la esfera interior.
- En la Tierra, el umbral procedural tierra/agua queda en `0.42` y la franja de costa en `0.385–0.42`; el valor anterior (`0.68`) no generaba suficiente superficie continental con el ruido actual.
