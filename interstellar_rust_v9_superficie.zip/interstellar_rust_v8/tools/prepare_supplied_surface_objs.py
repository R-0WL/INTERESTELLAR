#!/usr/bin/env python3
"""Reduce supplied high-density landing-site OBJs for the software renderer.

Usage: python3 tools/prepare_supplied_surface_objs.py /path/to/modelos-de-textura
The output meshes are centered in X/Z, sit on local Y=0 and are capped to a
few thousand faces using deterministic spatial sampling. Original sources are
kept outside the runtime project; the reduced OBJ files are self-contained.
"""
from __future__ import annotations
from pathlib import Path
import sys, math

if len(sys.argv) != 2:
    raise SystemExit('Uso: prepare_supplied_surface_objs.py <carpeta-modelos-de-textura>')
src = Path(sys.argv[1]); out = Path(__file__).resolve().parents[1] / 'assets/models/surface'
out.mkdir(parents=True, exist_ok=True)

SOURCES = [
    ('Apollo 14 - Landing Site.obj', 'apollo14_landing_site.obj', 44),
    ('Apollo 17 - Landing Site.obj', 'apollo17_landing_site.obj', 52),
    ('Crater Gale.obj', 'gale_crater_site.obj', 52),
    ('Curiosity Landing Site.obj', 'curiosity_rover_site.obj', 50),
]

def parse_obj(path: Path):
    vertices=[]; faces=[]
    with path.open('r',encoding='utf-8',errors='ignore') as f:
        for line in f:
            if line.startswith('v '):
                p=line.split()
                if len(p)>=4:
                    try: vertices.append(tuple(float(v) for v in p[1:4]))
                    except ValueError: pass
            elif line.startswith('f '):
                ids=[]
                for token in line.split()[1:]:
                    raw=token.split('/')[0]
                    try: idx=int(raw)
                    except ValueError: continue
                    idx=idx-1 if idx>0 else len(vertices)+idx
                    if 0<=idx<len(vertices): ids.append(idx)
                for i in range(1,len(ids)-1): faces.append((ids[0],ids[i],ids[i+1]))
    if not vertices or not faces: raise ValueError(f'OBJ vacío: {path}')
    return vertices,faces

def area(a,b,c):
    ab=[b[i]-a[i] for i in range(3)]; ac=[c[i]-a[i] for i in range(3)]
    cr=(ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0])
    return sum(x*x for x in cr)

for src_name,out_name,grid in SOURCES:
    vertices,faces=parse_obj(src/src_name)
    mins=[min(p[i] for p in vertices) for i in range(3)]
    maxs=[max(p[i] for p in vertices) for i in range(3)]
    horizontal=max(maxs[0]-mins[0],maxs[2]-mins[2],1e-6)
    cx=(mins[0]+maxs[0])*0.5; cz=(mins[2]+maxs[2])*0.5
    scale=2.0/horizontal
    normalized=[((p[0]-cx)*scale,(p[1]-mins[1])*scale,(p[2]-cz)*scale) for p in vertices]
    # One high-area representative per X/Z/height voxel preserves the outer
    # terrain relief while avoiding hundreds of thousands of CPU triangles.
    chosen={}
    yrange=max((maxs[1]-mins[1])*scale,1e-5)
    for face in faces:
        a,b,c=(normalized[i] for i in face)
        cxm=(a[0]+b[0]+c[0])/3; cym=(a[1]+b[1]+c[1])/3; czm=(a[2]+b[2]+c[2])/3
        gx=max(0,min(grid-1,int((cxm+1.0)*0.5*grid)))
        gz=max(0,min(grid-1,int((czm+1.0)*0.5*grid)))
        gy=max(0,min(3,int((cym/max(yrange,1e-6))*4)))
        key=(gx,gz,gy); score=area(a,b,c)
        if key not in chosen or score>chosen[key][0]: chosen[key]=(score,face)
    selected=[item[1] for _,item in sorted(chosen.items())]
    # Re-index only referenced vertices to keep the files compact.
    used=sorted({i for face in selected for i in face}); remap={old:new+1 for new,old in enumerate(used)}
    target=out/out_name
    with target.open('w',encoding='utf-8',newline='\n') as f:
        f.write(f'# Reduced from supplied asset: {src_name}\n# Vertices: {len(used)}, triangles: {len(selected)}\n')
        for old in used:
            x,y,z=normalized[old]; f.write(f'v {x:.6f} {y:.6f} {z:.6f}\n')
        for face in selected: f.write('f '+' '.join(str(remap[i]) for i in face)+'\n')
    print(f'{src_name} -> {out_name}: {len(used)} vertices, {len(selected)} triangles')
