#!/usr/bin/env python3
"""Generate original, low-poly OBJ props for spherical planetary surfaces."""
from __future__ import annotations
from pathlib import Path
import math
import random

OUT = Path(__file__).resolve().parents[1] / "assets" / "models" / "surface"

class Obj:
    def __init__(self):
        self.v: list[tuple[float,float,float]] = []
        self.f: list[tuple[int,...]] = []
    def vertex(self, p):
        self.v.append(tuple(float(x) for x in p)); return len(self.v)
    def face(self, *ids): self.f.append(tuple(ids))
    def box(self, cx, cy, cz, sx, sy, sz):
        x0,x1=cx-sx/2,cx+sx/2; y0,y1=cy-sy/2,cy+sy/2; z0,z1=cz-sz/2,cz+sz/2
        ids=[self.vertex(p) for p in [(x0,y0,z0),(x1,y0,z0),(x1,y0,z1),(x0,y0,z1),(x0,y1,z0),(x1,y1,z0),(x1,y1,z1),(x0,y1,z1)]]
        for q in [(0,1,2),(0,2,3),(4,7,6),(4,6,5),(0,4,5),(0,5,1),(1,5,6),(1,6,2),(2,6,7),(2,7,3),(3,7,4),(3,4,0)]: self.face(*(ids[i] for i in q))
    def cylinder(self, cx, y0, cz, r0, r1, h, sides=10, cap=True):
        bottom=[]; top=[]
        for i in range(sides):
            a=2*math.pi*i/sides
            bottom.append(self.vertex((cx+r0*math.cos(a),y0,cz+r0*math.sin(a))))
            top.append(self.vertex((cx+r1*math.cos(a),y0+h,cz+r1*math.sin(a))))
        for i in range(sides):
            j=(i+1)%sides; self.face(bottom[i],top[i],top[j],bottom[j])
        if cap:
            self.face(*bottom); self.face(*reversed(top))
    def dome(self, cx, base, cz, radius, height, sides=12, rings=5):
        prev=[]
        for ri in range(rings+1):
            a=(ri/rings)*math.pi/2
            rr=radius*math.cos(a); yy=base+height*math.sin(a)
            curr=[]
            for i in range(sides):
                t=2*math.pi*i/sides
                curr.append(self.vertex((cx+rr*math.cos(t),yy,cz+rr*math.sin(t))))
            if prev:
                for i in range(sides):
                    j=(i+1)%sides; self.face(prev[i],curr[i],curr[j],prev[j])
            prev=curr
        self.face(*reversed(prev))
    def cone(self, cx, y0, cz, radius, height, sides=7, top_radius=0.0):
        lo=[]; hi=[]
        for i in range(sides):
            a=2*math.pi*i/sides
            lo.append(self.vertex((cx+radius*math.cos(a),y0,cz+radius*math.sin(a))))
            hi.append(self.vertex((cx+top_radius*math.cos(a),y0+height,cz+top_radius*math.sin(a))))
        for i in range(sides):
            j=(i+1)%sides; self.face(lo[i],hi[i],hi[j],lo[j])
        self.face(*lo)
        if top_radius>0: self.face(*reversed(hi))
    def prism(self,cx,y0,cz,radius,height,sides=5): self.cone(cx,y0,cz,radius,height,sides,0.025*radius)
    def write(self,name):
        p=OUT/name
        with p.open('w',encoding='utf-8',newline='\n') as f:
            f.write('# Original low-poly planetary surface prop generated for Interstellar Rust\n')
            for x,y,z in self.v: f.write(f'v {x:.6f} {y:.6f} {z:.6f}\n')
            for face in self.f: f.write('f '+' '.join(map(str,face))+'\n')
        print(f'{p.name}: {len(self.v)} vertices, {len(self.f)} faces')

def tree():
    m=Obj(); m.cylinder(0,0,0,.065,.045,.47,8)
    for y,r,h in [(.20,.31,.34),(.40,.25,.34),(.59,.18,.36)]: m.cone(0,y,0,r,h,9)
    return m

def boulder():
    m=Obj(); rng=random.Random(91)
    rings=[]; sides=9
    for ri,(y,r) in enumerate([(0,.25),(.22,.43),(.56,.38),(.82,.23),(1,.08)]):
        ring=[]
        for i in range(sides):
            a=2*math.pi*i/sides
            wobble=rng.uniform(.82,1.18)
            ring.append(m.vertex((math.cos(a)*r*wobble,y+rng.uniform(-.035,.035),math.sin(a)*r*wobble)))
        rings.append(ring)
    for a,b in zip(rings,rings[1:]):
        for i in range(sides): m.face(a[i],b[i],b[(i+1)%sides],a[(i+1)%sides])
    m.face(*rings[0]); m.face(*reversed(rings[-1])); return m

def lunar_lander():
    m=Obj(); m.box(0,.52,0,.34,.20,.30); m.cylinder(0,.62,0,.18,.14,.18,8)
    m.dome(0,.76,0,.11,.11,8,3)
    for x in [-.27,.27]:
        for z in [-.22,.22]:
            m.box(x,.22,z,.045,.42,.045); m.box(x*1.16,.025,z*1.16,.20,.035,.20)
    m.cylinder(0,.80,0,.018,.012,.18,6)
    m.box(-.43,.56,0,.24,.035,.16); m.box(.43,.56,0,.24,.035,.16)
    m.box(-.43,.60,0,.035,.13,.035); m.box(.43,.60,0,.035,.13,.035)
    return m

def crystal_cluster():
    m=Obj()
    for x,z,r,h,n in [(0,0,.22,1.0,6),(-.22,.10,.13,.68,5),(.20,.12,.12,.76,5),(.11,-.20,.11,.57,5),(-.12,-.20,.10,.48,5)]:
        m.prism(x,0,z,r,h,n)
    return m

def habitat():
    m=Obj(); m.cylinder(0,.04,0,.39,.39,.18,12)
    m.dome(0,.22,0,.34,.47,14,6)
    m.box(0,.19,.39,.12,.27,.10)
    m.cylinder(0,.68,0,.055,.035,.19,8)
    m.box(-.48,.13,0,.24,.06,.20); m.box(.48,.13,0,.24,.06,.20)
    for x in [-.29,.29]:
        for z in [-.29,.29]: m.box(x,.025,z,.045,.12,.045)
    return m

def red_arch():
    m=Obj()
    # Two irregular rock columns and a lintel form a recognizable natural arch.
    m.box(-.30,.37,0,.25,.74,.30); m.box(.30,.37,0,.25,.74,.30)
    m.box(0,.78,0,.83,.20,.31)
    m.cone(-.30,.70,0,.15,.18,7); m.cone(.30,.70,0,.15,.18,7)
    return m

def volcanic_vent():
    m=Obj(); m.cone(0,0,0,.48,.72,12,.16)
    m.cylinder(0,.68,0,.20,.20,.06,12)
    m.cone(0,.74,0,.13,.18,9,.02)
    return m

def monument():
    m=Obj(); m.box(0,.06,0,.58,.12,.58)
    m.box(0,.48,0,.25,.74,.25)
    m.cone(0,.85,0,.22,.18,4)
    m.box(0,.20,.33,.12,.22,.06)
    return m

if __name__=='__main__':
    OUT.mkdir(parents=True,exist_ok=True)
    for name,fn in [('pine_tree.obj',tree),('surface_boulder.obj',boulder),('lunar_lander.obj',lunar_lander),('crystal_cluster.obj',crystal_cluster),('habitat_dome.obj',habitat),('red_rock_arch.obj',red_arch),('volcanic_vent.obj',volcanic_vent),('surface_monument.obj',monument)]: fn().write(name)
