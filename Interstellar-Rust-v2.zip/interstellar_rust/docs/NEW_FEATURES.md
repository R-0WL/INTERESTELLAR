# Cambios de interfaz y escala

## Menú principal

- `↑` / `↓` cambian el modo seleccionado.
- `Enter` abre el modo seleccionado.
- **Exploración** inicia el recorrido libre que ya estaba implementado.
- **Historia** y **Niveles** son opciones seleccionables con pantallas de presentación. La lógica de campaña y los retos por nivel quedan como trabajo posterior.

## Escala visual

Los radios se ampliaron para que las superficies se aprecien mejor en el renderizador por software. Las distancias entre la mayoría de los cuerpos no se multiplicaron, de modo que el mapa y el recorrido no se vuelvan desproporcionadamente grandes. La Luna se desplazó un poco más lejos de la Tierra para conservar un espacio visible entre ambas superficies.

Los tamaños son una escala artística comprimida, no una representación astronómica exacta. La nave conserva un tamaño de unos pocos world units, por lo que se ve pequeña respecto a los planetas y puede maniobrar alrededor de ellos.

| Cuerpo | Radio visual (unidades del mundo) |
|---|---:|
| Tierra | 180 |
| Luna | 54 |
| Marte | 105 |
| Júpiter | 350 |
| Saturno | 300 |
| Sol | 300 |
| Miller | 135 |
| Mann | 115 |
| Edmund | 125 |

## Órbitas

- Tierra, Marte, Júpiter y Saturno tienen guías circulares alrededor del Sol.
- La Luna tiene una guía circular alrededor de la Tierra.
- En la región posterior al agujero de gusano, Miller, Mann y Edmund reciben guías circulares alrededor de Gargantúa.
- Las trayectorias son visuales y estáticas: no aplican dinámica orbital ni desplazan automáticamente los planetas.

## Minimapa

- Está en la esquina superior derecha.
- `M` lo muestra u oculta.
- El marcador celeste representa la nave.
- Antes del agujero de gusano muestra el Sol, los cuerpos del sistema solar y las trayectorias.
- Después del agujero de gusano cambia a un mapa de Gargantúa y sus planetas.

## Volver al menú

Pulsa `Backspace` durante la exploración. El estado del viaje queda conservado mientras visitas el menú.
