# Capa 6 — materiales esféricos procedurales de alto detalle

La capa 6 es el preset de máxima calidad del renderizador por software. Está seleccionada por defecto y se puede forzar con `--shader-layer 6` o `--layer 6`.

## Corrección principal: las imágenes son referencias, no mapas UV

Las imágenes proporcionadas muestran cuerpos ya renderizados, fondos, halos, marcos y, en algunos casos, logotipos. No son mapas de superficie equirectangulares. Por eso **ya no se proyectan directamente sobre los planetas**. Se conservan en `assets/textures/` como referencia visual, pero el albedo de la capa 6 se reconstruye mediante campos volumétricos 3D evaluados a partir de la normal esférica. La superficie cubre los 360° del cuerpo sin arrastrar fondos negros, logos o elementos de composición fotográfica; tampoco presenta una costura de UV en el meridiano.

## Materiales y efectos

- **Tierra:** océanos profundos y plataformas costeras, masas continentales deformadas, biomas, bosques, desiertos, cordilleras y casquetes polares. Las nubes animadas y la atmósfera se dibujan en cáscaras independientes.
- **Edmund:** material de exoplaneta habitable con océanos verde azulado, masas continentales boscosas, tierras altas y regiones polares; incluye nubes y atmósfera animadas.
- **Miller:** planeta completamente oceánico. Varios trenes de olas se cruzan y desplazan a distinta velocidad; crestas, reflejos y espuma varían con el tiempo.
- **Mann:** roca de tonos fríos, placas de hielo, escarcha y fracturas azuladas. No utiliza la imagen de referencia que contiene el logotipo.
- **Júpiter y Saturno:** bandas atmosféricas deformadas por turbulencia; Júpiter incluye una tormenta ovalada. Urano y Neptuno tienen bandas y variaciones atmosféricas, con una tormenta oscura en Neptuno.
- **Marte, Mercurio y Luna:** superficies minerales, pátinas, cráteres y relieve de varias escalas.
- **Venus:** capas de nubes densas, ocres y doradas, con bandas turbulentas animadas.
- **Sol:** granulación fotosférica, filamentos calientes y una corona procedural animada con prominencias.
- **Agujero de gusano:** interior volumétrico de nebulosas azules, violetas y rosadas; galaxia espiral central con brazos, polvo oscuro, núcleo luminoso y puntos estelares. Una cáscara exterior translúcida añade reflejos de Fresnel para aproximarse a una bola de cristal con un universo en su interior. El shader cyan de los escapes de la nave permanece separado y sin cambios visuales intencionados.
- **Cielo profundo:** 16.000 estrellas de distintas temperaturas y luminosidades, centelleo sutil, banda galáctica, nubes de nebulosa con filamentos y carriles de polvo, y galaxias espirales pequeñas.
- **Cinturón de asteroides:** mantiene cuerpos orbitales independientes y variación procedural de roca.

## Ruta de renderizado CPU

1. La malla esférica de capa 6 se genera con 112 segmentos de latitud y 224 de longitud.
2. Antes de proyectar, los vértices reciben desplazamiento multi-octava determinista según su dirección tridimensional.
3. El rasterizador interpola posición y normal en perspectiva.
4. El fragment shader calcula el color con ruido 3D esférico, sin muestrear las fotografías.
5. El normal mapping procedural estima gradientes de altura alrededor de una base tangente y perturba la normal antes de la iluminación.
6. Las cáscaras animadas de nubes, atmósfera, corona y cristal se dibujan como geometrías independientes.

La dirección 3D evita los artefactos de proyección de las imágenes originales. No se ha llamado 16K a una textura ampliada artificialmente: el detalle se calcula durante el sombreado en función de la resolución de salida y del tamaño proyectado de cada cuerpo.

## Resolución

La ventana continúa en 1000×640. La causa del defecto observado no era el tamaño del framebuffer: era la naturaleza de las imágenes originales (renders promocionales y no mapas equirectangulares). El material procedural ahora recubre la esfera completa independientemente de esa resolución. Aumentar el framebuffer puede mejorar bordes y detalle de pantalla, pero no es necesario para corregir los fondos y logotipos incrustados.

## Alcance de esta pasada

Gargantúa y los modelos de naves no han recibido cambios visuales intencionados. Se ha modificado el shader del agujero de gusano y el fondo estelar, además de los materiales planetarios solicitados.

## Ejecución

Desde la carpeta `interstellar_rust_v9/`:

```bash
cargo run --release -- --place earth --shader-layer 6
cargo run --release -- --place miller --shader-layer 6
cargo run --release -- --place mann --shader-layer 6
cargo run --release -- --place edmund --shader-layer 6
cargo run --release -- --place wormhole --shader-layer 6
cargo run --release -- --foto all --shader-layer 6
```

Las imágenes de `assets/textures/` se mantienen en el proyecto para comparar colores y formas con las referencias del usuario. No se leen para colorear la superficie de los cuerpos.
