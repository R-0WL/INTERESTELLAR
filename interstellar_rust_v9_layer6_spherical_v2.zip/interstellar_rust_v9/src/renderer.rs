//! CPU triangle rasterizer.
//!
//! This module owns the complete rendering path:
//! model transform -> view transform -> perspective projection -> viewport
//! -> barycentric triangle fill -> depth test -> fragment/material function.
//! No GPU rendering API or scene-graph engine is used.

use crate::framebuffer::{color_from_f32, Framebuffer};
use crate::game::{Game, PlanetKind, SpaceBody, AU_SCALE, ASTEROID_BELT_INNER_AU, ASTEROID_BELT_OUTER_AU, GARGANTUA_DISK_RADIUS};
use crate::math::{cross, distance, dot, length, normalize, smoothstep, vec3, Mat4, Vec3};
use crate::mesh::Mesh;

#[derive(Clone, Copy, PartialEq, Eq)]
enum ShaderKind {
    Solid,
    Mercury,
    Venus,
    Earth,
    Moon,
    Mars,
    Jupiter,
    Saturn,
    Uranus,
    Neptune,
    Miller,
    Mann,
    Edmund,
    Sun,
    Ring,
    Wormhole, // Original cyan engine exhaust; kept unchanged for the ship.
    CrystalWormhole,
    WormholeGlass,
    AccretionDisc,
    Rock,
    Atmosphere,
    Clouds,
    Corona,
}

#[derive(Clone, Copy)]
struct Material {
    base_color: Vec3,
    shader: ShaderKind,
    emissive: f32,
    specular: f32,
    alpha: f32,
    detailed: bool,
    normal_strength: f32,
    displacement: f32,
}

impl Material {
    fn new(color: Vec3, shader: ShaderKind) -> Self {
        Self {
            base_color: color, shader, emissive: 0.0, specular: 0.18, alpha: 1.0,
            detailed: false, normal_strength: 0.0, displacement: 0.0,
        }
    }

    fn emissive(mut self, amount: f32) -> Self {
        self.emissive = amount;
        self
    }

    fn specular(mut self, amount: f32) -> Self {
        self.specular = amount;
        self
    }

    fn alpha(mut self, amount: f32) -> Self {
        self.alpha = amount.clamp(0.0, 1.0);
        self
    }


    fn detailed(mut self, enabled: bool) -> Self {
        self.detailed = enabled;
        self
    }

    fn normal_strength(mut self, amount: f32) -> Self {
        self.normal_strength = amount.max(0.0);
        self
    }

    fn displacement(mut self, amount: f32) -> Self {
        self.displacement = amount.max(0.0);
        self
    }
}

#[derive(Clone, Copy)]
struct Nebula {
    direction: Vec3,
    color: Vec3,
    radius: i32,
    seed: f32,
    galaxy: bool,
}

#[derive(Clone, Copy)]
struct ScreenVertex {
    x: f32,
    y: f32,
    z: f32,
    inv_w: f32,
    world_over_w: Vec3,
    normal_over_w: Vec3,
    uv_over_w: [f32; 2],
}

#[derive(Clone, Copy)]
struct Star {
    direction: Vec3,
    color: u32,
    radius: i32,
    twinkle_phase: f32,
    twinkle_amount: f32,
}

/// Imported scene objects prepared from the supplied GLB assets.
#[derive(Default)]
pub struct ImportedModels {
    pub solar_ship: Option<Mesh>,
    pub wormhole_ship: Option<Mesh>,
    pub gargantua: Option<Mesh>,
    pub endurance: Option<Mesh>,
    pub asteroid: Option<Mesh>,
}

pub struct Renderer {
    width: usize,
    height: usize,
    sphere: Mesh,
    detail_sphere: Mesh,
    nebulae: Vec<Nebula>,
    solar_ship: Mesh,
    wormhole_ship: Mesh,
    gargantua_model: Option<Mesh>,
    endurance_model: Option<Mesh>,
    asteroid_model: Mesh,
    cube: Mesh,
    rock: Mesh,
    torus: Mesh,
    ring: Mesh,
    stars: Vec<Star>,
    asteroids: Vec<(Vec3, Vec3, f32)>,
}

impl Renderer {
    pub fn new(width: usize, height: usize, imported_sphere: Option<Mesh>, models: ImportedModels) -> Self {
        let sphere = imported_sphere.unwrap_or_else(|| Mesh::uv_sphere(32, 56));
        // Layer 6 has a dedicated dense sphere. Its vertices are displaced by
        // deterministic multi-octave noise immediately before projection.
        let detail_sphere = Mesh::uv_sphere(112, 224);
        let stars = make_stars(16000);
        let nebulae = make_nebulae();
        let asteroids = make_asteroids();
        Self {
            width,
            height,
            sphere,
            detail_sphere,
            nebulae,
            solar_ship: models.solar_ship.unwrap_or_else(Mesh::spaceship),
            wormhole_ship: models.wormhole_ship.unwrap_or_else(Mesh::spaceship),
            gargantua_model: models.gargantua,
            endurance_model: models.endurance,
            asteroid_model: models.asteroid.unwrap_or_else(Mesh::octahedron),
            cube: Mesh::cube(),
            rock: Mesh::octahedron(),
            torus: Mesh::torus(1.0, 0.12, 64, 10),
            ring: Mesh::ring(1.0, 2.5, 96),
            stars,
            asteroids,
        }
    }

    pub fn render(&self, framebuffer: &mut Framebuffer, game: &Game) {
        self.render_with_layer(framebuffer, game, 6);
    }

    /// Layer 6 enables fully procedural spherical materials, procedural CPU
    /// normal mapping, animated atmospheric shells and displaced dense spheres.
    pub fn render_with_layer(&self, framebuffer: &mut Framebuffer, game: &Game, shader_layer: u8) {
        let layer6 = shader_layer.clamp(1, 6) == 6;
        framebuffer.clear_vertical_gradient(0x02040B, 0x080D1A);
        let (eye, target) = game.camera();
        let view = Mat4::look_at(eye, target, game.camera_up());
        let projection = Mat4::perspective(
            62.0_f32.to_radians(),
            self.width as f32 / self.height as f32,
            0.1,
            3_000_000.0,
        );
        let view_projection = projection * view;

        self.render_nebula_sky(framebuffer, eye, view_projection);
        self.render_stars(framebuffer, eye, view_projection, game.clock);
        self.render_space_bodies(framebuffer, game, eye, view_projection, layer6);
        if !game.destroyed && !game.is_overview() {
            self.render_ship(framebuffer, game, eye, view_projection);
        }
        if !game.is_overview() {
            self.render_speed_effect(framebuffer, game);
        }
    }

    /// Screen-space radial streaks inspired by the supplied hyperspace reference.
    /// Regular Shift boost is intentionally faint; Shift+B produces the full warp tunnel.
    fn render_speed_effect(&self, fb: &mut Framebuffer, game: &Game) {
        if !game.boost_active {
            return;
        }

        let superboost = game.superboost_active;
        let ray_count = if superboost { 220 } else { 18 };
        let center_x = self.width as f32 * 0.5;
        let center_y = self.height as f32 * 0.5;
        let max_radius = (center_x * center_x + center_y * center_y).sqrt() * 1.08;
        let golden_angle = 2.399_963_1_f32;

        for index in 0..ray_count {
            let seed = index as f32 * 91.731 + 17.17;
            let random_a = (seed.sin() * 43_758.547).fract().abs();
            let random_b = ((seed + 31.416).sin() * 24_634.635).fract().abs();
            let angle = index as f32 * golden_angle
                + game.clock * if superboost { 0.055 } else { 0.018 }
                + (random_a - 0.5) * 0.22;
            let (sin_angle, cos_angle) = angle.sin_cos();

            // Leave a dark breathing space around the vanishing point, as in
            // the reference image, so the ship/reticle remain readable.
            let inner_radius = if superboost { 26.0 + random_a * 66.0 } else { 42.0 + random_a * 52.0 };
            let outer_radius = max_radius * if superboost {
                0.30 + random_b * 0.82
            } else {
                0.24 + random_b * 0.52
            };
            let start_x = center_x + cos_angle * inner_radius;
            let start_y = center_y + sin_angle * inner_radius;
            let end_x = center_x + cos_angle * outer_radius;
            let end_y = center_y + sin_angle * outer_radius;

            let color = if index % 7 == 0 {
                0x79BFFF
            } else if index % 5 == 0 {
                0xD9F0FF
            } else {
                0xFFFFFF
            };
            let alpha = if superboost {
                (82.0 + random_a * 135.0) as u8
            } else {
                (7.0 + random_a * 15.0) as u8
            };
            fb.draw_line_blended(
                start_x.round() as i32,
                start_y.round() as i32,
                end_x.round() as i32,
                end_y.round() as i32,
                color,
                alpha,
            );

            // A few streaks get a very thin luminous core, but avoid thick neon bars.
            if superboost && index % 9 == 0 {
                fb.draw_line_blended(
                    start_x.round() as i32 + 1,
                    start_y.round() as i32,
                    end_x.round() as i32 + 1,
                    end_y.round() as i32,
                    0xB8DCFF,
                    (alpha / 2).max(24),
                );
            }
        }
    }

    fn render_nebula_sky(&self, fb: &mut Framebuffer, eye: Vec3, vp: Mat4) {
        for nebula in &self.nebulae {
            let anchor = eye + nebula.direction * 1_250_000.0;
            let Some((cx, cy, _)) = project_point(anchor, vp, self.width, self.height) else { continue; };
            if nebula.galaxy {
                self.draw_spiral_galaxy(fb, cx, cy, nebula.radius, nebula.color, nebula.seed);
            } else {
                self.draw_nebula_cloud(fb, cx, cy, nebula.radius, nebula.color, nebula.seed);
            }
        }
    }

    fn draw_nebula_cloud(&self, fb: &mut Framebuffer, cx: i32, cy: i32, radius: i32, color: Vec3, seed: f32) {
        for oy in -radius..=radius {
            for ox in -radius..=radius {
                let nx = ox as f32 / radius.max(1) as f32;
                let ny = oy as f32 / radius.max(1) as f32;
                let r2 = nx * nx + ny * ny * 0.72;
                if r2 >= 1.0 { continue; }
                let turbulence = fbm3(vec3(nx * 8.0 + seed, ny * 8.0, seed * 0.37), 4);
                let filaments = fbm3(vec3(nx * 22.0, ny * 19.0, seed + 4.0), 3);
                let dust_lane = smoothstep(0.58, 0.82, noise3(vec3(nx * 5.0 + seed, ny * 7.0, seed * 0.21)));
                let cloud_density = (turbulence * 0.63 + filaments * 0.37) * (1.0 - dust_lane * 0.46);
                let alpha = ((1.0 - r2).powf(1.35) * (0.022 + cloud_density * 0.105) * 255.0) as u8;
                if alpha > 0 {
                    let tint = color * (0.34 + cloud_density * 0.92);
                    fb.blend_pixel(cx + ox, cy + oy, color_from_f32(tint.x, tint.y, tint.z), alpha);
                }
            }
        }
    }

    fn draw_spiral_galaxy(&self, fb: &mut Framebuffer, cx: i32, cy: i32, radius: i32, color: Vec3, seed: f32) {
        for oy in -radius..=radius {
            for ox in -radius..=radius {
                let nx = ox as f32 / radius.max(1) as f32;
                let ny = oy as f32 / radius.max(1) as f32;
                let r = (nx * nx + ny * ny * 0.28).sqrt();
                if r >= 1.0 { continue; }
                let angle = ny.atan2(nx);
                let arm_a = (angle * 2.0 - r * 17.0 + seed).sin().abs();
                let arm_b = (angle * 3.0 - r * 22.0 + seed * 0.7).sin().abs();
                let arm = (arm_a * 0.62 + arm_b * 0.38).clamp(0.0, 1.0);
                let core = (-r * 8.2).exp();
                let dust = fbm3(vec3(nx * 15.0, ny * 15.0, seed), 3);
                let dark_lane = smoothstep(0.58, 0.88, dust);
                let alpha = ((core * 0.22 + (1.0 - r) * (1.0 - arm).powf(2.6) * 0.115)
                    * (0.38 + dust * 0.62) * (1.0 - dark_lane * 0.35) * 255.0) as u8;
                if alpha > 0 {
                    let tint = color * (0.40 + core * 1.55 + dust * 0.42);
                    fb.blend_pixel(cx + ox, cy + oy, color_from_f32(tint.x, tint.y, tint.z), alpha);
                }
            }
        }
    }

    fn render_stars(&self, framebuffer: &mut Framebuffer, eye: Vec3, view_projection: Mat4, time: f32) {
        for star in &self.stars {
            // Fixed directions create a sky sphere, not a cloud of particles
            // moving with the camera. Small luminosity changes mimic scintillation.
            let position = eye + star.direction * 1_300_000.0;
            if let Some((x, y, depth)) = project_point(position, view_projection, self.width, self.height) {
                let pulse = 1.0 - star.twinkle_amount * (0.5 + 0.5 * (time * 2.1 + star.twinkle_phase).sin());
                let r = ((star.color >> 16) & 0xFF) as f32 * pulse;
                let g = ((star.color >> 8) & 0xFF) as f32 * pulse;
                let b = (star.color & 0xFF) as f32 * pulse;
                let color = color_from_f32(r / 255.0, g / 255.0, b / 255.0);
                if star.radius <= 1 {
                    framebuffer.set_pixel_depth(x, y, depth, color);
                } else {
                    for oy in -star.radius..=star.radius {
                        for ox in -star.radius..=star.radius {
                            if ox * ox + oy * oy <= star.radius * star.radius {
                                framebuffer.set_pixel_depth(x + ox, y + oy, depth, color);
                            }
                        }
                    }
                    // A restrained one-pixel bloom makes the brighter stars read
                    // as luminous points without turning the whole sky into noise.
                    if star.radius >= 2 {
                        framebuffer.blend_pixel(x - star.radius - 1, y, color, 70);
                        framebuffer.blend_pixel(x + star.radius + 1, y, color, 70);
                        framebuffer.blend_pixel(x, y - star.radius - 1, color, 70);
                        framebuffer.blend_pixel(x, y + star.radius + 1, color, 70);
                    }
                }
            }
        }
    }

    fn render_space_bodies(&self, framebuffer: &mut Framebuffer, game: &Game, eye: Vec3, vp: Mat4, layer6: bool) {
        // Orbital paths are drawn first so planet meshes naturally cover the
        // parts of the lines that pass behind their surfaces in the Z-buffer.
        if !game.crossed_wormhole {
            self.render_solar_orbits(framebuffer, game, vp);
        } else {
            self.render_gargantua_orbits(framebuffer, game, vp);
        }

        let body_cull_distance = if game.is_overview() { 2_900_000.0 } else { 1_500_000.0 };
        for body in &game.bodies {
            if !game.body_is_visible(body) {
                continue;
            }
            if distance(body.position, eye) > body_cull_distance {
                continue;
            }
            self.render_body(framebuffer, body, game.clock, eye, vp, layer6);
        }

        if !game.crossed_wormhole {
            let belt_marker = game.bodies.iter().find(|body| body.kind == PlanetKind::AsteroidBelt);
            let sun = game.bodies.iter().find(|body| body.kind == PlanetKind::Sun);
            if let (Some(marker), Some(sun)) = (belt_marker, sun) {
                // Asteroids are distributed across the complete 360-degree belt.
                // The belt marker is retained only for navigation and visibility.
                let belt_cull_distance = if game.is_overview() { 2_900_000.0 } else { 400_000.0 };
                if distance(marker.position, eye) < belt_cull_distance {
                    self.render_asteroid_belt(framebuffer, sun.position, eye, vp, game.clock, belt_cull_distance, layer6);
                }
            }
        }
    }

    /// Draw circular orbital guides around the Sun. Planet radii use compressed
    /// AU units but preserve each planet's approximate semi-major-axis ratio.
    fn render_solar_orbits(&self, fb: &mut Framebuffer, game: &Game, vp: Mat4) {
        let Some(sun) = game.bodies.iter().find(|body| body.kind == PlanetKind::Sun) else {
            return;
        };

        for (kind, color) in [
            (PlanetKind::Mercury, 0x8B7A65),
            (PlanetKind::Venus, 0xB58B55),
            (PlanetKind::Earth, 0x285A78),
            (PlanetKind::Mars, 0x765344),
            (PlanetKind::Jupiter, 0x78634A),
            (PlanetKind::Saturn, 0x756C50),
            (PlanetKind::Uranus, 0x4F8790),
            (PlanetKind::Neptune, 0x3D5F9B),
        ] {
            if let Some(planet) = game.bodies.iter().find(|body| body.kind == kind) {
                let offset = planet.position - sun.position;
                let radius = (offset.x * offset.x + offset.z * offset.z).sqrt();
                let axis_u = normalize(vec3(offset.x, 0.0, offset.z));
                let mut axis_v = normalize(cross(vec3(0.0, 1.0, 0.0), axis_u));
                if length(axis_v) < 0.001 {
                    axis_v = normalize(cross(vec3(1.0, 0.0, 0.0), axis_u));
                }
                self.draw_orbit_line(fb, sun.position, axis_u, axis_v, radius, color, vp, 180);
            }
        }

        // The asteroid field is shown as individual rocks, without circular
        // guide lines that could make the belt look like a solid ring again.

        // Earth's Moon is the only moon currently represented as a world in
        // this journey, so its guide is centered on Earth rather than the Sun.
        if let (Some(earth), Some(moon)) = (
            game.bodies.iter().find(|body| body.kind == PlanetKind::Earth),
            game.bodies.iter().find(|body| body.kind == PlanetKind::Moon),
        ) {
            let offset = moon.position - earth.position;
            let radius = (offset.x * offset.x + offset.z * offset.z).sqrt();
            let axis_u = normalize(vec3(offset.x, 0.0, offset.z));
            let mut axis_v = normalize(cross(vec3(0.0, 1.0, 0.0), axis_u));
            if length(axis_v) < 0.001 {
                axis_v = normalize(cross(vec3(1.0, 0.0, 0.0), axis_u));
            }
            self.draw_orbit_line(fb, earth.position, axis_u, axis_v, radius, 0x697987, vp, 96);
        }
    }

    /// Draw the three known planets around Gargantua in the second-system view.
    fn render_gargantua_orbits(&self, fb: &mut Framebuffer, game: &Game, vp: Mat4) {
        let Some(center_body) = game.bodies.iter().find(|body| body.kind == PlanetKind::Gargantua) else {
            return;
        };
        for (kind, color) in [
            (PlanetKind::MillerWater, 0x28677C),
            (PlanetKind::MannIce, 0x71899A),
            (PlanetKind::EdmundHabitable, 0x526A4B),
        ] {
            if let Some(planet) = game.bodies.iter().find(|body| body.kind == kind) {
                let offset = planet.position - center_body.position;
                let radius = (offset.x * offset.x + offset.z * offset.z).sqrt();
                let axis_u = normalize(vec3(offset.x, 0.0, offset.z));
                let mut axis_v = normalize(cross(vec3(0.0, 1.0, 0.0), axis_u));
                if length(axis_v) < 0.001 {
                    axis_v = normalize(cross(vec3(1.0, 0.0, 0.0), axis_u));
                }
                self.draw_orbit_line(fb, center_body.position, axis_u, axis_v, radius, color, vp, 150);
            }
        }
    }

    fn draw_orbit_line(
        &self,
        fb: &mut Framebuffer,
        center: Vec3,
        axis_u: Vec3,
        axis_v: Vec3,
        radius: f32,
        color: u32,
        vp: Mat4,
        segments: usize,
    ) {
        if radius <= 1.0 || segments < 3 {
            return;
        }
        let mut previous: Option<(i32, i32, f32)> = None;
        for index in 0..=segments {
            let angle = index as f32 / segments as f32 * std::f32::consts::TAU;
            let point = center + axis_u * (radius * angle.cos()) + axis_v * (radius * angle.sin());
            let current = project_point(point, vp, self.width, self.height);
            if let (Some((x0, y0, _)), Some((x1, y1, _))) = (previous, current) {
                fb.draw_line(x0, y0, x1, y1, color);
            }
            previous = current;
        }
    }

    fn render_body(&self, fb: &mut Framebuffer, body: &SpaceBody, time: f32, eye: Vec3, vp: Mat4, layer6: bool) {
        let position = body.position;
        let radius = body.radius;
        let sphere = if layer6 { &self.detail_sphere } else { &self.sphere };
        match body.kind {
            PlanetKind::Earth => {
                let rotation = Mat4::rotation_y(time * 0.018);
                let model = Mat4::translation(position) * rotation * Mat4::scale(vec3(radius, radius, radius));
                let material = material_for(body.kind, layer6).displacement(if layer6 { 0.0025 } else { 0.0 });
                self.draw_mesh(fb, sphere, model, material, eye, vp, time);
                if layer6 {
                    let clouds = Mat4::translation(position) * Mat4::rotation_y(time * 0.024 + 0.7)
                        * Mat4::scale(vec3(radius * 1.009, radius * 1.009, radius * 1.009));
                    self.draw_mesh(fb, sphere, clouds, Material::new(vec3(0.76, 0.86, 0.96), ShaderKind::Clouds)
                        .alpha(0.34), eye, vp, time);
                    let atmosphere = Mat4::translation(position) * Mat4::scale(vec3(radius * 1.035, radius * 1.035, radius * 1.035));
                    self.draw_mesh(fb, sphere, atmosphere, Material::new(vec3(0.22, 0.54, 1.0), ShaderKind::Atmosphere)
                        .alpha(0.16).emissive(0.15), eye, vp, time);
                }
            }
            PlanetKind::Sun => {
                let model = Mat4::translation(position) * Mat4::scale(vec3(radius, radius, radius));
                let sun_material = Material::new(vec3(1.0, 0.68, 0.25), ShaderKind::Sun).emissive(1.8)
                    .detailed(layer6).normal_strength(if layer6 { 1.05 } else { 0.0 });
                self.draw_mesh(fb, sphere, model, sun_material, eye, vp, time);
                if layer6 {
                    // The translucent shell is drawn after the photosphere so
                    // its prominences never depth-occlude the solar surface.
                    let corona = Mat4::translation(position) * Mat4::rotation_y(time * 0.03)
                        * Mat4::scale(vec3(radius * 1.105, radius * 1.105, radius * 1.105));
                    self.draw_mesh(fb, sphere, corona, Material::new(vec3(1.0, 0.35, 0.08), ShaderKind::Corona)
                        .alpha(0.34).emissive(0.82), eye, vp, time);
                }
            }
            PlanetKind::Mercury | PlanetKind::Venus | PlanetKind::Moon | PlanetKind::Mars |
            PlanetKind::Jupiter | PlanetKind::Uranus | PlanetKind::Neptune |
            PlanetKind::MillerWater | PlanetKind::MannIce | PlanetKind::EdmundHabitable => {
                let rotation = Mat4::rotation_y(time * if body.kind == PlanetKind::Jupiter { 0.035 } else { 0.012 });
                let model = Mat4::translation(position) * rotation * Mat4::scale(vec3(radius, radius, radius));
                let displacement = if !layer6 { 0.0 } else { match body.kind {
                    PlanetKind::Mercury | PlanetKind::Moon | PlanetKind::Mars | PlanetKind::MannIce => 0.014,
                    PlanetKind::MillerWater => 0.0015, PlanetKind::EdmundHabitable => 0.004,
                    _ => 0.001,
                }};
                self.draw_mesh(fb, sphere, model, material_for(body.kind, layer6).displacement(displacement), eye, vp, time);
                if layer6 && body.kind == PlanetKind::EdmundHabitable {
                    let clouds = Mat4::translation(position) * Mat4::rotation_y(time * 0.020 + 1.1)
                        * Mat4::scale(vec3(radius * 1.010, radius * 1.010, radius * 1.010));
                    self.draw_mesh(fb, sphere, clouds, Material::new(vec3(0.76, 0.86, 0.91), ShaderKind::Clouds)
                        .alpha(0.30), eye, vp, time);
                    let atmosphere = Mat4::translation(position)
                        * Mat4::scale(vec3(radius * 1.032, radius * 1.032, radius * 1.032));
                    self.draw_mesh(fb, sphere, atmosphere, Material::new(vec3(0.45, 0.75, 0.94), ShaderKind::Atmosphere)
                        .alpha(0.15).emissive(0.12), eye, vp, time);
                }
            }
            PlanetKind::Saturn => {
                let model = Mat4::translation(position)
                    * Mat4::rotation_y(time * 0.012)
                    * Mat4::scale(vec3(radius, radius, radius));
                self.draw_mesh(fb, sphere, model, material_for(body.kind, layer6), eye, vp, time);
                let rings = Mat4::translation(position)
                    * Mat4::rotation_x(1.13)
                    * Mat4::rotation_z(0.14)
                    * Mat4::scale(vec3(radius * 1.0, radius * 1.0, radius * 0.16));
                self.draw_mesh(fb, &self.ring, rings, Material::new(vec3(0.72, 0.61, 0.43), ShaderKind::Ring).specular(0.35), eye, vp, time);
            }
            PlanetKind::Wormhole => {
                // The anomaly is kept as one luminous spherical body; no outer rings.
                let model = Mat4::translation(position)
                    * Mat4::rotation_y(time * 0.08)
                    * Mat4::scale(vec3(radius, radius, radius));
                // The supplied wormhole image is a photographic reference, not a
                // spherical UV map. Build its interior from volumetric noise and a
                // procedural spiral galaxy, then overlay a restrained glass shell.
                let wormhole_material = Material::new(vec3(0.025, 0.055, 0.12), ShaderKind::CrystalWormhole)
                    .emissive(0.72).specular(0.92).detailed(layer6)
                    .normal_strength(if layer6 { 0.22 } else { 0.0 });
                self.draw_mesh(fb, sphere, model, wormhole_material, eye, vp, time);
                if layer6 {
                    let glass_model = Mat4::translation(position)
                        * Mat4::rotation_y(time * 0.08)
                        * Mat4::scale(vec3(radius * 1.018, radius * 1.018, radius * 1.018));
                    self.draw_mesh(fb, sphere, glass_model,
                        Material::new(vec3(0.42, 0.72, 0.96), ShaderKind::WormholeGlass)
                            .alpha(0.17).specular(1.8), eye, vp, time);
                }
            }
            PlanetKind::Docking => {
                if let Some(endurance) = &self.endurance_model {
                    // This imported Endurance + Ranger model replaces the old docking torus.
                    let model = Mat4::translation(position)
                        * Mat4::rotation_y(time * 0.035 + std::f32::consts::FRAC_PI_2)
                        * Mat4::scale(vec3(radius * 1.4, radius * 1.4, radius * 1.4));
                    self.draw_mesh(fb, endurance, model,
                        Material::new(vec3(0.66, 0.70, 0.76), ShaderKind::Solid).specular(0.82),
                        eye, vp, time);
                } else {
                    let model = Mat4::translation(position) * Mat4::rotation_z(time * 0.08) * Mat4::scale(vec3(radius * 1.4, radius * 1.4, radius * 0.3));
                    self.draw_mesh(fb, &self.torus, model, Material::new(vec3(0.62, 0.72, 0.78), ShaderKind::Solid).specular(0.75), eye, vp, time);
                }
            }
            PlanetKind::Gargantua => {
                // The normalized OBJ's outer disk radius is 1.0. Set that edge
                // 1,600 world units inside Miller's orbit, making Gargantua
                // colossally large while keeping a narrow, intentional gap.
                // SpaceBody.radius tracks the matching 0.425 event-horizon ratio.
                let model_scale = GARGANTUA_DISK_RADIUS;
                let black_hole = Mat4::translation(position)
                    * Mat4::rotation_y(time * 0.006)
                    * Mat4::scale(vec3(model_scale, model_scale, model_scale));
                if let Some(model) = &self.gargantua_model {
                    // Use the supplied Gargantua GLB mesh instead of the procedural sphere.
                    self.draw_mesh(fb, model, black_hole,
                        Material::new(vec3(0.18, 0.13, 0.22), ShaderKind::Solid).specular(0.42),
                        eye, vp, time);
                } else {
                    self.draw_mesh(fb, &self.sphere, black_hole,
                        Material::new(vec3(0.004, 0.003, 0.008), ShaderKind::Solid), eye, vp, time);
                    let disk = Mat4::translation(position)
                        * Mat4::rotation_x(0.32)
                        * Mat4::rotation_z(time * 0.04)
                        * Mat4::scale(vec3(radius * 0.42, radius * 0.42, radius * 0.08));
                    self.draw_mesh(fb, &self.ring, disk,
                        Material::new(vec3(1.0, 0.47, 0.17), ShaderKind::AccretionDisc).emissive(0.85), eye, vp, time);
                    let outer = Mat4::translation(position)
                        * Mat4::rotation_x(0.32)
                        * Mat4::scale(vec3(radius * 0.62, radius * 0.62, radius * 0.05));
                    self.draw_mesh(fb, &self.ring, outer,
                        Material::new(vec3(0.35, 0.24, 0.62), ShaderKind::AccretionDisc).emissive(0.18), eye, vp, time);
                }
            }
            PlanetKind::AsteroidBelt => {}
        }
    }

    fn render_asteroid_belt(
        &self, fb: &mut Framebuffer, sun: Vec3, eye: Vec3, vp: Mat4, time: f32, max_distance: f32, layer6: bool,
    ) {
        // Each rock follows its own Keplerian speed: inner asteroids orbit
        // faster than outer ones instead of rotating as a rigid disc.
        for (offset, size, rotation) in &self.asteroids {
            let orbital_radius_au = (offset.x * offset.x + offset.z * offset.z).sqrt() / AU_SCALE;
            let orbital_period = 300.0 * orbital_radius_au.max(0.1).powf(1.5);
            let angle = time * (std::f32::consts::TAU / orbital_period);
            let (sin_angle, cos_angle) = angle.sin_cos();
            let rotated = vec3(
                offset.x * cos_angle + offset.z * sin_angle,
                offset.y,
                -offset.x * sin_angle + offset.z * cos_angle,
            );
            let position = sun + rotated;
            if distance(position, eye) > max_distance {
                continue;
            }
            let model = Mat4::translation(position)
                * Mat4::rotation_y(*rotation + time * 0.025)
                * Mat4::rotation_x(*rotation * 0.7 + time * 0.013)
                * Mat4::scale(*size);
            self.draw_mesh(fb, &self.asteroid_model, model,
                Material::new(vec3(0.37, 0.34, 0.31), ShaderKind::Rock).detailed(layer6), eye, vp, time);
        }
    }

    fn render_ship(&self, fb: &mut Framebuffer, game: &Game, eye: Vec3, vp: Mat4) {
        // These imported GLBs use different local axes. Endurance's ring lies
        // in the YZ plane, so it needs a quarter-turn to face the chase camera.
        // Ranger's aft engine is on its -Z end, so a half-turn brings that rear
        // face toward the camera. Only the mesh orientation changes; flight
        // direction, yaw, pitch, and thrust remain in the game's own basis.
        let (ship_mesh, ship_scale, local_yaw) = if game.crossed_wormhole {
            (&self.wormhole_ship, 4.8, std::f32::consts::PI)
        } else {
            (&self.solar_ship, 5.0, std::f32::consts::FRAC_PI_2)
        };
        let model = Mat4::translation(game.position)
            * Mat4::rotation_y(game.yaw)
            * Mat4::rotation_x(game.pitch)
            * Mat4::rotation_y(local_yaw)
            * Mat4::scale(vec3(ship_scale, ship_scale, ship_scale));
        self.draw_mesh(fb, ship_mesh, model,
            Material::new(vec3(0.72, 0.79, 0.83), ShaderKind::Solid).specular(0.82),
            eye, vp, game.clock);

        // Engine plumes stay restrained during normal boost; superboost gets
        // a longer and brighter exhaust to reinforce the stronger warp tunnel.
        let right = game.right();
        let up = game.up();
        let backward = -game.forward();
        let exhaust_length = if game.superboost_active {
            2.6
        } else if game.boost_active {
            0.68
        } else if game.speed > 180.0 {
            0.85
        } else {
            0.55
        };
        let exhaust_glow = if game.superboost_active { 1.35 } else if game.boost_active { 0.32 } else { 0.55 };
        for side in [-0.42, 0.42] {
            let center = game.position + right * side + backward * 3.15;
            let exhaust_model = Mat4::translation(center)
                * Mat4::rotation_y(game.yaw)
                * Mat4::rotation_x(game.pitch)
                * Mat4::scale(vec3(0.12, 0.12, exhaust_length));
            let _ = up; // Kept explicit to show the ship's local basis.
            self.draw_mesh(fb, &self.torus, exhaust_model, Material::new(vec3(0.20, 0.78, 1.0), ShaderKind::Wormhole).emissive(exhaust_glow), eye, vp, game.clock);
        }
    }

    /// Transform and rasterize a complete indexed triangle mesh.
    fn draw_mesh(
        &self,
        fb: &mut Framebuffer,
        mesh: &Mesh,
        model: Mat4,
        material: Material,
        eye: Vec3,
        vp: Mat4,
        time: f32,
    ) {
        if mesh.vertices.is_empty() || mesh.triangles.is_empty() {
            return;
        }
        let mvp = vp * model;
        let mut transformed: Vec<Option<ScreenVertex>> = Vec::with_capacity(mesh.vertices.len());
        for vertex in &mesh.vertices {
            let mut local_position = vertex.position;
            if material.displacement > 0.0 {
                let direction = normalize(local_position);
                let broad = noise3(direction * 5.2);
                let medium = noise3(direction * 13.7) * 0.38;
                let fine = noise3(direction * 31.0) * 0.16;
                let ridge = (broad * 0.72 + medium + fine - 0.62) * material.displacement;
                local_position = direction * (length(local_position) + ridge);
            }
            let world = model.transform_point(local_position);
            let normal = model.transform_direction(vertex.normal);
            let clip = mvp.transform_vec4([local_position.x, local_position.y, local_position.z, 1.0]);
            if clip[3] <= 0.1 || clip[3].is_nan() {
                transformed.push(None);
                continue;
            }
            let inv_w = 1.0 / clip[3];
            let ndc_x = clip[0] * inv_w;
            let ndc_y = clip[1] * inv_w;
            let ndc_z = clip[2] * inv_w;
            let screen_x = (ndc_x * 0.5 + 0.5) * self.width as f32;
            let screen_y = (0.5 - ndc_y * 0.5) * self.height as f32;
            transformed.push(Some(ScreenVertex {
                x: screen_x,
                y: screen_y,
                z: ndc_z,
                inv_w,
                world_over_w: world * inv_w,
                normal_over_w: normal * inv_w,
                uv_over_w: [vertex.uv[0] * inv_w, vertex.uv[1] * inv_w],
            }));
        }

        for triangle in &mesh.triangles {
            let Some(a) = transformed[triangle[0]] else { continue };
            let Some(b) = transformed[triangle[1]] else { continue };
            let Some(c) = transformed[triangle[2]] else { continue };
            self.rasterize_triangle(fb, a, b, c, material, eye, time);
        }
    }

    fn rasterize_triangle(
        &self,
        fb: &mut Framebuffer,
        a: ScreenVertex,
        b: ScreenVertex,
        c: ScreenVertex,
        material: Material,
        eye: Vec3,
        time: f32,
    ) {
        let area = edge(a.x, a.y, b.x, b.y, c.x, c.y);
        if area.abs() < 0.0001 {
            return;
        }

        let min_x = a.x.min(b.x).min(c.x).floor().max(0.0) as i32;
        let max_x = a.x.max(b.x).max(c.x).ceil().min((self.width - 1) as f32) as i32;
        let min_y = a.y.min(b.y).min(c.y).floor().max(0.0) as i32;
        let max_y = a.y.max(b.y).max(c.y).ceil().min((self.height - 1) as f32) as i32;
        if min_x > max_x || min_y > max_y {
            return;
        }

        for y in min_y..=max_y {
            for x in min_x..=max_x {
                let px = x as f32 + 0.5;
                let py = y as f32 + 0.5;
                let w0 = edge(b.x, b.y, c.x, c.y, px, py) / area;
                let w1 = edge(c.x, c.y, a.x, a.y, px, py) / area;
                let w2 = edge(a.x, a.y, b.x, b.y, px, py) / area;
                if w0 < -0.0001 || w1 < -0.0001 || w2 < -0.0001 {
                    continue;
                }

                let depth = w0 * a.z + w1 * b.z + w2 * c.z;
                if !(0.0..=1.0).contains(&depth) {
                    continue;
                }
                let reciprocal_w = w0 * a.inv_w + w1 * b.inv_w + w2 * c.inv_w;
                if reciprocal_w.abs() < 1.0e-8 {
                    continue;
                }
                let correction = 1.0 / reciprocal_w;
                let world_position = (a.world_over_w * w0 + b.world_over_w * w1 + c.world_over_w * w2) * correction;
                let normal = normalize((a.normal_over_w * w0 + b.normal_over_w * w1 + c.normal_over_w * w2) * correction);
                let uv = [
                    (a.uv_over_w[0] * w0 + b.uv_over_w[0] * w1 + c.uv_over_w[0] * w2) * correction,
                    (a.uv_over_w[1] * w0 + b.uv_over_w[1] * w1 + c.uv_over_w[1] * w2) * correction,
                ];
                let color = self.fragment(material, uv, world_position, normal, eye, time);
                let pixel_alpha = self.fragment_alpha(material, uv, normal, time);
                if pixel_alpha < 0.999 {
                    if pixel_alpha > 0.015 {
                        fb.blend_pixel_depth(x, y, depth, color, (pixel_alpha * 255.0) as u8);
                    }
                } else {
                    fb.set_pixel_depth(x, y, depth, color);
                }
            }
        }
    }

    /// CPU fragment shader: procedural spherical albedo, normal mapping and lighting.
    fn fragment(&self, material: Material, uv: [f32; 2], position: Vec3, normal: Vec3, eye: Vec3, time: f32) -> u32 {
        let geometric_normal = if length(normal) > 0.1 { normalize(normal) } else { vec3(0.0, 1.0, 0.0) };
        let n = self.map_normal(material, uv, geometric_normal, time);
        let albedo = self.sample_material(material, uv, n, position, time);
        let light_direction = normalize(vec3(-0.42, 0.72, 0.55));
        let diffuse = dot(n, light_direction).max(0.0);
        let view_direction = normalize(eye - position);
        let half_vector = normalize(light_direction + view_direction);
        let mut specular = dot(n, half_vector).max(0.0).powf(26.0) * material.specular;
        if material.shader == ShaderKind::Wormhole || material.shader == ShaderKind::CrystalWormhole || material.shader == ShaderKind::WormholeGlass {
            let fresnel = (1.0 - dot(n, view_direction).abs()).clamp(0.0, 1.0).powf(3.2);
            specular += fresnel * if material.shader == ShaderKind::WormholeGlass { 1.25 } else { 0.72 };
        }
        // A low blue environmental fill retains faint color on the night side;
        // the direct key light still defines a clear day/night terminator.
        let illumination = if material.shader == ShaderKind::Wormhole || material.shader == ShaderKind::Solid {
            // Preserve the original ship, docking and Gargantua solid-material lighting.
            0.22 + diffuse * 0.82
        } else {
            0.27 + diffuse * 0.78
        };
        let color = match material.shader {
            ShaderKind::Atmosphere => {
                let rim = (1.0 - dot(n, view_direction).abs()).clamp(0.0, 1.0).powf(2.4);
                material.base_color * (0.12 + rim * 1.55)
            }
            ShaderKind::Clouds => albedo * (0.45 + diffuse * 0.55),
            ShaderKind::Corona => albedo * (0.42 + diffuse * 0.82 + material.emissive),
            ShaderKind::WormholeGlass => {
                let fresnel = (1.0 - dot(n, view_direction).abs()).clamp(0.0, 1.0).powf(2.6);
                vec3(0.30, 0.62, 0.92) * (0.10 + fresnel * 1.15)
                    + vec3(specular * 0.95, specular * 1.02, specular * 1.08)
            }
            _ => albedo * (illumination + material.emissive) + vec3(specular, specular, specular),
        };
        color_from_f32(color.x, color.y, color.z)
    }

    fn sample_material(&self, material: Material, uv: [f32; 2], normal: Vec3, position: Vec3, time: f32) -> Vec3 {
        if !material.detailed {
            return sample_material_procedural(material, uv, normal, position, time);
        }
        match material.shader {
            ShaderKind::Atmosphere => material.base_color,
            ShaderKind::Clouds => {
                // Two-scale, time-advected billows with fine wisps. The field is
                // evaluated in 3D direction space, so it wraps without a UV seam.
                let drift = vec3(time * 0.018, time * 0.006, -time * 0.012);
                let broad = fbm3(normal * 8.5 + drift, 4);
                let billow = fbm3(normal * 22.0 + drift * 1.7, 3);
                let wisps = fbm3(normal * 63.0 + drift * 2.4, 2);
                let density = smoothstep(0.48, 0.72, broad * 0.62 + billow * 0.28 + wisps * 0.10);
                vec3(0.66, 0.76, 0.86) * (0.48 + density * 0.88)
            }
            _ => sample_material_procedural(material, uv, normal, position, time),
        }
    }

    fn fragment_alpha(&self, material: Material, uv: [f32; 2], normal: Vec3, time: f32) -> f32 {
        match material.shader {
            ShaderKind::Clouds => {
                let broad = noise3(normal * 15.0 + vec3(time * 0.018, 0.0, 0.0));
                let fine = noise3(normal * 41.0 + vec3(0.0, time * 0.027, 0.0));
                material.alpha * smoothstep(0.44, 0.68, broad * 0.58 + fine * 0.42)
            }
            ShaderKind::Corona => {
                let plasma = noise3(normal * 24.0 + vec3(time * 0.075, time * 0.035, 0.0));
                let arcs = (normal.y * 38.0 + normal.x * 11.0 + time * 0.16 + plasma * 5.0).sin().abs();
                material.alpha * smoothstep(0.30, 0.82, plasma * 0.72 + arcs * 0.28)
            }
            _ => material.alpha,
        }
    }

    /// Procedural CPU normal mapping. The height field is sampled in a tangent
    /// frame around the interpolated surface normal; it is independent of any
    /// source photograph and therefore covers the complete sphere continuously.
    fn map_normal(&self, material: Material, _uv: [f32; 2], n: Vec3, time: f32) -> Vec3 {
        if !material.detailed || material.normal_strength <= 0.0 {
            return n;
        }
        let mut tangent = normalize(cross(vec3(0.0, 1.0, 0.0), n));
        if length(tangent) < 0.01 {
            tangent = normalize(cross(vec3(1.0, 0.0, 0.0), n));
        }
        let bitangent = normalize(cross(n, tangent));
        let epsilon = 0.012;
        let height = |direction: Vec3| procedural_height(material.shader, normalize(direction), time);
        let center = height(n);
        let dx = (height(normalize(n + tangent * epsilon)) - center) / epsilon;
        let dy = (height(normalize(n + bitangent * epsilon)) - center) / epsilon;
        normalize(n - tangent * (dx * material.normal_strength * 0.18)
            - bitangent * (dy * material.normal_strength * 0.18))
    }

}

fn material_for(kind: PlanetKind, layer6: bool) -> Material {
    let mut material = match kind {
        PlanetKind::Mercury => Material::new(vec3(0.48, 0.46, 0.43), ShaderKind::Mercury),
        PlanetKind::Venus => Material::new(vec3(0.86, 0.64, 0.34), ShaderKind::Venus),
        PlanetKind::Earth => Material::new(vec3(0.22, 0.48, 0.78), ShaderKind::Earth).specular(0.42),
        PlanetKind::Moon => Material::new(vec3(0.55, 0.57, 0.58), ShaderKind::Moon),
        PlanetKind::Mars => Material::new(vec3(0.72, 0.29, 0.14), ShaderKind::Mars),
        PlanetKind::Jupiter => Material::new(vec3(0.72, 0.48, 0.31), ShaderKind::Jupiter).specular(0.24),
        PlanetKind::Saturn => Material::new(vec3(0.77, 0.66, 0.45), ShaderKind::Saturn).specular(0.22),
        PlanetKind::Uranus => Material::new(vec3(0.40, 0.74, 0.77), ShaderKind::Uranus).specular(0.28),
        PlanetKind::Neptune => Material::new(vec3(0.16, 0.29, 0.76), ShaderKind::Neptune).specular(0.38),
        PlanetKind::MillerWater => Material::new(vec3(0.05, 0.39, 0.67), ShaderKind::Miller).specular(0.92),
        PlanetKind::MannIce => Material::new(vec3(0.44, 0.56, 0.67), ShaderKind::Mann).specular(0.48),
        PlanetKind::EdmundHabitable => Material::new(vec3(0.28, 0.47, 0.27), ShaderKind::Edmund).specular(0.36),
        _ => Material::new(vec3(0.6, 0.6, 0.6), ShaderKind::Solid),
    };
    if layer6 {
        material = material.detailed(true).normal_strength(match kind {
            PlanetKind::MillerWater => 1.05,
            PlanetKind::MannIce | PlanetKind::Mercury | PlanetKind::Moon | PlanetKind::Mars => 1.25,
            PlanetKind::Earth | PlanetKind::EdmundHabitable => 0.78,
            PlanetKind::Jupiter | PlanetKind::Saturn | PlanetKind::Uranus | PlanetKind::Neptune => 0.48,
            _ => 0.65,
        });
    }
    material
}

fn sample_material_procedural(material: Material, uv: [f32; 2], normal: Vec3, _position: Vec3, time: f32) -> Vec3 {
    let n = normalize(normal);
    let u = uv[0];
    let v = uv[1];
    match material.shader {
        ShaderKind::Solid => material.base_color,
        ShaderKind::Mercury | ShaderKind::Moon => {
            let broad = fbm3(n * 13.0, 5);
            let mid = fbm3(n * 38.0, 4);
            let fine = fbm3(n * 106.0, 2);
            let crater_rims = 1.0 - (fbm3(n * 24.0, 3) * 2.0 - 1.0).abs();
            let pitted = broad * 0.42 + mid * 0.32 + fine * 0.12 + crater_rims * 0.14;
            let mineral = fbm3(n * 7.0 + vec3(8.0, 2.0, 5.0), 3);
            let base = if material.shader == ShaderKind::Moon {
                vec3(0.37, 0.39, 0.41)
            } else {
                vec3(0.34, 0.33, 0.31)
            };
            let bright = if material.shader == ShaderKind::Moon { 0.30 } else { 0.25 };
            base * (0.80 + pitted * bright + mineral * 0.10)
                + vec3(0.035, 0.032, 0.025) * smoothstep(0.78, 0.92, crater_rims)
        }
        ShaderKind::Venus => {
            let drift = vec3(time * 0.014, 0.0, -time * 0.009);
            let cloud_a = fbm3(n * 13.0 + drift, 5);
            let cloud_b = fbm3(n * 34.0 + drift * 1.6, 3);
            let bands = (n.y * 62.0 + fbm3(n * 8.0, 3) * 8.0 + time * 0.02).sin();
            let shade = cloud_a * 0.56 + cloud_b * 0.28 + (bands * 0.5 + 0.5) * 0.16;
            mix_color(vec3(0.48, 0.30, 0.16), vec3(0.96, 0.76, 0.48), shade.clamp(0.0, 1.0))
        }
        ShaderKind::Earth => {
            // Spherical 3D continental field: no UV projection, logos, borders or
            // black photographic background can enter the albedo.
            let warp = vec3(
                fbm3(n * 4.2 + vec3(3.1, 0.0, 1.7), 3) - 0.5,
                fbm3(n * 4.2 + vec3(8.4, 2.2, 0.0), 3) - 0.5,
                fbm3(n * 4.2 + vec3(0.0, 6.7, 4.2), 3) - 0.5,
            );
            let continental = fbm3(n * 4.0 + warp * 2.4, 5) * 0.74
                + fbm3(n * 10.0, 3) * 0.26;
            let land = smoothstep(0.475, 0.565, continental);
            let shelf = smoothstep(0.445, 0.515, continental) - land * 0.55;
            let ocean_noise = fbm3(n * 24.0, 4);
            let depth = (continental * 0.72 + ocean_noise * 0.28).clamp(0.0, 1.0);
            let ocean = mix_color(vec3(0.006, 0.035, 0.105), vec3(0.025, 0.20, 0.34), depth);
            let biome = fbm3(n * 8.5 + warp, 4);
            let detail = fbm3(n * 31.0, 4);
            let forest = mix_color(vec3(0.045, 0.13, 0.065), vec3(0.16, 0.31, 0.105), biome);
            let dry = mix_color(vec3(0.29, 0.22, 0.12), vec3(0.63, 0.47, 0.26), detail);
            let vegetation = smoothstep(0.24, 0.76, biome);
            let land_color = mix_color(dry, forest, vegetation);
            let ridges = 1.0 - (fbm3(n * 17.0, 4) * 2.0 - 1.0).abs();
            let mountains = smoothstep(0.76, 0.96, ridges) * land;
            let polar = smoothstep(0.78, 0.97, n.y.abs());
            let land_color = mix_color(land_color, vec3(0.72, 0.73, 0.68), mountains * 0.72);
            let land_color = mix_color(land_color, vec3(0.82, 0.88, 0.91), polar * land * 0.92);
            let ocean_color = mix_color(ocean, vec3(0.035, 0.25, 0.34), shelf.clamp(0.0, 1.0) * 0.42);
            let surface = mix_color(ocean_color, land_color, land);
            mix_color(surface, vec3(0.12, 0.25, 0.26), shelf.clamp(0.0, 1.0) * 0.14)
        }
        ShaderKind::Edmund => {
            // A separate habitable exoplanet palette: dark teal oceans, dense
            // forest continents, ochre highlands and polar cloud/ice regions.
            let warp = vec3(fbm3(n * 3.8, 4) - 0.5, fbm3(n * 5.2 + vec3(4.0, 0.0, 3.0), 3) - 0.5,
                fbm3(n * 4.4 + vec3(0.0, 6.0, 1.0), 3) - 0.5);
            let continents = fbm3(n * 3.7 + warp * 2.0, 5) * 0.72 + fbm3(n * 11.0, 3) * 0.28;
            let land = smoothstep(0.48, 0.57, continents);
            let ocean_noise = fbm3(n * 25.0, 3);
            let ocean = mix_color(vec3(0.008, 0.055, 0.13), vec3(0.025, 0.24, 0.30), ocean_noise);
            let vegetation = fbm3(n * 13.0 + warp, 4);
            let forest = mix_color(vec3(0.025, 0.12, 0.075), vec3(0.12, 0.34, 0.17), vegetation);
            let highlands = smoothstep(0.72, 0.92, fbm3(n * 28.0, 3));
            let land_color = mix_color(forest, vec3(0.40, 0.31, 0.19), highlands * 0.66);
            let polar = smoothstep(0.81, 0.98, n.y.abs()) * land;
            mix_color(mix_color(ocean, land_color, land), vec3(0.78, 0.86, 0.89), polar * 0.86)
        }
        ShaderKind::Miller => {
            // All-ocean planet. Intersecting swell systems are evaluated in 3D
            // and advected independently, so waves continue around the limb.
            let long_swell = (dot(n, vec3(16.0, 8.0, 27.0)) + time * 0.48
                + fbm3(n * 7.0, 3) * 3.2).sin();
            let cross_swell = (dot(n, vec3(-24.0, 5.0, 18.0)) - time * 0.34
                + fbm3(n * 13.0, 3) * 2.1).sin();
            let capillary = (dot(n, vec3(71.0, -19.0, 43.0)) + time * 0.92).sin();
            let wave = long_swell * 0.43 + cross_swell * 0.39 + capillary * 0.18;
            let depth = fbm3(n * 8.0, 4);
            let ocean = mix_color(vec3(0.006, 0.055, 0.16), vec3(0.015, 0.25, 0.40), depth);
            let crest = smoothstep(0.43, 0.93, wave * 0.5 + 0.5);
            let foam = smoothstep(0.76, 0.98, wave * 0.5 + 0.5 + fbm3(n * 42.0, 2) * 0.12);
            mix_color(ocean, vec3(0.14, 0.53, 0.66), crest * 0.46)
                + vec3(0.10, 0.17, 0.18) * foam * 0.42
        }
        ShaderKind::Mann => {
            // Blue-grey permafrost, exposed fractured stone and translucent ice.
            let broad = fbm3(n * 9.0, 5);
            let stone = fbm3(n * 27.0, 4);
            let grain = fbm3(n * 92.0, 2);
            let strata = (dot(n, vec3(11.0, 31.0, -7.0)) + fbm3(n * 12.0, 3) * 3.0).sin().abs();
            let rock = mix_color(vec3(0.12, 0.19, 0.25), vec3(0.38, 0.43, 0.47), stone * 0.68 + broad * 0.32);
            let ice_mask = smoothstep(0.38, 0.71, fbm3(n * 12.0 + vec3(1.7, 0.0, 2.4), 4));
            let ice = mix_color(vec3(0.36, 0.54, 0.66), vec3(0.83, 0.91, 0.96), grain);
            let cracks = smoothstep(0.83, 0.97, 1.0 - strata) * ice_mask;
            mix_color(rock, ice, ice_mask * 0.82) + vec3(0.09, 0.13, 0.16) * cracks * 0.42
        }
        ShaderKind::Mars => {
            let mineral = fbm3(n * 7.5, 5);
            let dunes = fbm3(n * 25.0, 4);
            let fine = fbm3(n * 88.0, 2);
            let ridges = 1.0 - (fbm3(n * 18.0, 3) * 2.0 - 1.0).abs();
            let dust = mix_color(vec3(0.23, 0.075, 0.035), vec3(0.72, 0.29, 0.12), mineral);
            let basalt = vec3(0.17, 0.12, 0.105) * smoothstep(0.69, 0.96, ridges);
            let polar = smoothstep(0.90, 0.99, n.y.abs());
            mix_color(dust, vec3(0.77, 0.70, 0.58), polar * 0.86) + basalt * 0.36
                + vec3(0.08, 0.035, 0.018) * dunes * fine * 0.18
        }
        ShaderKind::Jupiter => {
            let turbulence = fbm3(n * 18.0 + vec3(0.0, time * 0.004, 0.0), 4);
            let latitude = n.y + (turbulence - 0.5) * 0.105;
            let band = (latitude * 112.0 + fbm3(n * 31.0, 3) * 7.0).sin();
            let band_mask = band * 0.5 + 0.5;
            let bands = mix_color(vec3(0.36, 0.22, 0.14), vec3(0.84, 0.68, 0.48), band_mask);
            let turbulence_color = mix_color(vec3(0.43, 0.31, 0.23), vec3(0.91, 0.77, 0.61), turbulence);
            let mut cloud = mix_color(bands, turbulence_color, 0.34);
            let dx = (n.x - 0.28) * 10.0;
            let dy = (n.y - 0.18) * 18.0;
            let storm_r = (dx * dx + dy * dy).sqrt();
            let storm_ring = (storm_r * 5.6 + n.z * 3.0 + time * 0.03).sin();
            let storm = (-storm_r * 1.7).exp() * (0.72 + storm_ring * 0.18);
            cloud = mix_color(cloud, vec3(0.66, 0.20, 0.095), storm.clamp(0.0, 0.9));
            cloud + vec3(0.055, 0.035, 0.025) * fbm3(n * 66.0, 2) * 0.12
        }
        ShaderKind::Saturn => {
            let turbulence = fbm3(n * 16.0, 4);
            let latitude = n.y + (turbulence - 0.5) * 0.035;
            let band = (latitude * 74.0 + fbm3(n * 29.0, 3) * 3.2).sin() * 0.5 + 0.5;
            let cream = mix_color(vec3(0.43, 0.34, 0.24), vec3(0.83, 0.72, 0.54), band);
            let polar = smoothstep(0.82, 0.99, n.y.abs());
            mix_color(cream, vec3(0.72, 0.69, 0.58), polar * 0.48)
                + vec3(0.07, 0.045, 0.025) * fbm3(n * 74.0, 2) * 0.10
        }
        ShaderKind::Uranus => {
            let haze = fbm3(n * 13.0 + vec3(0.0, time * 0.002, 0.0), 4);
            let band = (n.y * 34.0 + fbm3(n * 22.0, 3) * 2.8).sin() * 0.5 + 0.5;
            mix_color(vec3(0.17, 0.48, 0.59), vec3(0.52, 0.83, 0.85), haze * 0.48 + band * 0.52)
        }
        ShaderKind::Neptune => {
            let haze = fbm3(n * 14.0 + vec3(time * 0.002, 0.0, 0.0), 4);
            let latitude = n.y + (haze - 0.5) * 0.055;
            let band = (latitude * 51.0 + fbm3(n * 31.0, 3) * 4.8).sin() * 0.5 + 0.5;
            let base = mix_color(vec3(0.025, 0.12, 0.39), vec3(0.09, 0.38, 0.77), band * 0.58 + haze * 0.42);
            let storm_d = (((n.x + 0.28) * 8.0).powi(2) + ((n.y - 0.14) * 14.0).powi(2)).sqrt();
            let storm = (-storm_d * 1.45).exp();
            mix_color(base, vec3(0.018, 0.055, 0.19), storm * 0.72)
        }
        ShaderKind::Sun => {
            let drift = vec3(time * 0.035, -time * 0.014, time * 0.022);
            let granulation = fbm3(n * 82.0 + drift, 4);
            let supergranules = fbm3(n * 23.0 + drift * 0.4, 3);
            let filaments = 1.0 - (fbm3(n * 57.0 + drift * 1.7, 3) * 2.0 - 1.0).abs();
            let heat = (granulation * 0.46 + supergranules * 0.32 + filaments * 0.22).clamp(0.0, 1.0);
            mix_color(vec3(0.65, 0.12, 0.018), vec3(1.0, 0.88, 0.48), heat)
        }
        ShaderKind::Wormhole => {
            // Preserve the original cyan engine plume material used by the ship.
            let pulse = 0.72 + 0.28 * (time * 2.4 + u * 18.0).sin().abs();
            vec3(0.20 * pulse, 0.68 * pulse, 1.0 * pulse)
        }
        ShaderKind::CrystalWormhole => {
            // Dense 3D nebula volume plus a clearly readable spiral galaxy.
            // This is deliberately not sampled from wormhole.jpeg.
            let drift = vec3(time * 0.018, -time * 0.011, time * 0.014);
            let cloud_a = fbm3(n * 8.0 + drift, 5);
            let cloud_b = fbm3(n * 22.0 - drift * 1.7, 4);
            let cloud_c = fbm3(n * 57.0 + drift * 2.1, 2);
            let nebula_density = (cloud_a * 0.55 + cloud_b * 0.31 + cloud_c * 0.14).clamp(0.0, 1.0);
            let radial = (n.x * n.x * 0.92 + n.y * n.y * 1.12).sqrt();
            let angle = n.y.atan2(n.x);
            let spiral_noise = fbm3(n * 13.0 + vec3(3.0, 0.0, time * 0.008), 3);
            let arms = (angle * 3.0 - radial * 20.0 + spiral_noise * 4.5 + time * 0.13).cos();
            let arm_density = smoothstep(0.18, 0.94, arms) * (-radial * 1.65).exp();
            let core = (-radial * 8.5).exp();
            let dust_lane = smoothstep(0.54, 0.86, fbm3(n * 31.0, 3)) * arm_density;
            let violet_cloud = vec3(0.24, 0.13, 0.52) * nebula_density;
            let blue_cloud = vec3(0.045, 0.30, 0.62) * (1.0 - nebula_density * 0.28);
            let pink_cloud = vec3(0.47, 0.13, 0.37) * smoothstep(0.61, 0.84, cloud_b);
            let star_specks = smoothstep(0.955, 0.992, fbm3(n * 96.0 + vec3(9.0, 2.0, 4.0), 2));
            let base = vec3(0.006, 0.012, 0.035) + violet_cloud * 0.58 + blue_cloud * 0.48 + pink_cloud * 0.34;
            let arms_color = vec3(0.27, 0.56, 0.92) * arm_density * (1.0 - dust_lane * 0.60);
            let nucleus = vec3(1.0, 0.72, 0.40) * core * 0.92;
            base + arms_color + nucleus + vec3(0.35, 0.64, 1.0) * star_specks * 0.75
        }
        ShaderKind::WormholeGlass => vec3(0.28, 0.58, 0.88),
        ShaderKind::Ring => {
            let stripe = (v * 90.0).sin() * 0.08;
            let radius_pattern = (u * 9.0).sin() * 0.04;
            vec3(0.73 + stripe, 0.63 + stripe + radius_pattern, 0.47 + stripe)
        }
        ShaderKind::AccretionDisc => {
            let band = (n.y * 42.0 + time * 0.3 + n.x * 6.0).sin();
            let heat = (0.76 + band * 0.18).clamp(0.2, 1.0);
            vec3(1.0 * heat, 0.34 + 0.34 * heat, 0.10 + 0.18 * heat)
        }
        ShaderKind::Rock => {
            let variation = noise3(n * 0.055) + noise3(n * 0.17) * 0.28;
            material.base_color * (0.62 + variation * 0.72)
        }
        ShaderKind::Atmosphere => material.base_color,
        ShaderKind::Clouds => {
            let drift = vec3(time * 0.018, 0.0, -time * 0.012);
            let broad = fbm3(n * 8.5 + drift, 4);
            let fine = fbm3(n * 31.0 + drift * 1.8, 3);
            vec3(0.70, 0.80, 0.91) * (0.35 + smoothstep(0.42, 0.78, broad * 0.7 + fine * 0.3) * 0.78)
        }
        ShaderKind::Corona => {
            let filament = fbm3(n * 31.0 + vec3(time * 0.08, time * 0.035, 0.0), 3);
            let arcs = (n.y * 35.0 + noise3(n * 12.0) * 4.0 + time * 0.18).sin().abs();
            let plasma = (filament * 0.72 + arcs * 0.28).clamp(0.0, 1.0);
            vec3(1.0, 0.24 + plasma * 0.42, 0.025 + plasma * 0.15)
        }
    }
}

fn procedural_height(shader: ShaderKind, n: Vec3, time: f32) -> f32 {
    match shader {
        ShaderKind::Miller => {
            (dot(n, vec3(16.0, 8.0, 27.0)) + time * 0.48).sin() * 0.34
                + (dot(n, vec3(-24.0, 5.0, 18.0)) - time * 0.34).sin() * 0.28
                + fbm3(n * 42.0, 2) * 0.18
        }
        ShaderKind::Mann => fbm3(n * 17.0, 4) * 0.55 + fbm3(n * 64.0, 3) * 0.24,
        ShaderKind::Earth | ShaderKind::Edmund => fbm3(n * 7.0, 4) * 0.35 + fbm3(n * 36.0, 3) * 0.18,
        ShaderKind::Jupiter | ShaderKind::Saturn | ShaderKind::Uranus | ShaderKind::Neptune => fbm3(n * 23.0, 3) * 0.18,
        ShaderKind::Wormhole | ShaderKind::CrystalWormhole | ShaderKind::WormholeGlass => fbm3(n * 33.0, 3) * 0.08,
        ShaderKind::Sun => fbm3(n * 72.0, 3) * 0.24,
        _ => fbm3(n * 28.0, 4) * 0.32 + fbm3(n * 84.0, 2) * 0.12,
    }
}

fn fbm3(mut point: Vec3, octaves: usize) -> f32 {
    let mut total = 0.0;
    let mut amplitude = 0.5;
    let mut normalization = 0.0;
    for _ in 0..octaves.max(1) {
        total += noise3(point) * amplitude;
        normalization += amplitude;
        point = point * 2.03 + vec3(11.7, 7.3, 5.9);
        amplitude *= 0.5;
    }
    if normalization > 0.0 { total / normalization } else { 0.5 }
}

fn mix_color(a: Vec3, b: Vec3, t: f32) -> Vec3 {
    a + (b - a) * t.clamp(0.0, 1.0)
}

fn edge(ax: f32, ay: f32, bx: f32, by: f32, px: f32, py: f32) -> f32 {
    (px - ax) * (by - ay) - (py - ay) * (bx - ax)
}

fn project_point(point: Vec3, vp: Mat4, width: usize, height: usize) -> Option<(i32, i32, f32)> {
    let clip = vp.transform_vec4([point.x, point.y, point.z, 1.0]);
    if clip[3] <= 0.1 {
        return None;
    }
    let inv_w = 1.0 / clip[3];
    let ndc_x = clip[0] * inv_w;
    let ndc_y = clip[1] * inv_w;
    let ndc_z = clip[2] * inv_w;
    if !(-1.2..=1.2).contains(&ndc_x) || !(-1.2..=1.2).contains(&ndc_y) {
        return None;
    }
    let x = ((ndc_x * 0.5 + 0.5) * width as f32) as i32;
    let y = ((0.5 - ndc_y * 0.5) * height as f32) as i32;
    Some((x, y, ndc_z))
}

fn make_stars(count: usize) -> Vec<Star> {
    let mut rng = SimpleRng::new(1901);
    let mut stars = Vec::with_capacity(count);
    for _ in 0..count {
        // A broad galactic band sits on top of a truly all-sky distribution.
        // This gives the background depth without creating a single flat stripe.
        let (x, y, z) = if rng.next() < 0.46 {
            let latitude = rng.range(-0.19, 0.19);
            let angle = rng.range(0.0, std::f32::consts::TAU);
            let radius = (1.0 - latitude * latitude).sqrt();
            (radius * angle.cos(), latitude, radius * angle.sin())
        } else {
            let vertical = rng.range(-1.0, 1.0);
            let angle = rng.range(0.0, std::f32::consts::TAU);
            let radial = (1.0 - vertical * vertical).max(0.0).sqrt();
            (radial * angle.cos(), vertical, radial * angle.sin())
        };
        let direction = vec3(x, y, z);
        let roll = rng.next();
        let color = if roll > 0.985 {
            color_from_f32(0.62, 0.78, 1.0)
        } else if roll > 0.955 {
            color_from_f32(0.50, 0.88, 1.0)
        } else if roll > 0.91 {
            color_from_f32(1.0, 0.78, 0.57)
        } else if roll > 0.82 {
            color_from_f32(1.0, 0.91, 0.78)
        } else {
            0xE6EDFF
        };
        let size_roll = rng.next();
        stars.push(Star {
            direction,
            color,
            radius: if size_roll > 0.996 { 2 } else if size_roll > 0.965 { 1 } else { 0 },
            twinkle_phase: rng.range(0.0, std::f32::consts::TAU),
            twinkle_amount: rng.range(0.015, 0.11),
        });
    }
    stars
}

fn make_nebulae() -> Vec<Nebula> {
    vec![
        Nebula { direction: normalize(vec3(-0.62, 0.24, -0.74)), color: vec3(0.24, 0.28, 0.92), radius: 145, seed: 2.1, galaxy: false },
        Nebula { direction: normalize(vec3(0.38, 0.48, -0.79)), color: vec3(0.72, 0.19, 0.54), radius: 125, seed: 5.7, galaxy: false },
        Nebula { direction: normalize(vec3(0.82, -0.19, -0.54)), color: vec3(0.12, 0.48, 0.68), radius: 110, seed: 8.4, galaxy: false },
        Nebula { direction: normalize(vec3(-0.18, -0.58, -0.79)), color: vec3(0.66, 0.31, 0.17), radius: 92, seed: 11.2, galaxy: false },
        Nebula { direction: normalize(vec3(-0.88, -0.12, 0.42)), color: vec3(0.20, 0.36, 0.82), radius: 80, seed: 14.8, galaxy: false },
        Nebula { direction: normalize(vec3(0.15, 0.82, 0.55)), color: vec3(0.42, 0.18, 0.72), radius: 118, seed: 18.0, galaxy: false },
        Nebula { direction: normalize(vec3(-0.44, 0.64, 0.61)), color: vec3(0.13, 0.52, 0.76), radius: 104, seed: 22.7, galaxy: false },
        Nebula { direction: normalize(vec3(0.61, -0.67, 0.42)), color: vec3(0.72, 0.24, 0.31), radius: 96, seed: 26.4, galaxy: false },
        Nebula { direction: normalize(vec3(-0.12, 0.36, 0.93)), color: vec3(0.32, 0.20, 0.68), radius: 88, seed: 29.1, galaxy: false },
        Nebula { direction: normalize(vec3(0.72, 0.18, 0.67)), color: vec3(0.82, 0.52, 0.24), radius: 56, seed: 4.3, galaxy: true },
        Nebula { direction: normalize(vec3(-0.32, 0.12, 0.94)), color: vec3(0.36, 0.68, 0.92), radius: 43, seed: 9.1, galaxy: true },
        Nebula { direction: normalize(vec3(0.14, -0.78, -0.60)), color: vec3(0.72, 0.38, 0.72), radius: 37, seed: 13.5, galaxy: true },
        Nebula { direction: normalize(vec3(-0.74, 0.53, -0.41)), color: vec3(0.56, 0.72, 0.96), radius: 31, seed: 17.3, galaxy: true },
        Nebula { direction: normalize(vec3(0.92, 0.22, -0.31)), color: vec3(0.94, 0.62, 0.34), radius: 27, seed: 21.9, galaxy: true },
    ]
}

fn make_asteroids() -> Vec<(Vec3, Vec3, f32)> {
    let mut rng = SimpleRng::new(7331);
    let mut rocks = Vec::with_capacity(900);
    let inner = ASTEROID_BELT_INNER_AU * AU_SCALE;
    let outer = ASTEROID_BELT_OUTER_AU * AU_SCALE;
    let golden_angle = 2.399_963_1_f32;

    // Even angular spacing with a little deterministic jitter avoids the
    // accidental clumps and empty sectors of a small random sample.
    for index in 0..900 {
        let angle = index as f32 * golden_angle + rng.range(-0.045, 0.045);
        // Uniform density by annular area rather than by radius.
        let radius = (inner * inner + rng.next() * (outer * outer - inner * inner)).sqrt();
        let y = rng.range(-180.0, 180.0);
        let position = vec3(angle.cos() * radius, y, angle.sin() * radius);
        // Most rocks remain small, with a few medium and very large bodies
        // breaking up the silhouette of the belt.
        let size = if index % 83 == 0 {
            rng.range(68.0, 110.0)
        } else if index % 13 == 0 {
            rng.range(34.0, 58.0)
        } else {
            rng.range(8.0, 24.0)
        };
        let shape = vec3(
            size * rng.range(0.72, 1.28),
            size * rng.range(0.58, 1.08),
            size * rng.range(0.70, 1.35),
        );
        let rotation = rng.range(0.0, std::f32::consts::TAU);
        rocks.push((position, shape, rotation));
    }
    rocks
}

struct SimpleRng {
    state: u64,
}

impl SimpleRng {
    fn new(seed: u64) -> Self { Self { state: seed.max(1) } }

    fn next(&mut self) -> f32 {
        self.state ^= self.state << 13;
        self.state ^= self.state >> 7;
        self.state ^= self.state << 17;
        (self.state as u32) as f32 / u32::MAX as f32
    }

    fn range(&mut self, min: f32, max: f32) -> f32 {
        min + (max - min) * self.next()
    }
}

fn hash3(x: i32, y: i32, z: i32) -> f32 {
    let mut n = x.wrapping_mul(374761393)
        .wrapping_add(y.wrapping_mul(668265263))
        .wrapping_add(z.wrapping_mul(2147483647));
    n = (n ^ (n >> 13)).wrapping_mul(1274126177);
    let value = n ^ (n >> 16);
    (value as u32) as f32 / u32::MAX as f32
}

fn fade(value: f32) -> f32 { value * value * (3.0 - 2.0 * value) }

fn noise3(point: Vec3) -> f32 {
    let x0 = point.x.floor() as i32;
    let y0 = point.y.floor() as i32;
    let z0 = point.z.floor() as i32;
    let fx = fade(point.x - x0 as f32);
    let fy = fade(point.y - y0 as f32);
    let fz = fade(point.z - z0 as f32);

    let c000 = hash3(x0, y0, z0);
    let c100 = hash3(x0 + 1, y0, z0);
    let c010 = hash3(x0, y0 + 1, z0);
    let c110 = hash3(x0 + 1, y0 + 1, z0);
    let c001 = hash3(x0, y0, z0 + 1);
    let c101 = hash3(x0 + 1, y0, z0 + 1);
    let c011 = hash3(x0, y0 + 1, z0 + 1);
    let c111 = hash3(x0 + 1, y0 + 1, z0 + 1);

    let x00 = c000 + (c100 - c000) * fx;
    let x10 = c010 + (c110 - c010) * fx;
    let x01 = c001 + (c101 - c001) * fx;
    let x11 = c011 + (c111 - c011) * fx;
    let y0_value = x00 + (x10 - x00) * fy;
    let y1_value = x01 + (x11 - x01) * fy;
    y0_value + (y1_value - y0_value) * fz
}


#[cfg(test)]
mod asteroid_tests {
    use super::*;

    #[test]
    fn gargantua_disk_stops_1600_units_before_millers_orbit() {
        use crate::game::{GARGANTUA_DISK_ORBIT_GAP, GARGANTUA_DISK_RADIUS, GARGANTUA_MILLER_ORBIT};
        assert!((GARGANTUA_MILLER_ORBIT - GARGANTUA_DISK_RADIUS - GARGANTUA_DISK_ORBIT_GAP).abs() < 0.001);
    }

    #[test]
    fn inner_asteroids_have_shorter_periods_than_outer_asteroids() {
        let period = |radius_au: f32| 300.0 * radius_au.powf(1.5);
        assert!(period(ASTEROID_BELT_INNER_AU) < period(ASTEROID_BELT_OUTER_AU));
    }

    #[test]
    fn procedural_surface_fields_are_finite_for_multiple_directions() {
        let directions = [
            vec3(1.0, 0.0, 0.0),
            vec3(0.0, 1.0, 0.0),
            vec3(0.0, 0.0, -1.0),
            normalize(vec3(0.31, -0.77, 0.55)),
        ];
        let shaders = [
            ShaderKind::Earth, ShaderKind::Edmund, ShaderKind::Miller,
            ShaderKind::Mann, ShaderKind::Jupiter, ShaderKind::CrystalWormhole,
        ];
        for shader in shaders {
            let material = Material::new(vec3(0.5, 0.5, 0.5), shader).detailed(true);
            for direction in directions {
                let color = sample_material_procedural(material, [0.37, 0.61], direction, vec3(0.0, 0.0, 0.0), 12.0);
                assert!(color.x.is_finite() && color.y.is_finite() && color.z.is_finite());
                let height = procedural_height(shader, direction, 12.0);
                assert!(height.is_finite());
            }
        }
    }

    #[test]
    fn asteroid_field_covers_the_full_orbital_annulus() {
        let asteroids = make_asteroids();
        assert_eq!(asteroids.len(), 900);
        let inner = ASTEROID_BELT_INNER_AU * AU_SCALE;
        let outer = ASTEROID_BELT_OUTER_AU * AU_SCALE;
        let mut angular_bins = [0usize; 36];

        for (offset, _, _) in asteroids {
            let radius = (offset.x * offset.x + offset.z * offset.z).sqrt();
            assert!(radius >= inner && radius <= outer);
            let angle = offset.z.atan2(offset.x).rem_euclid(std::f32::consts::TAU);
            let bin = ((angle / std::f32::consts::TAU) * angular_bins.len() as f32) as usize;
            angular_bins[bin.min(angular_bins.len() - 1)] += 1;
        }

        // Every ten-degree sector must contain rocks; the belt cannot collapse
        // into the short visible arc from the previous implementation.
        assert!(angular_bins.iter().all(|count| *count >= 10));
    }
}
