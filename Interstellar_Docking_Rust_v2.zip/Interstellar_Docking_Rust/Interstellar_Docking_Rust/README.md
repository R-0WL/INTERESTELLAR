# INTERSTELLAR // Docking Maneuver (Rust + Bevy)

Minijuego 3D de acoplamiento orbital inspirado en la secuencia de docking de *Interstellar*. Incluye los modelos GLB proporcionados en el ZIP de referencia.

## Características

- **Endurance a -68.0 RPM exactas**, giro hacia la izquierda. La velocidad se calcula como `-68 × 2π / 60` rad/s.
- Control de giro del Lander con aceleración angular: A / flecha izquierda para acelerar hacia la izquierda y D / flecha derecha para corregir hacia la derecha.
- Control vertical del Lander con W / flecha arriba y S / flecha abajo.
- Acercamiento final con E. El avance se pausa automáticamente hasta que el error de RPM, la fase angular y la altura están dentro del margen seguro.
- Telemetría superior derecha: RPM del Endurance y del Lander, error de giro, alineación, error de fase, altura, distancia, velocidad lineal relativa, velocidad vertical, estado y cámara.
- Monitor secundario inferior izquierdo con dial circular. Su escala visual convierte la referencia principal de 68 RPM a **15 RPM** usando `15 / 68`; el porcentaje de alineación procede de la simulación principal, no de una física separada.
- Cámara automática con cambios de encuadre exterior, seguimiento y primer plano del puerto. C permite recorrer los modos manuales.
- Estado de acoplamiento completado o contacto incorrecto, más reinicio.

## Controles

| Tecla | Acción |
|---|---|
| A / ← | Acelerar el giro del Lander hacia la izquierda |
| D / → | Corregir el giro hacia la derecha |
| W / ↑ | Subir el Lander |
| S / ↓ | Bajar el Lander |
| E | Activar / pausar el acercamiento final |
| C | Cambiar cámara: automática, exterior, seguimiento, puerto |
| R | Reiniciar la maniobra |

## Ejecutar

Se requiere Rust **1.97.1 o superior** y Cargo (requisito declarado por Bevy 0.20.1). Desde esta carpeta:

```bash
cargo run --release
```

Para ejecutar las pruebas unitarias:

```bash
cargo test
```

La primera compilación descarga las dependencias de Bevy desde crates.io. En Windows, si el entorno de compilación gráfico no está preparado, instala primero las herramientas de compilación recomendadas por Rust/Bevy.

## Estructura

```text
Interstellar_Docking_Rust/
├── Cargo.toml
├── README.md
├── src/
│   └── main.rs
├── assets/
│   └── models/
│       ├── endurance.glb
│       └── lander.glb
└── references/
    └── docking_hud_reference.jpg
```

El video de referencia no se duplica dentro del proyecto para evitar añadir casi 100 MB redundantes. Los dos modelos 3D y la imagen de referencia sí están incluidos.

## Notas de implementación

- El proyecto usa **Bevy 0.20.1**.
- Se asume el eje longitudinal X del Endurance y se orienta el Lander desde su eje local Z hacia +X para aproximarse al puerto frontal. Si al ejecutar los GLB aparece un giro u orientación distinta por cómo se exportaron los modelos, los ajustes de orientación están centralizados en `setup_scene` y `update_scene_transforms`.
- La escala del Lander, el desplazamiento de su nariz y la coordenada X del puerto están declarados como constantes al inicio de `src/main.rs` para facilitar la calibración visual.
- Este proyecto es una recreación jugable inspirada en la escena y utiliza los recursos suministrados por el usuario; no incluye audio ni pretende ser una reproducción exacta del montaje cinematográfico. Comprueba las licencias originales de los modelos antes de redistribuir el proyecto.
