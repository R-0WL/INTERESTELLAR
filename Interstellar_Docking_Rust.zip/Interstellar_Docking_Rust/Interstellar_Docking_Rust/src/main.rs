use bevy::{prelude::*, text::FontSize};
use std::f32::consts::{FRAC_PI_2, TAU};

const ENDURANCE_RPM: f32 = -68.0; // Negativo = giro a la izquierda.
const MONITOR_RPM: f32 = -15.0;
const TARGET_PORT_X: f32 = -10.8;
const LANDER_SCALE: f32 = 5.0;
const LANDER_NOSE_OFFSET: f32 = 0.74 * LANDER_SCALE;
const ROTATION_ACCEL_RPM_S: f32 = 220.0;
const VERTICAL_SPEED: f32 = 2.0;
const CLOSURE_SPEED: f32 = 0.75;

fn main() {
    App::new()
        .add_plugins(DefaultPlugins.set(WindowPlugin {
            primary_window: Some(Window {
                title: "INTERSTELLAR // DOCKING MANEUVER".to_string(),
                resolution: (1600, 900).into(),
                ..default()
            }),
            ..default()
        }))
        .insert_resource(ClearColor(Color::srgb(0.002, 0.004, 0.012)))
        .init_resource::<GameState>()
        .add_systems(Startup, (setup_scene, setup_hud))
        .add_systems(
            Update,
            (
                input_and_physics,
                update_scene_transforms,
                update_camera,
                update_hud,
            )
                .chain(),
        )
        .run();
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum GamePhase {
    Active,
    Docked,
    Collision,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum CameraMode {
    Automatic,
    Wide,
    Chase,
    Docking,
}

#[derive(Resource)]
struct GameState {
    elapsed: f32,
    endurance_angle: f32,
    lander_angle: f32,
    lander_rpm: f32,
    altitude: f32,
    distance: f32,
    approach_enabled: bool,
    vertical_speed: f32,
    phase: GamePhase,
    camera_mode: CameraMode,
}

impl Default for GameState {
    fn default() -> Self {
        Self {
            elapsed: 0.0,
            endurance_angle: 0.0,
            // Posición de fase inicial calculada para que la sincronización se alcance
            // al acelerar desde 0 hasta -68 RPM con A durante ~0.31 s.
            lander_angle: -63.0_f32.to_radians(),
            lander_rpm: 0.0,
            altitude: 2.0,
            distance: 22.0,
            approach_enabled: false,
            vertical_speed: 0.0,
            phase: GamePhase::Active,
            camera_mode: CameraMode::Automatic,
        }
    }
}

impl GameState {
    fn lander_position(&self) -> Vec3 {
        Vec3::new(
            TARGET_PORT_X - self.distance - LANDER_NOSE_OFFSET,
            self.altitude,
            0.0,
        )
    }

    fn phase_error_rad(&self) -> f32 {
        wrap_angle(self.lander_angle - self.endurance_angle)
    }

    fn rpm_error(&self) -> f32 {
        (self.lander_rpm - ENDURANCE_RPM).abs()
    }

    fn alignment_percent(&self) -> f32 {
        let speed_score = (1.0 - self.rpm_error() / 10.0).clamp(0.0, 1.0);
        let phase_score =
            (1.0 - self.phase_error_rad().abs() / 18.0_f32.to_radians()).clamp(0.0, 1.0);
        let height_score = (1.0 - self.altitude.abs() / 1.25).clamp(0.0, 1.0);
        (100.0 * (0.50 * speed_score + 0.35 * phase_score + 0.15 * height_score))
            .clamp(0.0, 100.0)
    }

    fn hard_lock(&self) -> bool {
        self.rpm_error() <= 0.8
            && self.phase_error_rad().abs() <= 2.0_f32.to_radians()
            && self.altitude.abs() <= 0.20
    }

    fn can_approach(&self) -> bool {
        self.alignment_percent() >= 84.0
            && self.rpm_error() <= 3.5
            && self.phase_error_rad().abs() <= 8.0_f32.to_radians()
            && self.altitude.abs() <= 0.65
    }

    fn closure_speed(&self) -> f32 {
        if self.approach_enabled && self.can_approach() && self.distance > 0.0 {
            CLOSURE_SPEED
        } else {
            0.0
        }
    }

    fn status_label(&self) -> &'static str {
        match self.phase {
            GamePhase::Docked => "DOCKING COMPLETE",
            GamePhase::Collision => "HULL CONTACT / ABORT",
            GamePhase::Active if self.approach_enabled && self.can_approach() => "FINAL APPROACH",
            GamePhase::Active if self.approach_enabled => "HOLD / ALIGNMENT REQUIRED",
            GamePhase::Active if self.hard_lock() => "TARGET LOCKED",
            GamePhase::Active => "TARGET UNLOCKED",
        }
    }
}

#[derive(Component)]
struct EndurancePivot;
#[derive(Component)]
struct LanderRoot;
#[derive(Component)]
struct MainCamera;
#[derive(Component)]
struct TargetMonitorRing;
#[derive(Component)]
struct LanderMonitorRing;
#[derive(Component)]
struct TelemetryLine(usize);
#[derive(Component)]
struct MiniLine(usize);

fn setup_scene(
    mut commands: Commands,
    asset_server: Res<AssetServer>,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
) {
    commands.spawn((
        Camera3d::default(),
        Transform::from_xyz(-72.0, 16.0, 29.0).looking_at(Vec3::new(-5.0, 0.0, 0.0), Vec3::Y),
        MainCamera,
    ));

    // La malla del Endurance está modelada alrededor de su eje longitudinal X.
    let endurance = commands
        .spawn((Transform::default(), Visibility::default(), EndurancePivot))
        .id();
    commands.entity(endurance).with_children(|parent| {
        parent.spawn(WorldAssetRoot(
            asset_server.load("models/endurance.glb#Scene0"),
        ));
    });

    // El modelo del Lander tiene su eje largo sobre Z; se orienta hacia +X,
    // en dirección al puerto frontal del Endurance.
    let lander = commands
        .spawn((
            Transform {
                translation: Vec3::new(
                    TARGET_PORT_X - 22.0 - LANDER_NOSE_OFFSET,
                    2.0,
                    0.0,
                ),
                rotation: Quat::from_rotation_y(FRAC_PI_2),
                scale: Vec3::splat(LANDER_SCALE),
            },
            Visibility::default(),
            LanderRoot,
        ))
        .id();
    commands.entity(lander).with_children(|parent| {
        parent.spawn(WorldAssetRoot(asset_server.load("models/lander.glb#Scene0")));
    });

    commands.spawn((
        DirectionalLight {
            illuminance: 14_000.0,
            shadow_maps_enabled: true,
            ..default()
        },
        Transform::from_rotation(Quat::from_euler(EulerRot::XYZ, -0.7, -0.6, -0.2)),
    ));
    commands.spawn((
        PointLight {
            intensity: 3_500_000.0,
            range: 150.0,
            shadow_maps_enabled: false,
            ..default()
        },
        Transform::from_xyz(-25.0, 22.0, 28.0),
    ));

    // Estrellas pequeñas, deterministas y repartidas en una esfera amplia.
    let star_mesh = meshes.add(Cuboid::new(0.055, 0.055, 0.055));
    let star_material = materials.add(StandardMaterial {
        base_color: Color::srgb(0.78, 0.86, 1.0),
        emissive: LinearRgba::new(0.7, 0.8, 1.0, 1.0),
        unlit: true,
        ..default()
    });
    let count = 260.0_f32;
    let golden_angle = 2.399_963_1_f32;
    for i in 0..260 {
        let fi = i as f32;
        let y = 1.0 - 2.0 * ((fi + 0.5) / count);
        let radius = (1.0 - y * y).sqrt();
        let theta = golden_angle * fi;
        let direction = Vec3::new(radius * theta.cos(), y, radius * theta.sin());
        let shell = 105.0 + ((i * 37) % 85) as f32;
        commands.spawn((
            Mesh3d(star_mesh.clone()),
            MeshMaterial3d(star_material.clone()),
            Transform::from_translation(direction * shell),
        ));
    }
}

fn setup_hud(mut commands: Commands) {
    // Panel principal de telemetría, esquina superior derecha.
    let stats_root = commands
        .spawn((
            Node {
                position_type: PositionType::Absolute,
                top: px(22),
                right: px(22),
                width: px(350),
                padding: UiRect::all(px(14)),
                border: UiRect::all(px(1)),
                flex_direction: FlexDirection::Column,
                ..default()
            },
            BackgroundColor(Color::srgba(0.015, 0.035, 0.055, 0.88)),
            BorderColor::all(Color::srgba(0.35, 0.78, 0.92, 0.75)),
            Text::new(""),
            TextFont {
                font_size: FontSize::Px(15.0),
                ..default()
            },
            TextColor(Color::srgb(0.78, 0.88, 0.92)),
        ))
        .id();
    commands.entity(stats_root).with_children(|parent| {
        parent.spawn((
            TextSpan::new("FLIGHT TELEMETRY  //  DOCK-01\n"),
            TextFont {
                font_size: FontSize::Px(17.0),
                ..default()
            },
            TextColor(Color::srgb(0.45, 0.86, 1.0)),
        ));
        let initial = [
            "ENDURANCE SPIN      -68.0 RPM  LEFT\n",
            "LANDER SPIN          +0.0 RPM\n",
            "SPIN ERROR            68.0 RPM\n",
            "ALIGNMENT              0.0 %\n",
            "PHASE ERROR          -63.0 deg\n",
            "ALTITUDE OFFSET       +2.00 m\n",
            "DOCKING DISTANCE      22.00 m\n",
            "RELATIVE SPEED         0.00 m/s\n",
            "VERTICAL RATE         -0.00 m/s\n",
            "STATUS                 TARGET UNLOCKED\n",
            "CAMERA                 AUTO / EXTERIOR\n",
        ];
        for (index, line) in initial.into_iter().enumerate() {
            parent.spawn((
                TextSpan::new(line),
                TextFont {
                    font_size: FontSize::Px(14.0),
                    ..default()
                },
                TextColor(if index == 9 {
                    Color::srgb(1.0, 0.72, 0.34)
                } else {
                    Color::srgb(0.78, 0.88, 0.92)
                }),
                TelemetryLine(index),
            ));
        }
    });

    // Ventana secundaria de docking: el aro del Endurance se representa a 15 RPM.
    let monitor_root = commands
        .spawn((
            Node {
                position_type: PositionType::Absolute,
                left: px(22),
                bottom: px(22),
                width: px(430),
                height: px(222),
                padding: UiRect::all(px(12)),
                border: UiRect::all(px(1)),
                flex_direction: FlexDirection::Column,
                row_gap: px(8),
                ..default()
            },
            BackgroundColor(Color::srgba(0.015, 0.035, 0.055, 0.90)),
            BorderColor::all(Color::srgba(0.35, 0.78, 0.92, 0.75)),
        ))
        .id();

    commands.entity(monitor_root).with_children(|panel| {
        panel.spawn((
            Text::new("DOCKING CAMERA  //  MONITOR SCALE 15 RPM"),
            TextFont {
                font_size: FontSize::Px(14.0),
                ..default()
            },
            TextColor(Color::srgb(0.45, 0.86, 1.0)),
        ));

        panel
            .spawn(Node {
                flex_direction: FlexDirection::Row,
                align_items: AlignItems::Center,
                column_gap: px(16),
                flex_grow: 1.0,
                ..default()
            })
            .with_children(|row| {
                // Dial exterior (objetivo a -15 RPM).
                row.spawn(Node {
                    width: px(156),
                    height: px(156),
                    position_type: PositionType::Relative,
                    ..default()
                })
                .with_children(|dial| {
                    dial.spawn((
                        Node {
                            position_type: PositionType::Absolute,
                            left: px(7),
                            top: px(7),
                            width: px(142),
                            height: px(142),
                            border: UiRect::all(px(2)),
                            border_radius: BorderRadius::MAX,
                            ..default()
                        },
                        BorderColor::all(Color::srgb(0.24, 0.82, 1.0)),
                        UiTransform::default(),
                        TargetMonitorRing,
                    ))
                    .with_children(|ring| {
                        ring.spawn((
                            Node {
                                position_type: PositionType::Absolute,
                                left: px(66),
                                top: px(1),
                                width: px(6),
                                height: px(17),
                                border_radius: BorderRadius::MAX,
                                ..default()
                            },
                            BackgroundColor(Color::srgb(0.24, 0.82, 1.0)),
                        ));
                    });
                    dial.spawn((
                        Node {
                            position_type: PositionType::Absolute,
                            left: px(28),
                            top: px(28),
                            width: px(100),
                            height: px(100),
                            border: UiRect::all(px(2)),
                            border_radius: BorderRadius::MAX,
                            ..default()
                        },
                        BorderColor::all(Color::srgb(1.0, 0.63, 0.30)),
                        UiTransform::default(),
                        LanderMonitorRing,
                    ))
                    .with_children(|ring| {
                        ring.spawn((
                            Node {
                                position_type: PositionType::Absolute,
                                left: px(45),
                                top: px(2),
                                width: px(6),
                                height: px(14),
                                border_radius: BorderRadius::MAX,
                                ..default()
                            },
                            BackgroundColor(Color::srgb(1.0, 0.63, 0.30)),
                        ));
                    });
                    dial.spawn((
                        Node {
                            position_type: PositionType::Absolute,
                            left: px(73),
                            top: px(73),
                            width: px(10),
                            height: px(10),
                            border_radius: BorderRadius::MAX,
                            ..default()
                        },
                        BackgroundColor(Color::WHITE),
                    ));
                    dial.spawn((
                        Text::new("+"),
                        TextFont {
                            font_size: FontSize::Px(18.0),
                            ..default()
                        },
                        TextColor(Color::srgb(0.72, 0.85, 0.90)),
                        Node {
                            position_type: PositionType::Absolute,
                            left: px(74),
                            top: px(63),
                            ..default()
                        },
                    ));
                });

                row.spawn((
                    Node {
                        flex_direction: FlexDirection::Column,
                        justify_content: JustifyContent::Center,
                        row_gap: px(5),
                        flex_grow: 1.0,
                        ..default()
                    },
                    Text::new(""),
                    TextFont {
                        font_size: FontSize::Px(13.0),
                        ..default()
                    },
                    TextColor(Color::srgb(0.78, 0.88, 0.92)),
                ))
                .with_children(|text_parent| {
                    let mini_initial = [
                        "TARGET   -15.0 RPM\n",
                        "LANDER    +0.0 RPM\n",
                        "ROLL Δ   15.0 RPM\n",
                        "ALIGN      0.0 %\n",
                        "PHASE    -13.9 deg\n",
                    ];
                    for (index, line) in mini_initial.into_iter().enumerate() {
                        text_parent.spawn((
                            TextSpan::new(line),
                            TextFont {
                                font_size: FontSize::Px(13.0),
                                ..default()
                            },
                            MiniLine(index),
                        ));
                    }
                });
            });
    });

    commands.spawn((
        Text::new(
            "A / ←  SPIN LEFT     D / →  SPIN RIGHT\nW / ↑  RAISE          S / ↓  LOWER\nE  AUTO-APPROACH / HOLD     C  CAMERA     R  RESET",
        ),
        TextFont {
            font_size: FontSize::Px(13.0),
            ..default()
        },
        TextColor(Color::srgba(0.78, 0.88, 0.92, 0.80)),
        Node {
            position_type: PositionType::Absolute,
            left: px(22),
            top: px(22),
            ..default()
        },
    ));
}

fn input_and_physics(time: Res<Time>, keys: Res<ButtonInput<KeyCode>>, mut game: ResMut<GameState>) {
    if keys.just_pressed(KeyCode::KeyR) {
        *game = GameState::default();
        return;
    }

    if keys.just_pressed(KeyCode::KeyC) {
        game.camera_mode = match game.camera_mode {
            CameraMode::Automatic => CameraMode::Wide,
            CameraMode::Wide => CameraMode::Chase,
            CameraMode::Chase => CameraMode::Docking,
            CameraMode::Docking => CameraMode::Automatic,
        };
    }
    if keys.just_pressed(KeyCode::KeyE) && game.phase == GamePhase::Active {
        game.approach_enabled = !game.approach_enabled;
    }

    let dt = time.delta_secs().min(0.05);
    game.elapsed += dt;

    // La estación mantiene exactamente -68 RPM durante toda la simulación.
    game.endurance_angle = wrap_angle(
        game.endurance_angle + ENDURANCE_RPM * TAU / 60.0 * dt,
    );

    if game.phase == GamePhase::Docked {
        // Una vez acoplado, el Lander comparte el giro de la estación.
        game.lander_rpm = ENDURANCE_RPM;
        game.lander_angle = wrap_angle(game.lander_angle + ENDURANCE_RPM * TAU / 60.0 * dt);
        game.altitude = 0.0;
        return;
    }
    if game.phase != GamePhase::Active {
        return;
    }

    let left = keys.pressed(KeyCode::KeyA) || keys.pressed(KeyCode::ArrowLeft);
    let right = keys.pressed(KeyCode::KeyD) || keys.pressed(KeyCode::ArrowRight);
    let spin_input = (right as i32 - left as i32) as f32;
    game.lander_rpm =
        (game.lander_rpm + spin_input * ROTATION_ACCEL_RPM_S * dt).clamp(-90.0, 90.0);
    game.lander_angle = wrap_angle(game.lander_angle + game.lander_rpm * TAU / 60.0 * dt);

    let raise = keys.pressed(KeyCode::KeyW) || keys.pressed(KeyCode::ArrowUp);
    let lower = keys.pressed(KeyCode::KeyS) || keys.pressed(KeyCode::ArrowDown);
    let vertical_input = (raise as i32 - lower as i32) as f32;
    game.vertical_speed = vertical_input * VERTICAL_SPEED;
    game.altitude = (game.altitude + game.vertical_speed * dt).clamp(-5.0, 5.0);

    // El avance se mantiene bloqueado hasta lograr una alineación segura.
    if game.closure_speed() > 0.0 {
        game.distance = (game.distance - CLOSURE_SPEED * dt).max(0.0);
    }

    if game.distance <= 0.04 {
        game.approach_enabled = false;
        if game.hard_lock() {
            game.phase = GamePhase::Docked;
            game.lander_rpm = ENDURANCE_RPM;
        } else {
            game.phase = GamePhase::Collision;
        }
    }
}

fn update_scene_transforms(
    game: Res<GameState>,
    mut endurance_query: Query<&mut Transform, With<EndurancePivot>>,
    mut lander_query: Query<&mut Transform, (With<LanderRoot>, Without<EndurancePivot>)>,
) {
    if let Ok(mut transform) = endurance_query.single_mut() {
        transform.rotation = Quat::from_rotation_x(game.endurance_angle);
    }
    if let Ok(mut transform) = lander_query.single_mut() {
        transform.translation = game.lander_position();
        transform.rotation = Quat::from_rotation_x(game.lander_angle)
            * Quat::from_rotation_y(FRAC_PI_2);
    }
}

fn update_camera(
    time: Res<Time>,
    game: Res<GameState>,
    mut camera_query: Query<&mut Transform, With<MainCamera>>,
) {
    let Ok(mut transform) = camera_query.single_mut() else {
        return;
    };

    let lander = game.lander_position();
    let port = Vec3::new(TARGET_PORT_X, 0.0, 0.0);
    let (desired_position, look_target) = match game.camera_mode {
        CameraMode::Wide => (Vec3::new(-72.0, 16.0, 29.0), Vec3::new(-5.0, 0.0, 0.0)),
        CameraMode::Chase => (lander + Vec3::new(-13.0, 7.5, 16.0), port),
        CameraMode::Docking => (lander + Vec3::new(-5.0, 2.1, 7.0), port),
        CameraMode::Automatic if game.distance > 12.0 => {
            (Vec3::new(-72.0, 16.0, 29.0), Vec3::new(-5.0, 0.0, 0.0))
        }
        CameraMode::Automatic if game.distance > 4.0 => {
            (lander + Vec3::new(-13.0, 7.5, 16.0), port)
        }
        CameraMode::Automatic => (lander + Vec3::new(-5.0, 2.1, 7.0), port),
    };

    let blend = 1.0 - (-3.2 * time.delta_secs()).exp();
    transform.translation = transform.translation.lerp(desired_position, blend);
    let current_target = transform.forward().as_vec3() * 20.0 + transform.translation;
    let blended_target = current_target.lerp(look_target, blend);
    transform.look_at(blended_target, Vec3::Y);
}

fn update_hud(
    game: Res<GameState>,
    mut telemetry: Query<(&mut TextSpan, &TelemetryLine)>,
    mut mini: Query<(&mut TextSpan, &MiniLine), Without<TelemetryLine>>,
    mut target_ring: Query<&mut UiTransform, (With<TargetMonitorRing>, Without<LanderMonitorRing>)>,
    mut lander_ring: Query<&mut UiTransform, (With<LanderMonitorRing>, Without<TargetMonitorRing>)>,
) {
    let phase_deg = game.phase_error_rad().to_degrees();
    let align = game.alignment_percent();
    let camera_label = match game.camera_mode {
        CameraMode::Automatic => "AUTO",
        CameraMode::Wide => "EXTERIOR",
        CameraMode::Chase => "FOLLOW",
        CameraMode::Docking => "DOCKING PORT",
    };
    let stats = [
        format!("ENDURANCE SPIN      {ENDURANCE_RPM:>6.1} RPM  LEFT\n"),
        format!("LANDER SPIN         {:+6.1} RPM\n", game.lander_rpm),
        format!("SPIN ERROR           {:5.1} RPM\n", game.rpm_error()),
        format!("ALIGNMENT            {:5.1} %\n", align),
        format!("PHASE ERROR          {:+5.1} deg\n", phase_deg),
        format!("ALTITUDE OFFSET      {:+5.2} m\n", game.altitude),
        format!("DOCKING DISTANCE     {:5.2} m\n", game.distance),
        format!("RELATIVE SPEED        {:4.2} m/s\n", game.closure_speed()),
        format!("VERTICAL RATE       {:+5.2} m/s\n", game.vertical_speed),
        format!("STATUS                {}\n", game.status_label()),
        format!("CAMERA                {}\n", camera_label),
    ];
    for (mut span, line) in &mut telemetry {
        **span = stats[line.0].clone();
    }

    let scaled_lander_rpm = game.lander_rpm * (15.0 / 68.0);
    let mini_lines = [
        format!("TARGET   {MONITOR_RPM:>+5.1} RPM\n"),
        format!("LANDER   {scaled_lander_rpm:>+5.1} RPM\n"),
        format!("ROLL Δ   {:5.1} RPM\n", (scaled_lander_rpm - MONITOR_RPM).abs()),
        format!("ALIGN    {:5.1} %\n", align),
        format!("PHASE    {:+5.1} deg\n", phase_deg * (15.0 / 68.0)),
    ];
    for (mut span, line) in &mut mini {
        **span = mini_lines[line.0].clone();
    }

    // Ambos aros giran a escala 15/68: objetivo = 15 RPM exactas;
    // el aro naranja refleja el RPM real del Lander convertido a esa escala.
    if let Ok(mut transform) = target_ring.single_mut() {
        transform.rotation = Rot2::radians(game.elapsed * MONITOR_RPM * TAU / 60.0);
    }
    if let Ok(mut transform) = lander_ring.single_mut() {
        let target_monitor_angle = game.elapsed * MONITOR_RPM * TAU / 60.0;
        transform.rotation = Rot2::radians(
            target_monitor_angle + game.phase_error_rad() * (15.0 / 68.0),
        );
    }
}

fn wrap_angle(angle: f32) -> f32 {
    (angle + std::f32::consts::PI).rem_euclid(TAU) - std::f32::consts::PI
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn endurance_speed_is_exactly_sixty_eight_rpm_left() {
        assert_eq!(ENDURANCE_RPM, -68.0);
        assert!((ENDURANCE_RPM * TAU / 60.0 + 7.1209433).abs() < 0.0001);
    }

    #[test]
    fn monitor_converts_sixty_eight_rpm_to_fifteen_rpm() {
        let converted = 68.0 * (15.0 / 68.0);
        assert!((converted - 15.0).abs() < 0.0001);
    }

    #[test]
    fn wrapped_angle_stays_inside_pi_range() {
        let result = wrap_angle(8.0 * TAU + 0.25);
        assert!((result - 0.25).abs() < 0.0001);
        assert!(wrap_angle(5.0).abs() <= std::f32::consts::PI);
    }

    #[test]
    fn perfect_lock_is_required_to_finish_docking() {
        let mut game = GameState::default();
        game.lander_rpm = ENDURANCE_RPM;
        game.lander_angle = game.endurance_angle;
        game.altitude = 0.0;
        assert!(game.hard_lock());
        assert!((game.alignment_percent() - 100.0).abs() < 0.001);
    }
}
