//! Interstellar Journey - Rust software-rendering edition.
//!
//! The app starts in a keyboard-operated mode menu. Exploration uses the
//! custom CPU rasterizer; the menu, HUD, and minimap are all framebuffer UI.

mod framebuffer;
mod game;
mod math;
mod mesh;
mod renderer;
mod ui;

use crate::framebuffer::Framebuffer;
use crate::game::{Game, InputState};
use crate::mesh::load_obj;
use crate::renderer::Renderer;
use minifb::{Key, Window, WindowOptions};
use std::error::Error;
use std::fs;
use std::path::PathBuf;
use std::time::{Instant, SystemTime, UNIX_EPOCH};

const WIDTH: usize = 1000;
const HEIGHT: usize = 640;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum AppScreen {
    MainMenu,
    Exploration,
    StoryPreview,
    LevelsPreview,
}

fn main() -> Result<(), Box<dyn Error>> {
    let model_path = parse_model_argument().unwrap_or_else(|| PathBuf::from("assets/models/esfera.obj"));
    let sphere = match load_obj(&model_path) {
        Ok(mesh) => {
            println!(
                "Modelo OBJ cargado: {} ({} vertices, {} triangulos)",
                model_path.display(),
                mesh.vertices.len(),
                mesh.triangles.len()
            );
            Some(mesh)
        }
        Err(error) => {
            eprintln!("Aviso: {error}. Se usara una esfera generada por codigo.");
            None
        }
    };

    let mut window = Window::new(
        "INTERSTELLAR JOURNEY | Rust Software Renderer",
        WIDTH,
        HEIGHT,
        WindowOptions::default(),
    )?;
    window.set_target_fps(60);

    let mut framebuffer = Framebuffer::new(WIDTH, HEIGHT);
    let renderer = Renderer::new(WIDTH, HEIGHT, sphere);
    let mut game = Game::new();

    let mut screen = AppScreen::MainMenu;
    let mut selected_mode = 0usize;
    let mut show_minimap = true;

    // Edge-triggered keys keep menu selection and toggles from repeating every frame.
    let mut previous_up = false;
    let mut previous_down = false;
    let mut previous_enter = false;
    let mut previous_backspace = false;
    let mut previous_m = false;
    let mut previous_e = false;
    let mut previous_space = false;
    let mut previous_r = false;
    let mut previous_p = false;
    let mut previous_frame = Instant::now();

    println!("\nINTERSTELLAR JOURNEY - RUST");
    println!("Menu: Up/Down + Enter | Exploration: W/S thrust, A/D steer, arrows pitch");
    println!("Shift: boost | E: land | Space: wormhole | R: takeoff/restart");
    println!("M: show/hide minimap | Backspace: main menu | P: save BMP | Esc: exit\n");

    while window.is_open() && !window.is_key_down(Key::Escape) {
        let now = Instant::now();
        let dt = (now - previous_frame).as_secs_f32().min(0.05);
        previous_frame = now;

        let key_up = window.is_key_down(Key::Up);
        let key_down = window.is_key_down(Key::Down);
        let key_enter = window.is_key_down(Key::Enter);
        let key_backspace = window.is_key_down(Key::Backspace);
        let key_m = window.is_key_down(Key::M);
        let key_e = window.is_key_down(Key::E);
        let key_space = window.is_key_down(Key::Space);
        let key_r = window.is_key_down(Key::R);
        let key_p = window.is_key_down(Key::P);

        let up_pressed = key_up && !previous_up;
        let down_pressed = key_down && !previous_down;
        let enter_pressed = key_enter && !previous_enter;
        let backspace_pressed = key_backspace && !previous_backspace;
        let m_pressed = key_m && !previous_m;

        let mut screenshot_requested = false;

        match screen {
            AppScreen::MainMenu => {
                if up_pressed {
                    selected_mode = (selected_mode + 2) % 3;
                }
                if down_pressed {
                    selected_mode = (selected_mode + 1) % 3;
                }
                if enter_pressed {
                    screen = match selected_mode {
                        0 => AppScreen::Exploration,
                        1 => AppScreen::StoryPreview,
                        _ => AppScreen::LevelsPreview,
                    };
                }
            }
            AppScreen::StoryPreview | AppScreen::LevelsPreview => {
                if enter_pressed || backspace_pressed {
                    screen = AppScreen::MainMenu;
                }
            }
            AppScreen::Exploration => {
                if backspace_pressed {
                    screen = AppScreen::MainMenu;
                } else {
                    if m_pressed {
                        show_minimap = !show_minimap;
                    }

                    let input = InputState {
                        forward: window.is_key_down(Key::W),
                        back: window.is_key_down(Key::S),
                        left: window.is_key_down(Key::A) || window.is_key_down(Key::Left),
                        right: window.is_key_down(Key::D) || window.is_key_down(Key::Right),
                        pitch_up: window.is_key_down(Key::Up),
                        pitch_down: window.is_key_down(Key::Down),
                        boost: window.is_key_down(Key::LeftShift) || window.is_key_down(Key::RightShift),
                        interact_pressed: key_e && !previous_e,
                        wormhole_pressed: key_space && !previous_space,
                        takeoff_pressed: key_r && !previous_r,
                        screenshot_pressed: key_p && !previous_p,
                    };

                    game.update(dt, input);
                    screenshot_requested = input.screenshot_pressed;
                }
            }
        }

        // Render whichever screen is active after handling this frame's input.
        match screen {
            AppScreen::MainMenu => ui::draw_main_menu(&mut framebuffer, selected_mode),
            AppScreen::StoryPreview => ui::draw_mode_preview(
                &mut framebuffer,
                "Modo historia",
                "Una campana narrativa con escenas, dialogos y objetivos de mision.",
            ),
            AppScreen::LevelsPreview => ui::draw_mode_preview(
                &mut framebuffer,
                "Modo niveles",
                "Desafios independientes con rutas, tiempos y condiciones de llegada.",
            ),
            AppScreen::Exploration => {
                renderer.render(&mut framebuffer, &game);
                ui::draw_hud(&mut framebuffer, &game, &game.hud(), game.capture_notice, show_minimap);

                if screenshot_requested {
                    fs::create_dir_all("captures")?;
                    let timestamp = SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs();
                    let filename = format!("captures/interstellar_{timestamp}.bmp");
                    framebuffer.save_bmp(&filename)?;
                    println!("Captura guardada en {filename}");
                }
            }
        }

        window.update_with_buffer(&framebuffer.color, WIDTH, HEIGHT)?;

        previous_up = key_up;
        previous_down = key_down;
        previous_enter = key_enter;
        previous_backspace = key_backspace;
        previous_m = key_m;
        previous_e = key_e;
        previous_space = key_space;
        previous_r = key_r;
        previous_p = key_p;
    }

    Ok(())
}

fn parse_model_argument() -> Option<PathBuf> {
    let mut arguments = std::env::args().skip(1);
    while let Some(argument) = arguments.next() {
        if argument == "--obj" {
            return arguments.next().map(PathBuf::from);
        }
    }
    None
}
