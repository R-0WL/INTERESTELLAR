# Escala y Gargantúa — v6

## Escala de los cuerpos

`PLANET_SCALE` pasa de `4.0` a `15.0` respecto de los radios base. Se aplica a los ocho planetas, el Sol y el agujero de gusano. Gargantúa usa una escala propia derivada del radio externo de su disco y la separación deseada respecto de Miller. La nave no cambia de tamaño.

La escala orbital pasa de `1 UA = 8,000` a `1 UA = 30,000` unidades. Esto mantiene las proporciones aproximadas entre semiejes orbitales y conserva holguras grandes entre planetas. El spawn inicial se desplazó al corredor entre Tierra y Venus para evitar aparecer dentro de alguno de los dos cuerpos ampliados.

La órbita de la Luna se amplió a 6,500 unidades para que no intersecte la Tierra ampliada.

## Agujero de gusano junto a Saturno

El agujero de gusano mantiene su posición relativa a Saturno, ahora con desplazamiento `(18,000, 3,900, 0)`. Este punto queda fuera del límite exterior de los anillos de Saturno, incluso con la nueva escala.

## Gargantúa

Gargantúa se representa con `blackhole.obj`, convertido del GLB homónimo adjunto. El radio exterior normalizado del disco en ese OBJ es 1.0. Se amplía hasta `GARGANTUA_DISK_RADIUS = 83,400` unidades de juego, de modo que el borde del disco queda a 1,600 unidades de la órbita interior de Miller (85,000). El horizonte de eventos/collisión se sincroniza a aproximadamente 0.425 del radio del disco (`GARGANTUA_RADIUS = 35,445`).

La simulación trabaja con unidades de mundo estilizadas, no con kilómetros físicos; por tanto, el valor 1,600 representa la separación solicitada dentro de la escala del juego y no una conversión astronómica literal.

Las órbitas de los planetas del segundo sistema quedan muy alejadas del centro:

| Planeta | Radio orbital |
|---|---:|
| Miller | 85,000 |
| Mann | 155,000 |
| Edmund | 235,000 |

La salida del agujero de gusano está a 275,000 unidades del centro, fuera de la órbita de Edmund. La entrada al sistema permite acercarse desde el planeta exterior hacia Gargantúa. Los periodos de esos tres cuerpos mantienen una relación tipo Kepler entre sus radios orbitales.

El archivo `blackhole.obj` se genera a partir de `blackhole.glb` mediante `tools/convert_glb_assets.py`; el ejecutable usa el OBJ ya preparado y no necesita dependencias Python para cargarlo.

## Renderizado y visibilidad

El plano lejano de la proyección se amplió a 3,000,000 unidades y las estrellas de fondo se sitúan a 1,300,000. Las vistas generales elevan el culling de cuerpos y asteroides a 2,900,000 unidades para que Neptuno y el sistema exterior permanezcan visibles en los encuadres completos.

## Pruebas añadidas/actualizadas

- Escala visual 15x para Tierra, Sol y agujero de gusano; Gargantúa usa una escala derivada de la separación disco-órbita.
- Separación nave-planetas en el punto de inicio.
- Separación de los cuerpos de Gargantúa respecto del volumen central y margen de 1,600 unidades entre disco y órbita de Miller.
- Salida del agujero de gusano fuera de la órbita exterior.
- Offset fijo del agujero de gusano respecto a Saturno.
