mod game;
mod hud;
mod model;
mod render;

use game::{GameState, ModuleStatus};
use glam::{Mat4, Quat, Vec3};
use minifb::{Key, KeyRepeat, UseGPU, Window, WindowOptions};
use model::{Model, ModelFamily};
use render::Framebuffer;
use std::time::Instant;

const WIDTH: usize = 1024;
const HEIGHT: usize = 576;
const SHIP_SCALE: f32 = 0.68;
const SHIP_SCREEN_OFFSET: Vec3 = Vec3::new(35.0, 0.0, 0.0);

fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("GARGANTUA // CPU FRAMEBUFFER RENDERER");
    println!("Loading Gargantua and assembled Endurance models...");

    let blackhole = Model::load("assets/blackhole.glb", "Gargantua", 8_500)?;
    let family = Model::load_assembly_family(
        "assets/combined/endurance_full_assembly.glb",
        "assets/combined/endurance_ranger_assembly.glb",
    )?;

    println!("  {}: {} triangles / {} textures", blackhole.name, blackhole.triangles.len(), blackhole.textures.len());
    println!("  {}: {} triangles", family.full.name, family.full.triangles.len());
    println!("  {}: {} triangles", family.without_lander.name, family.without_lander.triangles.len());
    println!("  {}: {} triangles", family.endurance.name, family.endurance.triangles.len());
    println!("  {}: {} triangles", family.ranger.name, family.ranger.triangles.len());
    println!("  {}: {} triangles", family.lander.name, family.lander.triangles.len());

    let options = WindowOptions {
        use_gpu: UseGPU::Disabled,
        ..WindowOptions::default()
    };
    let mut window = Window::new(
        "GARGANTUA // ORBITAL ESCAPE",
        WIDTH,
        HEIGHT,
        options,
    )?;
    window.set_target_fps(60);

    let mut frame = Framebuffer::new(WIDTH, HEIGHT);
    let mut game = GameState::new();
    apply_assembly_offsets(&mut game, &family);

    let mut last_frame = Instant::now();
    while window.is_open() && !window.is_key_down(Key::Escape) {
        let now = Instant::now();
        let dt = now.duration_since(last_frame).as_secs_f32();
        last_frame = now;

        for key in window.get_keys_pressed(KeyRepeat::No) {
            game.handle_key(key);
            if key == Key::R {
                // GameState::new restores gameplay values; reapply model-derived
                // offsets so released components restart at their real mounts.
                apply_assembly_offsets(&mut game, &family);
            }
        }
        // Keep the release points aligned with the current attitude of the ship.
        apply_assembly_offsets(&mut game, &family);

        let mut held = Vec::with_capacity(6);
        for key in [Key::W, Key::S, Key::A, Key::D, Key::Q, Key::E] {
            if window.is_key_down(key) {
                held.push(key);
            }
        }
        game.update(dt, &held);

        render_world(&mut frame, &blackhole, &family, &game);
        hud::draw_hud(&mut frame, &game);
        draw_help(&mut frame);

        window.update_with_buffer(&frame.color, WIDTH, HEIGHT)?;
    }
    Ok(())
}


fn apply_assembly_offsets(game: &mut GameState, family: &ModelFamily) {
    // The module origins come from the combined GLB itself. These offsets
    // therefore match the attachment points rather than guessed positions.
    let assembly_rotation = Quat::from_rotation_y(std::f32::consts::FRAC_PI_2)
        * Quat::from_rotation_z(game.orientation.to_radians() * 0.18);
    game.modules[0].attached_offset = assembly_rotation
        * ((family.lander.origin - family.assembly_center) * SHIP_SCALE);
    game.modules[1].attached_offset = assembly_rotation
        * ((family.ranger.origin - family.assembly_center) * SHIP_SCALE);
    game.modules[2].attached_offset = assembly_rotation
        * ((family.endurance.origin - family.assembly_center) * SHIP_SCALE);
}

fn render_world(
    frame: &mut Framebuffer,
    blackhole: &Model,
    family: &ModelFamily,
    game: &GameState,
) {
    frame.clear(0x02050B);
    draw_starfield(frame);

    let camera_position = Vec3::new(0.0, 8.0, 112.0);
    let camera_target = Vec3::new(0.0, 0.0, -18.0);
    let view = Mat4::look_at_rh(camera_position, camera_target, Vec3::Y);
    let projection = Mat4::perspective_rh(
        52.0_f32.to_radians(),
        WIDTH as f32 / HEIGHT as f32,
        0.1,
        500.0,
    );
    let view_projection = projection * view;

    // Gargantua remains on the left side of the frame to keep a clear lane
    // for the Endurance assembly on the right.
    let blackhole_transform = Mat4::from_scale_rotation_translation(
        Vec3::splat(21.0),
        Quat::IDENTITY,
        Vec3::new(-38.0, 0.0, -28.0),
    );
    frame.draw_model(blackhole, blackhole_transform, view_projection);

    let ship_position = game.ship_position + SHIP_SCREEN_OFFSET;
    let ship_rotation = Quat::from_rotation_y(std::f32::consts::FRAC_PI_2)
        * Quat::from_rotation_z(game.orientation.to_radians() * 0.18);
    let ship_scale = Vec3::splat(SHIP_SCALE);

    let lander_attached = game.modules[0].status != ModuleStatus::Detached;
    let ranger_attached = game.modules[1].status != ModuleStatus::Detached;

    // Phase 1: exact user-provided full assembly.
    // Phase 2: exact user-provided Endurance + Ranger assembly.
    // Phase 3: Endurance extracted from the full assembly, with its original
    // assembly-space origin retained so it does not jump during the stage swap.
    if lander_attached && ranger_attached {
        let transform = Mat4::from_scale_rotation_translation(
            ship_scale,
            ship_rotation,
            ship_position,
        );
        frame.draw_spacecraft(&family.full, transform, view_projection);
    } else if ranger_attached {
        let transform = Mat4::from_scale_rotation_translation(
            ship_scale,
            ship_rotation,
            ship_position,
        );
        frame.draw_spacecraft(&family.without_lander, transform, view_projection);
    } else {
        let endurance_position = ship_position
            + ship_rotation * ((family.endurance.origin - family.assembly_center) * SHIP_SCALE);
        let transform = Mat4::from_scale_rotation_translation(
            ship_scale,
            ship_rotation,
            endurance_position,
        );
        frame.draw_spacecraft(&family.endurance, transform, view_projection);
    }

    // Released components remain visible as independent spacecraft. Their
    // geometry was extracted from the combined GLB, so its scale/orientation
    // and exact attachment location are consistent with the attached phases.
    for (index, module) in game.modules.iter().enumerate() {
        if module.status != ModuleStatus::Detached || index == 2 {
            continue;
        }
        let model: &Model = if index == 0 {
            &family.lander
        } else {
            &family.ranger
        };
        let detached_position = module.detached_position + SHIP_SCREEN_OFFSET;
        let transform = Mat4::from_scale_rotation_translation(
            ship_scale,
            ship_rotation,
            detached_position,
        );
        frame.draw_spacecraft(model, transform, view_projection);
    }
}

fn draw_starfield(frame: &mut Framebuffer) {
    // Deterministic background: no RNG or per-frame allocation required.
    for i in 0..210usize {
        let x = ((i * 197 + 73) % WIDTH) as i32;
        let y = ((i * 113 + i * i * 7 + 29) % HEIGHT) as i32;
        let brightness = 95 + ((i * 31) % 130) as u32;
        let color = (brightness << 16) | ((brightness / 3) << 8) | (brightness / 2);
        frame.pixel(x, y, color);
        if i % 29 == 0 {
            frame.pixel(x + 1, y, 0x668A9A);
        }
    }
}

fn draw_help(frame: &mut Framebuffer) {
    let x = 12;
    let y = 12;
    let w = 280;
    let h = 82;
    frame.alpha_rect(x, y, w, h, 0x06171C, 0.78);
    frame.rect(x, y, w, h, 0x16454A);
    frame.text(x + 10, y + 8, "GARGANTUA // FLIGHT DIRECTOR", 0x45D9D2, 1);
    frame.text(x + 10, y + 26, "W/S POWER     A/D TRAJECTORY", 0xA8C2C2, 1);
    frame.text(x + 10, y + 39, "Q/E ATTITUDE  SPACE RELEASE", 0xA8C2C2, 1);
    frame.text(x + 10, y + 52, "SHIFT BOOST   1-3 MODULE", 0xA8C2C2, 1);
    frame.text(x + 10, y + 65, "TAB DIAGNOSTICS   R RESTART", 0x45D9D2, 1);
}
