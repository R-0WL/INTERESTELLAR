use crate::model::Model;
use glam::{Mat4, Vec2, Vec3, Vec4};

pub struct Framebuffer {
    pub width: usize,
    pub height: usize,
    pub color: Vec<u32>,
    depth: Vec<f32>,
}

#[derive(Clone, Copy)]
struct ScreenVertex {
    x: f32,
    y: f32,
    z: f32,
    inv_w: f32,
    uv_over_w: Vec2,
    normal_over_w: Vec3,
}

impl Framebuffer {
    pub fn new(width: usize, height: usize) -> Self {
        Self {
            width,
            height,
            color: vec![0x02060D; width * height],
            depth: vec![f32::INFINITY; width * height],
        }
    }

    pub fn clear(&mut self, color: u32) {
        self.color.fill(color);
        self.depth.fill(f32::INFINITY);
    }

    pub fn draw_model(&mut self, model: &Model, model_matrix: Mat4, view_projection: Mat4) {
        self.draw_model_internal(model, model_matrix, view_projection, false);
    }

    /// Spacecraft use a visibility lift: dark source textures/materials are
    /// gently raised toward ivory-white so silhouettes remain readable against
    /// the dark event horizon and the bright accretion disk.
    pub fn draw_spacecraft(&mut self, model: &Model, model_matrix: Mat4, view_projection: Mat4) {
        self.draw_model_internal(model, model_matrix, view_projection, true);
    }

    fn draw_model_internal(
        &mut self,
        model: &Model,
        model_matrix: Mat4,
        view_projection: Mat4,
        visibility_lift: bool,
    ) {
        for triangle in &model.triangles {
            let mut screen = [ScreenVertex {
                x: 0.0, y: 0.0, z: 0.0, inv_w: 0.0,
                uv_over_w: Vec2::ZERO, normal_over_w: Vec3::ZERO,
            }; 3];
            let mut valid = true;
            for i in 0..3 {
                let v = triangle.vertices[i];
                let world = model_matrix.transform_point3(v.position);
                let normal = model_matrix.transform_vector3(v.normal).normalize_or_zero();
                let clip: Vec4 = view_projection * world.extend(1.0);
                if clip.w <= 0.05 || !clip.is_finite() { valid = false; break; }
                let inv_w = 1.0 / clip.w;
                let ndc = clip.truncate() * inv_w;
                if !ndc.is_finite() || ndc.z < 0.0 || ndc.z > 1.0 { valid = false; break; }
                screen[i] = ScreenVertex {
                    x: (ndc.x * 0.5 + 0.5) * (self.width as f32 - 1.0),
                    y: (1.0 - (ndc.y * 0.5 + 0.5)) * (self.height as f32 - 1.0),
                    z: ndc.z,
                    inv_w,
                    uv_over_w: v.uv * inv_w,
                    normal_over_w: normal * inv_w,
                };
            }
            if valid {
                self.rasterize_triangle(
                    screen,
                    model,
                    triangle.color,
                    triangle.texture,
                    visibility_lift,
                );
            }
        }
    }

    fn rasterize_triangle(
        &mut self,
        v: [ScreenVertex; 3],
        model: &Model,
        base: [f32; 4],
        texture: Option<usize>,
        visibility_lift: bool,
    ) {
        let min_x = v.iter().map(|p| p.x).fold(f32::INFINITY, f32::min).floor().max(0.0) as i32;
        let max_x = v.iter().map(|p| p.x).fold(f32::NEG_INFINITY, f32::max).ceil().min(self.width as f32 - 1.0) as i32;
        let min_y = v.iter().map(|p| p.y).fold(f32::INFINITY, f32::min).floor().max(0.0) as i32;
        let max_y = v.iter().map(|p| p.y).fold(f32::NEG_INFINITY, f32::max).ceil().min(self.height as f32 - 1.0) as i32;
        if min_x > max_x || min_y > max_y { return; }

        let area = edge(v[0].x, v[0].y, v[1].x, v[1].y, v[2].x, v[2].y);
        if area.abs() < 0.0001 { return; }

        let texture_data = texture.and_then(|id| model.textures.get(id));
        let light = Vec3::new(-0.35, 0.72, 0.9).normalize();

        for y in min_y..=max_y {
            for x in min_x..=max_x {
                let px = x as f32 + 0.5;
                let py = y as f32 + 0.5;
                let w0 = edge(v[1].x, v[1].y, v[2].x, v[2].y, px, py) / area;
                let w1 = edge(v[2].x, v[2].y, v[0].x, v[0].y, px, py) / area;
                let w2 = 1.0 - w0 - w1;
                if w0 < -0.001 || w1 < -0.001 || w2 < -0.001 { continue; }
                let depth = w0 * v[0].z + w1 * v[1].z + w2 * v[2].z;
                let index = y as usize * self.width + x as usize;
                if depth >= self.depth[index] { continue; }

                let inv_w = w0 * v[0].inv_w + w1 * v[1].inv_w + w2 * v[2].inv_w;
                if inv_w <= 0.000001 { continue; }
                let uv = (v[0].uv_over_w * w0 + v[1].uv_over_w * w1 + v[2].uv_over_w * w2) / inv_w;
                let normal = (v[0].normal_over_w * w0 + v[1].normal_over_w * w1 + v[2].normal_over_w * w2)
                    .normalize_or_zero();
                let mut texel = texture_data.map(|t| t.sample(uv)).unwrap_or([1.0; 4]);
                let mut material = base;
                let diffuse = normal.dot(light).max(0.0);
                let illumination = if visibility_lift {
                    // Retain texture variation, but do not let dark source maps
                    // turn a black spacecraft silhouette against Gargantua.
                    for channel in 0..3 {
                        texel[channel] = 0.58 + texel[channel] * 0.42;
                        material[channel] = 0.62 + material[channel] * 0.38;
                    }
                    0.48 + diffuse * 0.68
                } else {
                    0.30 + diffuse * 0.70
                };
                let red_balance = if visibility_lift { 0.94 } else { 1.0 };
                let blue_balance = if visibility_lift { 1.04 } else { 1.0 };
                let r = (material[0] * texel[0] * illumination * red_balance).clamp(0.0, 1.0);
                let g = (material[1] * texel[1] * illumination).clamp(0.0, 1.0);
                let b = (material[2] * texel[2] * illumination * blue_balance).clamp(0.0, 1.0);
                let a = (base[3] * texel[3]).clamp(0.0, 1.0);
                let src = pack_rgb(r, g, b);
                if a < 0.98 {
                    self.color[index] = blend(self.color[index], src, a);
                } else {
                    self.color[index] = src;
                }
                self.depth[index] = depth;
            }
        }
    }

    pub fn pixel(&mut self, x: i32, y: i32, color: u32) {
        if x >= 0 && y >= 0 && x < self.width as i32 && y < self.height as i32 {
            self.color[y as usize * self.width + x as usize] = color;
        }
    }

    pub fn alpha_pixel(&mut self, x: i32, y: i32, color: u32, alpha: f32) {
        if x >= 0 && y >= 0 && x < self.width as i32 && y < self.height as i32 {
            let i = y as usize * self.width + x as usize;
            self.color[i] = blend(self.color[i], color, alpha.clamp(0.0, 1.0));
        }
    }

    pub fn fill_rect(&mut self, x: i32, y: i32, w: i32, h: i32, color: u32) {
        let x0 = x.max(0);
        let y0 = y.max(0);
        let x1 = (x + w).min(self.width as i32);
        let y1 = (y + h).min(self.height as i32);
        if x0 >= x1 || y0 >= y1 { return; }
        for yy in y0..y1 {
            let start = yy as usize * self.width + x0 as usize;
            let end = yy as usize * self.width + x1 as usize;
            self.color[start..end].fill(color);
        }
    }

    pub fn alpha_rect(&mut self, x: i32, y: i32, w: i32, h: i32, color: u32, alpha: f32) {
        let x0 = x.max(0);
        let y0 = y.max(0);
        let x1 = (x + w).min(self.width as i32);
        let y1 = (y + h).min(self.height as i32);
        if x0 >= x1 || y0 >= y1 { return; }
        for yy in y0..y1 {
            for xx in x0..x1 {
                let i = yy as usize * self.width + xx as usize;
                self.color[i] = blend(self.color[i], color, alpha);
            }
        }
    }

    pub fn rect(&mut self, x: i32, y: i32, w: i32, h: i32, color: u32) {
        self.line(x, y, x + w, y, color);
        self.line(x, y, x, y + h, color);
        self.line(x + w, y, x + w, y + h, color);
        self.line(x, y + h, x + w, y + h, color);
    }

    pub fn line(&mut self, mut x0: i32, mut y0: i32, x1: i32, y1: i32, color: u32) {
        let dx = (x1 - x0).abs();
        let sx = if x0 < x1 { 1 } else { -1 };
        let dy = -(y1 - y0).abs();
        let sy = if y0 < y1 { 1 } else { -1 };
        let mut err = dx + dy;
        loop {
            self.pixel(x0, y0, color);
            if x0 == x1 && y0 == y1 { break; }
            let e2 = 2 * err;
            if e2 >= dy { err += dy; x0 += sx; }
            if e2 <= dx { err += dx; y0 += sy; }
        }
    }

    pub fn circle(&mut self, cx: i32, cy: i32, radius: i32, color: u32) {
        let mut x = radius;
        let mut y = 0;
        let mut err = 0;
        while x >= y {
            self.pixel(cx + x, cy + y, color); self.pixel(cx + y, cy + x, color);
            self.pixel(cx - y, cy + x, color); self.pixel(cx - x, cy + y, color);
            self.pixel(cx - x, cy - y, color); self.pixel(cx - y, cy - x, color);
            self.pixel(cx + y, cy - x, color); self.pixel(cx + x, cy - y, color);
            y += 1;
            if err <= 0 { err += 2 * y + 1; }
            if err > 0 { x -= 1; err -= 2 * x + 1; }
        }
    }

    pub fn text(&mut self, x: i32, y: i32, value: &str, color: u32, scale: i32) {
        use font8x8::UnicodeFonts;
        let mut cursor = x;
        for ch in value.chars() {
            if ch == '\n' { cursor = x; continue; }
            let glyph = font8x8::BASIC_FONTS.get(ch).or_else(|| font8x8::BASIC_FONTS.get('?'));
            if let Some(bitmap) = glyph {
                for (row, bits) in bitmap.iter().enumerate() {
                    for col in 0..8 {
                        if ((*bits >> col) & 1) == 1 {
                            self.fill_rect(cursor + col * scale, y + row as i32 * scale, scale, scale, color);
                        }
                    }
                }
            }
            cursor += 8 * scale;
        }
    }
}

fn edge(ax: f32, ay: f32, bx: f32, by: f32, px: f32, py: f32) -> f32 {
    (px - ax) * (by - ay) - (py - ay) * (bx - ax)
}

pub fn pack_rgb(r: f32, g: f32, b: f32) -> u32 {
    ((r * 255.0) as u32) << 16 | ((g * 255.0) as u32) << 8 | (b * 255.0) as u32
}

fn blend(dst: u32, src: u32, alpha: f32) -> u32 {
    let a = alpha.clamp(0.0, 1.0);
    let dr = ((dst >> 16) & 255) as f32;
    let dg = ((dst >> 8) & 255) as f32;
    let db = (dst & 255) as f32;
    let sr = ((src >> 16) & 255) as f32;
    let sg = ((src >> 8) & 255) as f32;
    let sb = (src & 255) as f32;
    (((dr + (sr - dr) * a) as u32) << 16)
        | (((dg + (sg - dg) * a) as u32) << 8)
        | ((db + (sb - db) * a) as u32)
}
