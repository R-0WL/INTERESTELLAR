# GARGANTUA // Orbital Escape (Rust / CPU framebuffer)

Prototipo jugable de lanzamiento orbital por etapas. Renderiza los modelos GLB con un rasterizador de triángulos por software y presenta el resultado en una ventana `minifb`. No usa shaders, OpenGL, Vulkan, DirectX ni un pipeline de renderizado GPU.

## Estado de esta entrega

Implementado:

- Carga de `blackhole.glb` y de los dos ensamblajes GLB suministrados: `assets/combined/endurance_full_assembly.glb` (Endurance + Ranger 2 + Lander) y `assets/combined/endurance_ranger_assembly.glb` (Endurance + Ranger 2).
- Los componentes individuales de Lander, Ranger 2 y Endurance se extraen de la misma jerarquía del ensamblaje completo. Así conservan la escala, orientación y puntos de unión originales al quedar liberados.
- Rasterización por CPU con z-buffer, proyección en perspectiva, iluminación difusa y muestreo de texturas GLB.
- `minifb` recibe el framebuffer ya calculado por CPU y se configura con `UseGPU::Disabled` para solicitar presentación por software en los backends que exponen esa opción.
- Fondo espacial y modelo de Gargantúa.
- Fase 1: ensamblaje GLB completo Endurance + Ranger 2 + Lander.
- Fase 2: ensamblaje GLB Endurance + Ranger 2, sin Lander.
- Fase 3: Endurance individual extraída del ensamblaje original.
- Los módulos liberados se dibujan como modelos independientes extraídos del mismo GLB de ensamblaje; se mantienen visibles en la escena.
- La iluminación de naves aplica un realce blanco marfil/cian a materiales y texturas oscuros para mejorar la lectura de la silueta sobre Gargantúa.
- Máquina de estados `Attached` → `Detaching` → `Detached` por módulo (el estado intermedio es lógico; aún no tiene movimiento visual).
- Separación individual con `SPACE`, bloqueada fuera de la ventana de seguridad, con estimación de apertura/cierre y validada en el orden Lander → Ranger 2.
- Los módulos liberados se conservan como objetos independientes y continúan su trayectoria.
- Recalculo de masa, combustible disponible y respuesta de aceleración al cambiar la configuración.
- Gestión de potencia, trayectoria, orientación, combustible e impulso.
- Condiciones de victoria y derrota asociadas a velocidad de escape, combustible y proximidad al horizonte.
- HUD distribuido en paneles compactos: controles arriba a la izquierda, estado de módulos arriba a la derecha, telemetría abajo a la derecha, secuencia abajo al centro y medidor gravitacional a la izquierda. El centro queda libre para la escena.
- Tecla `R` para reiniciar la maniobra completa desde cualquier estado, incluido victoria o derrota.
- Gargantúa compuesto en un plano de perfil, con el disco de acreción horizontal y desplazado a la izquierda para mejorar la composición cinematográfica.
- Animaciones de transición de separación aplazadas intencionalmente. La separación lógica ocurre sin desplazamiento animado en esta entrega.

Pendiente para una siguiente iteración:

- Animación visual de desacoplamiento: la máquina de estados `Attached → Detaching → Detached` ya existe, pero el movimiento/efecto de transición se implementará en la última etapa.
- Ajuste fino de encuadre, escala y legibilidad de las naves en el equipo objetivo; los ensamblajes ya conservan sus posiciones relativas.
- Calibración de balance y rendimiento en la máquina objetivo.
- Soporte de mando: se deja fuera del prototipo, tal como se solicitó.

## Requisitos

- Rust estable y Cargo. El archivo `rust-toolchain.toml` fija el canal `stable` mediante rustup para evitar que el proyecto se compile accidentalmente con una toolchain nightly experimental.
- Windows, Linux o macOS con soporte de ventana para `minifb`.

## Ejecutar

Desde esta carpeta (si usas rustup, el archivo `rust-toolchain.toml` selecciona automáticamente Rust estable):

```bash
rustup toolchain install stable
cargo clean
cargo run --release
```

Para ejecutar las pruebas de lógica incluidas:

```bash
cargo test
```

Esta entrega no incluye `Cargo.lock`; Cargo resolverá las versiones compatibles de las dependencias al primer build.

El modo `--release` es importante para el rasterizador por software. Los modelos se cargan desde `assets/`, por lo que hay que ejecutar el programa desde la raíz del proyecto.

## Controles

| Tecla | Acción |
|---|---|
| `W` / `S` | Aumentar / reducir potencia |
| `A` / `D` | Ajustar trayectoria |
| `Q` / `E` | Ajustar orientación |
| `SPACE` | Liberar únicamente el módulo seleccionado y requerido por la secuencia |
| `SHIFT` | Impulso de combustible |
| `1` / `2` / `3` | Seleccionar Lander / Ranger 2 / Endurance |
| `←` / `→` | Cambiar módulo seleccionado |
| `TAB` | Mostrar / ocultar diagnóstico de vuelo |
| `R` | Reiniciar la maniobra |
| `ESC` | Salir |

### Mando (no implementado)

```text
Stick izquierdo: trayectoria
RT / LT: potencia
A (Xbox) / X (PlayStation): liberar módulo
B / Círculo: activar impulso
RB / LB: cambiar módulo seleccionado
```

## Notas técnicas

- El framebuffer usa 1024 × 576 píxeles.
- Los modelos se limitan a un presupuesto de triángulos por componente al cargarse para reducir el coste de rasterización por CPU, sin dejar fuera a los módulos pequeños del ensamblaje.
- Los materiales GLB conservan factor de color y textura base cuando existe. Las naves reciben un realce de visibilidad que eleva los tonos oscuros hacia blanco marfil/cian; Gargantúa conserva sus materiales originales.
- El renderizado 3D/2D se calcula por CPU y escribe directamente en el framebuffer. No hay shaders, OpenGL, Vulkan, DirectX ni pipeline GPU de renderizado. `UseGPU::Disabled` solicita escalado por CPU en los backends que respetan esa opción; minifb documenta que Wayland es el único backend que la consulta actualmente, X11 escala por software y Windows presenta mediante GDI, mientras que macOS usa GPU para la presentación nativa de la ventana. Esa presentación del sistema operativo no participa en el cálculo de los píxeles del juego.
- La física es un modelo arcade normalizado para el minijuego, no una simulación astrodinámica realista.
- Los paneles del HUD están construidos con primitivas 2D dibujadas directamente sobre el mismo framebuffer y distribuidos alrededor de los bordes para no cubrir el campo visual central.


### Diagnóstico si aparecen errores en `core`, `shlex` o archivos `.rmeta`

Esos errores suelen indicar una toolchain nightly/experimental o una instalación incompleta/inconsistente de Rust, no un error del código del juego. Comprueba `rustc --version --verbose`, `cargo --version`, `where rustc`, `where cargo` y `rustup show active-toolchain`. Instala y usa el canal oficial estable con `rustup toolchain install stable` y `cargo +stable clean && cargo +stable run --release`.
