use std::fs;
use std::path::{Path, PathBuf};
use std::time::Instant;

use fontdue::Font;
use image::imageops::FilterType;

use crate::game::{GameState, TARGET_MESSAGES};
use crate::morse::{pretty_code, MORSE_PAIRS};

const INK: u32 = 0xEAF4FF;
const MUTED: u32 = 0x8EA9C4;
const CYAN: u32 = 0x69E5F2;
const TEAL: u32 = 0x1AD4B5;
const PURPLE: u32 = 0x9E8CFF;
const PANEL: u32 = 0x0B1A2C;
const PANEL_LIGHT: u32 = 0x10263B;
const DARK: u32 = 0x071321;

#[derive(Clone, Copy, Debug)]
pub struct Rect {
    pub x: i32,
    pub y: i32,
    pub w: i32,
    pub h: i32,
}

impl Rect {
    pub fn contains(self, x: f32, y: f32) -> bool {
        x >= self.x as f32 && y >= self.y as f32
            && x < (self.x + self.w) as f32 && y < (self.y + self.h) as f32
    }
}

#[derive(Clone, Copy, Debug)]
pub struct Hitboxes {
    pub settings: Rect,
    pub send: Rect,
    pub play: Rect,
    pub clear: Rect,
    pub close_modal: Rect,
}

pub struct Backgrounds {
    images: Vec<Vec<u32>>,
    width: usize,
    height: usize,
}

impl Backgrounds {
    pub fn load(folder: &Path, width: usize, height: usize) -> Self {
        let mut paths: Vec<PathBuf> = Vec::new();
        if let Ok(entries) = fs::read_dir(folder) {
            for entry in entries.flatten() {
                let path = entry.path();
                let supported = path.extension()
                    .and_then(|e| e.to_str())
                    .map(|e| matches!(e.to_ascii_lowercase().as_str(), "png" | "jpg" | "jpeg" | "webp"))
                    .unwrap_or(false);
                if supported { paths.push(path); }
            }
        }
        paths.sort();

        let mut images = Vec::new();
        for path in paths {
            match image::open(&path) {
                Ok(image) => {
                    let resized = image.resize_exact(width as u32, height as u32, FilterType::CatmullRom).to_rgba8();
                    let pixels = resized.pixels().map(|p| {
                        let [r, g, b, _] = p.0;
                        ((r as u32) << 16) | ((g as u32) << 8) | b as u32
                    }).collect();
                    println!("Fondo cargado: {}", path.display());
                    images.push(pixels);
                }
                Err(error) => eprintln!("No se pudo cargar {}: {error}", path.display()),
            }
        }
        if images.is_empty() {
            println!("No hay fondos en {}. Se usará el cielo estrellado generado por el programa.", folder.display());
        }
        Self { images, width, height }
    }

    fn draw(&self, canvas: &mut Canvas, start: Instant) {
        if self.images.is_empty() {
            canvas.gradient(0x061120, 0x10223A);
            canvas.circle_alpha((self.width / 2) as i32, (self.height / 3) as i32, 310, 0x234D6A, 24);
            canvas.circle_alpha((self.width * 3 / 4) as i32, (self.height * 2 / 3) as i32, 230, 0x3C286D, 18);
            let time = start.elapsed().as_secs_f32();
            for i in 0..185usize {
                let x = ((i * 7919 + 113) % self.width) as i32;
                let y = ((i * 3571 + 47) % self.height) as i32;
                let twinkle = (time * (0.65 + (i % 7) as f32 * 0.1) + i as f32).sin() * 0.5 + 0.5;
                let radius = if i % 17 == 0 { 2 } else { 1 };
                let alpha = (80.0 + 160.0 * twinkle) as u8;
                canvas.circle_alpha(x, y, radius, if i % 9 == 0 { CYAN } else { 0xDCEBFF }, alpha);
                if i % 31 == 0 {
                    canvas.line(x - 5, y, x + 5, y, 0x8BDCE8);
                    canvas.line(x, y - 5, x, y + 5, 0x8BDCE8);
                }
            }
        } else {
            let seconds = start.elapsed().as_secs();
            let index = ((seconds / 22) as usize) % self.images.len();
            if let Some(image) = self.images.get(index) {
                canvas.buffer.copy_from_slice(image);
            }
            canvas.overlay(0x061426, 174);
            // Viñeta suave para mantener la legibilidad de los paneles.
            canvas.rect_alpha(0, 0, self.width as i32, 92, 0x061426, 55);
            canvas.rect_alpha(0, self.height as i32 - 245, self.width as i32, 245, 0x061426, 70);
        }
    }
}

pub struct Canvas {
    pub width: usize,
    pub height: usize,
    pub buffer: Vec<u32>,
}

impl Canvas {
    pub fn new(width: usize, height: usize) -> Self {
        Self { width, height, buffer: vec![0; width * height] }
    }

    fn blend(base: u32, over: u32, alpha: u8) -> u32 {
        let a = alpha as u32;
        let inv = 255 - a;
        let r = ((((base >> 16) & 255) * inv + ((over >> 16) & 255) * a) / 255) & 255;
        let g = ((((base >> 8) & 255) * inv + ((over >> 8) & 255) * a) / 255) & 255;
        let b = (((base & 255) * inv + (over & 255) * a) / 255) & 255;
        (r << 16) | (g << 8) | b
    }

    pub fn pixel(&mut self, x: i32, y: i32, color: u32) {
        if x < 0 || y < 0 || x >= self.width as i32 || y >= self.height as i32 { return; }
        self.buffer[y as usize * self.width + x as usize] = color;
    }

    pub fn pixel_alpha(&mut self, x: i32, y: i32, color: u32, alpha: u8) {
        if x < 0 || y < 0 || x >= self.width as i32 || y >= self.height as i32 { return; }
        let index = y as usize * self.width + x as usize;
        self.buffer[index] = Self::blend(self.buffer[index], color, alpha);
    }

    pub fn gradient(&mut self, top: u32, bottom: u32) {
        for y in 0..self.height {
            let t = y as f32 / self.height.max(1) as f32;
            let color = lerp_color(top, bottom, t);
            let start = y * self.width;
            self.buffer[start..start + self.width].fill(color);
        }
    }

    pub fn overlay(&mut self, color: u32, alpha: u8) {
        for pixel in &mut self.buffer {
            *pixel = Self::blend(*pixel, color, alpha);
        }
    }

    pub fn rect(&mut self, x: i32, y: i32, w: i32, h: i32, color: u32) {
        let x0 = x.max(0);
        let y0 = y.max(0);
        let x1 = (x + w).min(self.width as i32);
        let y1 = (y + h).min(self.height as i32);
        if x0 >= x1 || y0 >= y1 { return; }
        for yy in y0..y1 {
            let start = yy as usize * self.width + x0 as usize;
            let end = yy as usize * self.width + x1 as usize;
            self.buffer[start..end].fill(color);
        }
    }

    pub fn rect_alpha(&mut self, x: i32, y: i32, w: i32, h: i32, color: u32, alpha: u8) {
        let x0 = x.max(0);
        let y0 = y.max(0);
        let x1 = (x + w).min(self.width as i32);
        let y1 = (y + h).min(self.height as i32);
        if x0 >= x1 || y0 >= y1 { return; }
        for yy in y0..y1 {
            let start = yy as usize * self.width + x0 as usize;
            let end = yy as usize * self.width + x1 as usize;
            for pixel in &mut self.buffer[start..end] {
                *pixel = Self::blend(*pixel, color, alpha);
            }
        }
    }

    pub fn outline(&mut self, x: i32, y: i32, w: i32, h: i32, color: u32) {
        self.rect(x, y, w, 1, color);
        self.rect(x, y + h - 1, w, 1, color);
        self.rect(x, y, 1, h, color);
        self.rect(x + w - 1, y, 1, h, color);
    }

    pub fn circle(&mut self, cx: i32, cy: i32, radius: i32, color: u32) {
        self.circle_alpha(cx, cy, radius, color, 255);
    }

    pub fn circle_alpha(&mut self, cx: i32, cy: i32, radius: i32, color: u32, alpha: u8) {
        let r2 = radius * radius;
        for y in -radius..=radius {
            for x in -radius..=radius {
                if x * x + y * y <= r2 {
                    self.pixel_alpha(cx + x, cy + y, color, alpha);
                }
            }
        }
    }

    pub fn circle_outline(&mut self, cx: i32, cy: i32, radius: i32, color: u32, thickness: i32) {
        let outer = radius * radius;
        let inner_r = (radius - thickness).max(0);
        let inner = inner_r * inner_r;
        for y in -radius..=radius {
            for x in -radius..=radius {
                let d = x * x + y * y;
                if d <= outer && d >= inner {
                    self.pixel(cx + x, cy + y, color);
                }
            }
        }
    }

    pub fn line(&mut self, mut x0: i32, mut y0: i32, x1: i32, y1: i32, color: u32) {
        let dx = (x1 - x0).abs();
        let sx = if x0 < x1 { 1 } else { -1 };
        let dy = -(y1 - y0).abs();
        let sy = if y0 < y1 { 1 } else { -1 };
        let mut error = dx + dy;
        loop {
            self.pixel(x0, y0, color);
            if x0 == x1 && y0 == y1 { break; }
            let twice = 2 * error;
            if twice >= dy { error += dy; x0 += sx; }
            if twice <= dx { error += dx; y0 += sy; }
        }
    }

    pub fn polygon(&mut self, points: &[(i32, i32)], color: u32) {
        if points.len() < 3 { return; }
        let min_y = points.iter().map(|p| p.1).min().unwrap_or(0).max(0);
        let max_y = points.iter().map(|p| p.1).max().unwrap_or(0).min(self.height as i32 - 1);
        for y in min_y..=max_y {
            let mut intersections = Vec::new();
            for i in 0..points.len() {
                let (x1, y1) = points[i];
                let (x2, y2) = points[(i + 1) % points.len()];
                if (y1 <= y && y2 > y) || (y2 <= y && y1 > y) {
                    let x = x1 as f32 + (y - y1) as f32 * (x2 - x1) as f32 / (y2 - y1) as f32;
                    intersections.push(x as i32);
                }
            }
            intersections.sort_unstable();
            for pair in intersections.chunks(2) {
                if pair.len() == 2 {
                    self.rect(pair[0], y, pair[1] - pair[0] + 1, 1, color);
                }
            }
        }
    }

    pub fn star(&mut self, cx: i32, cy: i32, outer: i32, inner: i32, color: u32) {
        let mut points = Vec::with_capacity(10);
        for i in 0..10 {
            let angle = -std::f32::consts::FRAC_PI_2 + i as f32 * std::f32::consts::PI / 5.0;
            let radius = if i % 2 == 0 { outer } else { inner };
            points.push((cx + (angle.cos() * radius as f32) as i32, cy + (angle.sin() * radius as f32) as i32));
        }
        self.polygon(&points, color);
    }

    pub fn text(&mut self, font: &Font, x: i32, y: i32, size: f32, content: &str, color: u32) {
        let mut cursor_x = x as f32;
        let baseline = y as f32 + size;
        for ch in content.chars() {
            if ch == '\n' { continue; }
            let (metrics, bitmap) = font.rasterize(ch, size);
            let left = cursor_x.round() as i32 + metrics.xmin;
            let top = baseline.round() as i32 - metrics.height as i32 - metrics.ymin;
            for by in 0..metrics.height {
                for bx in 0..metrics.width {
                    let alpha = bitmap[by * metrics.width + bx];
                    if alpha > 0 {
                        self.pixel_alpha(left + bx as i32, top + by as i32, color, alpha);
                    }
                }
            }
            cursor_x += metrics.advance_width;
        }
    }

    pub fn measure_text(font: &Font, size: f32, content: &str) -> f32 {
        content.chars().map(|ch| font.metrics(ch, size).advance_width).sum()
    }

    pub fn wrapped_text(&mut self, font: &Font, x: i32, y: i32, size: f32, content: &str, max_width: f32, line_gap: i32, color: u32) -> i32 {
        let mut line = String::new();
        let mut cursor_y = y;
        for word in content.split_whitespace() {
            let candidate = if line.is_empty() { word.to_string() } else { format!("{line} {word}") };
            if !line.is_empty() && Self::measure_text(font, size, &candidate) > max_width {
                self.text(font, x, cursor_y, size, &line, color);
                cursor_y += size as i32 + line_gap;
                line = word.to_string();
            } else {
                line = candidate;
            }
        }
        if !line.is_empty() {
            self.text(font, x, cursor_y, size, &line, color);
            cursor_y += size as i32 + line_gap;
        }
        cursor_y
    }
}

fn lerp_color(a: u32, b: u32, t: f32) -> u32 {
    let channel = |shift| {
        let av = ((a >> shift) & 255u32) as f32;
        let bv = ((b >> shift) & 255u32) as f32;
        (av + (bv - av) * t) as u32
    };
    (channel(16) << 16) | (channel(8) << 8) | channel(0)
}

pub fn load_font() -> Result<Font, String> {
    let candidates = font_candidates();
    for path in candidates {
        if let Ok(bytes) = fs::read(&path) {
            if let Ok(font) = Font::from_bytes(bytes, fontdue::FontSettings::default()) {
                println!("Fuente cargada: {}", path.display());
                return Ok(font);
            }
        }
    }
    Err("No se encontró una fuente TTF del sistema. Instala Arial, Segoe UI o DejaVu Sans.".to_string())
}

fn font_candidates() -> Vec<PathBuf> {
    #[cfg(target_os = "windows")]
    let paths = vec![
        r"C:\Windows\Fonts\segoeui.ttf",
        r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\calibri.ttf",
    ];
    #[cfg(target_os = "macos")]
    let paths = vec![
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/System/Library/Fonts/SFNS.ttf",
    ];
    #[cfg(target_os = "linux")]
    let paths = vec![
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
    ];
    paths.into_iter().map(PathBuf::from).collect()
}

fn panel(canvas: &mut Canvas, rect: Rect) {
    canvas.rect_alpha(rect.x, rect.y, rect.w, rect.h, PANEL, 220);
    canvas.outline(rect.x, rect.y, rect.w, rect.h, 0x31516B);
    canvas.rect(rect.x + 1, rect.y + 1, rect.w - 2, 2, 0x26465E);
}

fn label(canvas: &mut Canvas, font: &Font, x: i32, y: i32, text: &str) {
    canvas.text(font, x, y, 11.0, text, CYAN);
}

fn button(canvas: &mut Canvas, font: &Font, rect: Rect, caption: &str, active: bool) {
    let fill = if active { 0x0E796F } else { 0x12354B };
    canvas.rect_alpha(rect.x, rect.y, rect.w, rect.h, fill, 245);
    canvas.outline(rect.x, rect.y, rect.w, rect.h, if active { 0x66F1D7 } else { 0x3A7188 });
    let text_w = Canvas::measure_text(font, 13.0, caption) as i32;
    canvas.text(font, rect.x + (rect.w - text_w) / 2, rect.y + 10, 13.0, caption, INK);
}

fn draw_stars(canvas: &mut Canvas, center_x: i32, y: i32, count: u8, scale: i32) {
    let spacing = scale * 2 + 18;
    let start_x = center_x - spacing * 2;
    for i in 0..5 {
        let x = start_x + i * spacing;
        let active = i < count as i32;
        let color = if active { 0x68F0E2 } else { 0x34465B };
        if active {
            canvas.circle_alpha(x, y, scale + 9, 0x36CFC6, 22);
            canvas.circle_outline(x, y, scale + 8, 0x2A8F98, 1);
            canvas.star(x, y, scale, (scale as f32 * 0.46) as i32, color);
            canvas.star(x, y, (scale as f32 * 0.47) as i32, (scale as f32 * 0.22) as i32, 0xE4FFFF);
        } else {
            canvas.star(x, y, scale, (scale as f32 * 0.46) as i32, color);
            canvas.circle_outline(x, y, scale + 6, 0x26394F, 1);
        }
    }
}

fn draw_reference(canvas: &mut Canvas, font: &Font, rect: Rect) {
    panel(canvas, rect);
    label(canvas, font, rect.x + 15, rect.y + 13, "TABLA DE CAMPO / MORSE ITU");
    canvas.text(font, rect.x + 15, rect.y + 32, 18.0, "Alfabeto de transmisión", INK);
    canvas.line(rect.x + 15, rect.y + 60, rect.x + rect.w - 15, rect.y + 60, 0x34546B);

    let letters: Vec<(char, &str)> = MORSE_PAIRS.iter().copied().filter(|(c, _)| c.is_ascii_alphabetic() || *c == 'Ñ').collect();
    let left_x = rect.x + 16;
    let right_x = rect.x + rect.w / 2 + 5;
    let row_y = rect.y + 72;
    for (i, (ch, code)) in letters.iter().enumerate() {
        let col = if i < 14 { 0 } else { 1 };
        let row = if col == 0 { i } else { i - 14 };
        let x = if col == 0 { left_x } else { right_x };
        let y = row_y + row as i32 * 14;
        canvas.text(font, x, y, 12.0, &ch.to_string(), INK);
        canvas.text(font, x + 22, y, 12.0, &pretty_code(code), CYAN);
    }

    let number_y = rect.y + 264;
    canvas.line(rect.x + 15, number_y - 7, rect.x + rect.w - 15, number_y - 7, 0x34546B);
    label(canvas, font, rect.x + 15, number_y, "NÚMEROS");
    let numbers: Vec<(char, &str)> = MORSE_PAIRS.iter().copied().filter(|(c, _)| c.is_ascii_digit()).collect();
    for (i, (ch, code)) in numbers.iter().enumerate() {
        let col = if i < 5 { 0 } else { 1 };
        let row = if col == 0 { i } else { i - 5 };
        let x = if col == 0 { left_x } else { right_x };
        let y = number_y + 17 + row as i32 * 14;
        canvas.text(font, x, y, 11.0, &ch.to_string(), INK);
        canvas.text(font, x + 20, y, 11.0, &pretty_code(code), CYAN);
    }

    let punctuation_y = rect.y + 362;
    canvas.line(rect.x + 15, punctuation_y - 8, rect.x + rect.w - 15, punctuation_y - 8, 0x34546B);
    label(canvas, font, rect.x + 15, punctuation_y, "SIGNOS");
    let signs_a = [('!', "!"), ('?', "?"), (',', ","), ('.', ".")];
    let signs_b = [('\'', "'"), ('"', "\""), (':', ":"), ('/', "/")];
    let format_signs = |items: &[(char, &str)]| -> String {
        items.iter().map(|(ch, shown)| {
            let code = crate::morse::code_for(*ch).unwrap_or("");
            format!("{shown} {}", pretty_code(code))
        }).collect::<Vec<_>>().join("   ")
    };
    canvas.text(font, rect.x + 15, punctuation_y + 14, 9.0, &format_signs(&signs_a), 0xC8D8E9);
    canvas.text(font, rect.x + 15, punctuation_y + 27, 9.0, &format_signs(&signs_b), 0xC8D8E9);
    canvas.text(font, rect.x + 15, rect.y + rect.h - 20, 9.0, "Tilde → vocal base   ·   ° → DEG   ·   Ñ extendida", MUTED);
}

pub fn render(
    canvas: &mut Canvas,
    font: &Font,
    backgrounds: &Backgrounds,
    started: Instant,
    game: &GameState,
    settings_open: bool,
    playing: bool,
) -> Hitboxes {
    backgrounds.draw(canvas, started);
    let width = canvas.width as i32;
    let height = canvas.height as i32;

    // Cabecera espacial.
    canvas.circle_alpha(43, 43, 23, 0x35E2DA, 28);
    canvas.circle_outline(43, 43, 20, 0x5DEDE5, 1);
    canvas.star(43, 43, 12, 5, 0x8BFFF1);
    canvas.text(font, 77, 20, 19.0, "TESERACTO INTERESTELAR", INK);
    canvas.text(font, 78, 45, 10.0, "MORSE RELAY  /  ENLACE CON MURPH", MUTED);
    canvas.line(30, 82, width - 30, 82, 0x35536B);

    let settings_rect = Rect { x: width - 174, y: 22, w: 144, h: 39 };
    button(canvas, font, settings_rect, "⚙  CONFIGURACIÓN", settings_open);

    let top = 106;
    let panel_h = 432;
    let left = Rect { x: 28, y: top, w: 342, h: panel_h };
    let center = Rect { x: 388, y: top, w: 508, h: panel_h };
    let right = Rect { x: 914, y: top, w: 338, h: panel_h };

    // Objetivo narrativo.
    panel(canvas, left);
    label(canvas, font, left.x + 18, left.y + 17, "OBJETIVO DE TRANSMISIÓN");
    let current_index = game.current_message_index();
    if !game.is_finished() {
        let badge = format!("MENSAJE  {:02} / 05", current_index + 1);
        canvas.text(font, left.x + 18, left.y + 43, 15.0, &badge, 0xA6E9F3);
        canvas.text(font, left.x + left.w - 100, left.y + 45, 10.0, "PRIORIDAD ALTA", 0xF0BC84);
        canvas.line(left.x + 18, left.y + 70, left.x + left.w - 18, left.y + 70, 0x34546B);
        let next_y = canvas.wrapped_text(font, left.x + 18, left.y + 91, 23.0, TARGET_MESSAGES[current_index], (left.w - 38) as f32, 8, INK);
        let note_y = next_y + 13;
        canvas.text(font, left.x + 18, note_y, 10.0, "CODIFICA EL TEXTO Y ENVÍALO A MURPH", CYAN);
        canvas.text(font, left.x + 18, note_y + 28, 11.0, "El resultado se calcula con los cinco mensajes.", MUTED);
        canvas.text(font, left.x + 18, left.y + left.h - 68, 10.0, "PROGRESO DE LA MISIÓN", MUTED);
        canvas.rect_alpha(left.x + 18, left.y + left.h - 47, left.w - 36, 8, 0x273B50, 255);
        canvas.rect(left.x + 18, left.y + left.h - 47, ((left.w - 36) as f32 * game.progress_fraction()) as i32, 8, TEAL);
        canvas.text(font, left.x + 18, left.y + left.h - 30, 10.0, &format!("{} de 5 transmisiones enviadas", game.submitted.len()), MUTED);
    } else {
        canvas.text(font, left.x + 18, left.y + 48, 18.0, "TRANSMISIONES COMPLETADAS", TEAL);
        canvas.wrapped_text(font, left.x + 18, left.y + 96, 20.0, "Murph ha recibido la secuencia completa. Revisa la exactitud global del enlace.", (left.w - 36) as f32, 8, INK);
        canvas.text(font, left.x + 18, left.y + left.h - 65, 11.0, "Pulsa REINICIAR para repetir la misión.", MUTED);
    }

    // Centro: interfaz del enlace y estrellas globales.
    panel(canvas, center);
    label(canvas, font, center.x + 18, center.y + 16, "CANAL CUÁNTICO  /  SECTOR GARGANTÚA");
    canvas.text(font, center.x + 18, center.y + 38, 18.0, "Enlace gravitacional", INK);
    let cx = center.x + center.w / 2;
    let cy = center.y + 202;
    let pulse = (started.elapsed().as_secs_f32() * 1.8).sin() * 0.5 + 0.5;
    let glow = 68 + (pulse * 30.0) as i32;
    canvas.circle_alpha(cx, cy, glow + 28, 0x29C9D4, 18);
    canvas.circle_outline(cx, cy, glow + 19, 0x477DA2, 1);
    canvas.circle_outline(cx, cy, glow + 8, 0x55BFC9, 2);
    canvas.circle_alpha(cx, cy, glow, 0x0D4157, 220);
    canvas.circle_outline(cx, cy, glow, 0x73F2E9, 2);
    canvas.circle_outline(cx, cy, glow - 12, 0x4C9FAF, 1);
    canvas.star(cx, cy, 29, 13, 0x6DE8E4);
    canvas.star(cx, cy, 12, 5, 0xF0FFFF);
    canvas.line(cx - 120, cy, cx - 83, cy, 0x5C96B2);
    canvas.line(cx + 83, cy, cx + 120, cy, 0x5C96B2);
    canvas.circle(cx - 120, cy, 3, CYAN);
    canvas.circle(cx + 120, cy, 3, CYAN);

    let signal = if playing { "REPRODUCIENDO SEÑAL" } else if !game.input.current_code().is_empty() { "RECIBIENDO PULSOS" } else { "ESPERANDO TRANSMISIÓN" };
    let signal_width = Canvas::measure_text(font, 12.0, signal) as i32;
    canvas.text(font, cx - signal_width / 2, center.y + 314, 12.0, signal, if playing { PURPLE } else { CYAN });
    let preview = if game.input.current_code().is_empty() { "· · ·".to_string() } else { pretty_code(game.input.current_code()) };
    let preview_width = Canvas::measure_text(font, 17.0, &preview) as i32;
    canvas.text(font, cx - preview_width / 2, center.y + 340, 17.0, &preview, INK);
    canvas.text(font, center.x + 18, center.y + center.h - 53, 10.0, "EXACTITUD GLOBAL", MUTED);
    let accuracy = game.accuracy();
    canvas.text(font, center.x + 18, center.y + center.h - 34, 18.0, &format!("{accuracy:05.1}%"), INK);
    draw_stars(canvas, center.x + center.w - 119, center.y + center.h - 35, game.stars(), 10);

    // Tabla construida en tiempo de ejecución desde MORSE_PAIRS.
    draw_reference(canvas, font, right);

    // Panel inferior: señal y traducción, siguiendo la distribución del proyecto original.
    let bottom = Rect { x: 28, y: 556, w: width - 56, h: height - 584 };
    panel(canvas, bottom);
    label(canvas, font, bottom.x + 18, bottom.y + 13, "TRANSMISIÓN EN CURSO");
    canvas.text(font, bottom.x + 18, bottom.y + 34, 15.0, "SEÑAL MORSE", INK);
    let raw = game.input.displayed_morse();
    let raw = if raw.is_empty() { "Los puntos y rayas aparecerán aquí al pulsar las teclas.".to_string() } else { pretty_code(&raw) };
    draw_single_line_fit(canvas, font, bottom.x + 18, bottom.y + 59, 14.0, &raw, bottom.w - 415, CYAN);
    canvas.line(bottom.x + 18, bottom.y + 88, bottom.x + bottom.w - 18, bottom.y + 88, 0x34546B);
    canvas.text(font, bottom.x + 18, bottom.y + 101, 10.0, "DECODIFICACIÓN", MUTED);
    let decoded = game.input.decoded_text();
    let decoded = if decoded.is_empty() { "MURPH, esperando tus palabras…" } else { decoded.as_str() };
    draw_single_line_fit(canvas, font, bottom.x + 18, bottom.y + 121, 17.0, decoded, bottom.w - 415, INK);
    canvas.text(font, bottom.x + 18, bottom.y + bottom.h - 27, 10.0, "ESPACIO: < 2 s = ·  /  ≥ 2 s = —     J: ·     K: —     BACKSPACE: borrar letra / mantener 3 s: borrar todo", MUTED);

    let button_x = bottom.x + bottom.w - 378;
    let send_rect = Rect { x: button_x + 250, y: bottom.y + 38, w: 110, h: 42 };
    let play_rect = Rect { x: button_x + 126, y: bottom.y + 38, w: 110, h: 42 };
    let clear_rect = Rect { x: button_x, y: bottom.y + 38, w: 110, h: 42 };
    button(canvas, font, clear_rect, "REINICIAR", false);
    button(canvas, font, play_rect, if playing { "DETENER" } else { "REPRODUCIR" }, playing);
    button(canvas, font, send_rect, if game.is_finished() { "COMPLETADO" } else { "TRANSMITIR" }, true);
    canvas.text(font, button_x, bottom.y + 96, 9.0, "ENTER: transmitir el mensaje actual", MUTED);
    canvas.text(font, button_x, bottom.y + 112, 9.0, "J / K: puntos y rayas instantáneos", MUTED);

    // Pie de pantalla.
    canvas.text(font, 31, height - 13, 9.0, "TESERACTO // PROTOCOLO MORSE // CPU RENDER", 0x7790A8);
    canvas.text(font, width - 171, height - 13, 9.0, if backgrounds.images.is_empty() { "FONDO PROCEDURAL" } else { "ARCHIVO VISUAL ACTIVO" }, 0x7790A8);

    let close_modal = if settings_open || game.is_finished() {
        let modal = Rect { x: width / 2 - 280, y: height / 2 - 185, w: 560, h: 370 };
        canvas.rect_alpha(0, 0, width, height, 0x020914, 185);
        panel(canvas, modal);
        if settings_open {
            label(canvas, font, modal.x + 28, modal.y + 25, "PROTOCOLO DE OPERACIÓN");
            canvas.text(font, modal.x + 28, modal.y + 54, 25.0, "Controles de transmisión", INK);
            let lines = [
                "BARRA ESPACIADORA  ·  Mantén menos de 2 s para punto.",
                "BARRA ESPACIADORA  —  Mantén 2 s o más para raya.",
                "J  ·  Inserta un punto.       K  —  Inserta una raya.",
                "Pausa de 0.9 s: cierra una letra; 2.3 s: separa palabras.",
                "BACKSPACE corto: elimina la letra anterior.",
                "BACKSPACE durante más de 3 s: reinicia toda la misión.",
                "ENTER o TRANSMITIR: envía el mensaje al siguiente objetivo.",
                "La exactitud compara el texto completo de las cinco frases.",
                "Acentos → vocal base; ° → DEG; ′ y ″ → ' y comillas.",
            ];
            for (i, line) in lines.iter().enumerate() {
                canvas.text(font, modal.x + 28, modal.y + 103 + i as i32 * 23, 12.0, line, if i == 8 { 0xB9C6D9 } else { INK });
            }
            canvas.text(font, modal.x + 28, modal.y + modal.h - 48, 10.0, "Coloca tus imágenes de la película en assets/backgrounds/.", CYAN);
        } else {
            label(canvas, font, modal.x + 28, modal.y + 25, "REPORTE DE TRANSMISIÓN");
            canvas.text(font, modal.x + 28, modal.y + 55, 26.0, "Enlace con Murph completado", INK);
            let accuracy = game.accuracy();
            let stars = game.stars();
            canvas.text(font, modal.x + 28, modal.y + 108, 39.0, &format!("{accuracy:.1}%"), CYAN);
            canvas.text(font, modal.x + 203, modal.y + 120, 12.0, "EXACTITUD TOTAL", MUTED);
            draw_stars(canvas, modal.x + modal.w / 2, modal.y + 199, stars, 24);
            let result = match stars {
                5 => "Transmisión excepcional. Murph comprendió casi todo.",
                4 => "Señal muy clara. La mayor parte del mensaje llegó.",
                3 => "Señal parcial. Murph logró reconstruir varias ideas.",
                2 => "Interferencia importante. La transmisión llegó incompleta.",
                1 => "Señal débil. Apenas se distinguieron algunos fragmentos.",
                _ => "La señal no pudo reconstruirse. Inténtalo de nuevo.",
            };
            let line_y = canvas.wrapped_text(font, modal.x + 28, modal.y + 246, 13.0, result, (modal.w - 56) as f32, 5, INK);
            canvas.text(font, modal.x + 28, line_y + 5, 10.0, "REINICIAR para volver a transmitir las cinco frases.", MUTED);
        }
        let close = Rect { x: modal.x + modal.w - 96, y: modal.y + 12, w: 70, h: 30 };
        button(canvas, font, close, "CERRAR", false);
        close
    } else {
        Rect { x: -100, y: -100, w: 0, h: 0 }
    };

    Hitboxes { settings: settings_rect, send: send_rect, play: play_rect, clear: clear_rect, close_modal }
}

fn draw_single_line_fit(canvas: &mut Canvas, font: &Font, x: i32, y: i32, size: f32, text: &str, max_width: i32, color: u32) {
    let mut shortened = text.to_string();
    let mut did_shorten = false;
    while !shortened.is_empty() && Canvas::measure_text(font, size, &shortened) > max_width as f32 {
        shortened.pop();
        did_shorten = true;
    }
    if did_shorten && shortened.chars().count() > 4 {
        while !shortened.is_empty() && Canvas::measure_text(font, size, &format!("{shortened}…")) > max_width as f32 {
            shortened.pop();
        }
        shortened.push('…');
    }
    canvas.text(font, x, y, size, &shortened, color);
}
