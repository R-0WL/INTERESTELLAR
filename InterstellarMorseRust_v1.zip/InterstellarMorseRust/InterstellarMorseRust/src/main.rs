mod audio;
mod game;
mod morse;
mod render;

use std::path::PathBuf;
use std::time::{Duration, Instant};

use minifb::{Key, KeyRepeat, MouseButton, MouseMode, Window, WindowOptions};

use game::GameState;
use render::{Backgrounds, Canvas};

const WIDTH: usize = 1280;
const HEIGHT: usize = 800;
const SPACE_DASH_THRESHOLD: Duration = Duration::from_secs(2);
const CLEAR_HOLD_THRESHOLD: Duration = Duration::from_secs(3);

fn main() {
    let mut window = match Window::new(
        "Teseracto Interestelar | Simulador Morse en Rust",
        WIDTH,
        HEIGHT,
        WindowOptions::default(),
    ) {
        Ok(window) => window,
        Err(error) => {
            eprintln!("No se pudo crear la ventana: {error}");
            return;
        }
    };
    window.limit_update_rate(Some(Duration::from_micros(16_600)));

    let font = match render::load_font() {
        Ok(font) => font,
        Err(error) => {
            eprintln!("{error}");
            return;
        }
    };

    let project_dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let backgrounds = Backgrounds::load(&project_dir.join("assets").join("backgrounds"), WIDTH, HEIGHT);
    let mut canvas = Canvas::new(WIDTH, HEIGHT);
    let mut game = GameState::default();
    let started = Instant::now();

    let mut settings_open = false;
    let mut playing_until: Option<Instant> = None;
    let mut space_was_down = false;
    let mut space_started: Option<Instant> = None;
    let mut backspace_was_down = false;
    let mut backspace_started: Option<Instant> = None;
    let mut backspace_cleared = false;
    let mut mouse_was_down = false;

    while window.is_open() {
        let now = Instant::now();
        let input_enabled = !settings_open && !game.is_finished();

        // La duración de la barra espaciadora determina punto o raya.
        let space_down = window.is_key_down(Key::Space);
        if input_enabled && space_down && !space_was_down {
            space_started = Some(now);
        }
        if space_was_down && !space_down {
            if input_enabled {
                if let Some(start) = space_started.take() {
                    let duration = now.saturating_duration_since(start);
                    if duration < SPACE_DASH_THRESHOLD {
                        game.input.push_held_dot(start, now);
                    } else {
                        game.input.push_held_dash(start, now);
                    }
                }
            } else {
                space_started = None;
            }
        }
        space_was_down = space_down;

        // J y K insertan pulsos inmediatos, sin depender de la duración de la tecla.
        if input_enabled && window.is_key_pressed(Key::J, KeyRepeat::No) {
            game.input.push_dot(now);
        }
        if input_enabled && window.is_key_pressed(Key::K, KeyRepeat::No) {
            game.input.push_dash(now);
        }

        // Backspace corto elimina la letra anterior; mantenerlo 3 s reinicia la misión.
        let backspace_down = window.is_key_down(Key::Backspace);
        if input_enabled && backspace_down && !backspace_was_down {
            backspace_started = Some(now);
            backspace_cleared = false;
        }
        if backspace_down && backspace_was_down && !backspace_cleared {
            if let Some(start) = backspace_started {
                if now.saturating_duration_since(start) >= CLEAR_HOLD_THRESHOLD {
                    game.clear_all();
                    audio::stop_morse();
                    backspace_cleared = true;
                    backspace_started = None;
                }
            }
        }
        if backspace_was_down && !backspace_down {
            if input_enabled && !backspace_cleared {
                if let Some(start) = backspace_started {
                    if now.saturating_duration_since(start) < CLEAR_HOLD_THRESHOLD {
                        game.input.delete_previous_letter();
                    }
                }
            }
            backspace_started = None;
            backspace_cleared = false;
        }
        backspace_was_down = backspace_down;

        // Las pausas separan letras y palabras automáticamente.
        if input_enabled && !space_down {
            game.input.update(now);
        }

        if window.is_key_pressed(Key::Escape, KeyRepeat::No) {
            settings_open = !settings_open;
        }

        if input_enabled && window.is_key_pressed(Key::Enter, KeyRepeat::No) {
            game.send_current();
            audio::stop_morse();
            playing_until = None;
        } else if game.is_finished() && window.is_key_pressed(Key::Enter, KeyRepeat::No) {
            game.clear_all();
            audio::stop_morse();
        }

        let mouse_down = window.get_mouse_down(MouseButton::Left);
        let mouse_pressed = mouse_down && !mouse_was_down;
        mouse_was_down = mouse_down;
        let mouse = window.get_mouse_pos(MouseMode::Discard);

        let hitboxes = render::render(
            &mut canvas,
            &font,
            &backgrounds,
            started,
            &game,
            settings_open,
            playing_until.map(|end| now < end).unwrap_or(false),
        );

        if mouse_pressed {
            if let Some((mx, my)) = mouse {
                if hitboxes.settings.contains(mx, my) {
                    settings_open = !settings_open;
                } else if (settings_open || game.is_finished()) && hitboxes.close_modal.contains(mx, my) {
                    settings_open = false;
                    if game.is_finished() {
                        game.clear_all();
                        audio::stop_morse();
                        playing_until = None;
                    }
                } else if !settings_open && hitboxes.clear.contains(mx, my) {
                    game.clear_all();
                    audio::stop_morse();
                    playing_until = None;
                } else if !settings_open && !game.is_finished() && hitboxes.send.contains(mx, my) {
                    game.send_current();
                    audio::stop_morse();
                    playing_until = None;
                } else if !settings_open && !game.is_finished() && hitboxes.play.contains(mx, my) {
                    let currently_playing = playing_until.map(|end| now < end).unwrap_or(false);
                    if currently_playing {
                        playing_until = None;
                        audio::stop_morse();
                    } else {
                        let patterns = game.input.patterns_for_playback();
                        if !patterns.is_empty() {
                            let millis: u64 = patterns.iter().map(|pattern| {
                                if pattern == "/" { 550 }
                                else { pattern.chars().map(|c| if c == '.' { 215 } else { 475 }).sum::<u64>() + 220 }
                            }).sum();
                            playing_until = Some(now + Duration::from_millis(millis));
                            audio::play_morse(patterns);
                        }
                    }
                }
            }
        }

        if let Err(error) = window.update_with_buffer(&canvas.buffer, WIDTH, HEIGHT) {
            eprintln!("Error al actualizar la ventana: {error}");
            break;
        }
    }
}
