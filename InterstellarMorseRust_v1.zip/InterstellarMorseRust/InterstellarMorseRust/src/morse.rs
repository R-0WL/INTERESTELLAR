//! Conversión entre texto y código Morse internacional.
//!
//! La tabla se mantiene como datos Rust y se dibuja en pantalla; no se necesita
//! una imagen externa con el alfabeto.

pub const MORSE_PAIRS: &[(char, &str)] = &[
    ('A', ".-"), ('B', "-..."), ('C', "-.-."), ('D', "-.."), ('E', "."),
    ('F', "..-."), ('G', "--."), ('H', "...."), ('I', ".."), ('J', ".---"),
    ('K', "-.-"), ('L', ".-.."), ('M', "--"), ('N', "-."), ('O', "---"),
    ('P', ".--."), ('Q', "--.-"), ('R', ".-."), ('S', "..."), ('T', "-"),
    ('U', "..-"), ('V', "...-"), ('W', ".--"), ('X', "-..-"), ('Y', "-.--"),
    ('Z', "--.."), ('Ñ', "--.--"),
    ('1', ".----"), ('2', "..---"), ('3', "...--"), ('4', "....-"), ('5', "....."),
    ('6', "-...."), ('7', "--..."), ('8', "---.."), ('9', "----."), ('0', "-----"),
    ('.', ".-.-.-"), (',', "--..--"), ('?', "..--.."), ('!', "-.-.--"),
    (':', "---..."), (';', "-.-.-."), ('+', ".-.-."), ('-', "-....-"),
    ('=', "-...-"), ('\'', ".----."), ('/', "-..-."), ('"', ".-..-."),
    ('(', "-.--."), (')', "-.--.-"), ('&', ".-..."), ('@', ".--.-."),
];

/// Convierte caracteres acentuados a su equivalente Morse más cercano.
/// El signo de grado se expande a DEG; prima y doble prima usan apóstrofo y comillas.
pub fn normalize_text(input: &str) -> String {
    let mut out = String::new();
    for ch in input.chars() {
        match ch {
            'á' | 'à' | 'ä' | 'â' | 'Á' | 'À' | 'Ä' | 'Â' => out.push('A'),
            'é' | 'è' | 'ë' | 'ê' | 'É' | 'È' | 'Ë' | 'Ê' => out.push('E'),
            'í' | 'ì' | 'ï' | 'î' | 'Í' | 'Ì' | 'Ï' | 'Î' => out.push('I'),
            'ó' | 'ò' | 'ö' | 'ô' | 'Ó' | 'Ò' | 'Ö' | 'Ô' => out.push('O'),
            'ú' | 'ù' | 'ü' | 'û' | 'Ú' | 'Ù' | 'Ü' | 'Û' => out.push('U'),
            'ñ' | 'Ñ' => out.push('Ñ'),
            '°' => out.push_str(" DEG "),
            '′' => out.push('\''),
            '″' => out.push('"'),
            c if c.is_whitespace() => out.push(' '),
            c => out.push(c.to_ascii_uppercase()),
        }
    }
    out.split_whitespace().collect::<Vec<_>>().join(" ")
}

pub fn code_for(ch: char) -> Option<&'static str> {
    MORSE_PAIRS.iter().find_map(|(letter, code)| (*letter == ch).then_some(*code))
}

pub fn decode_code(code: &str) -> Option<char> {
    MORSE_PAIRS.iter().find_map(|(letter, pattern)| (*pattern == code).then_some(*letter))
}

/// Representación de una frase como letras Morse separadas por espacios y palabras por /.
pub fn encode_text(input: &str) -> String {
    let normalized = normalize_text(input);
    let mut parts = Vec::new();
    for ch in normalized.chars() {
        if ch == ' ' {
            parts.push("/".to_string());
        } else if let Some(code) = code_for(ch) {
            parts.push(code.to_string());
        } else {
            parts.push("?".to_string());
        }
    }
    parts.join(" ")
}

pub fn pretty_code(code: &str) -> String {
    code.chars()
        .map(|c| if c == '.' { '·' } else if c == '-' { '—' } else { c })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn translates_basic_text() {
        assert_eq!(encode_text("STAY!"), "... - .- -.-- -.-.--");
        assert_eq!(decode_code("-.-.--"), Some('!'));
    }

    #[test]
    fn normalizes_coordinate_symbols() {
        assert_eq!(normalize_text("38° 52′ 59″ N"), "38 DEG 52' 59\" N");
    }
}
