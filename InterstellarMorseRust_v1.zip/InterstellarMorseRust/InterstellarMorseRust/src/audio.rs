//! Reproducción opcional de Morse. Se activa con `--features audio`.

#[cfg(feature = "audio")]
mod enabled {
    use rodio::{source::SineWave, OutputStream, Sink, Source};
    use std::sync::atomic::{AtomicBool, Ordering};
    use std::thread;
    use std::time::Duration;

    static STOP_AUDIO: AtomicBool = AtomicBool::new(false);

    pub fn play(patterns: Vec<String>) {
        STOP_AUDIO.store(false, Ordering::Relaxed);
        thread::spawn(move || {
            let Ok((_stream, handle)) = OutputStream::try_default() else {
                eprintln!("No hay dispositivo de audio disponible.");
                return;
            };
            let Ok(sink) = Sink::try_new(&handle) else {
                eprintln!("No se pudo crear el canal de audio.");
                return;
            };

            for pattern in patterns {
                if STOP_AUDIO.load(Ordering::Relaxed) { return; }
                if pattern == "/" {
                    thread::sleep(Duration::from_millis(550));
                    continue;
                }
                for symbol in pattern.chars() {
                    if STOP_AUDIO.load(Ordering::Relaxed) { return; }
                    let duration = if symbol == '.' { 130 } else { 390 };
                    sink.append(
                        SineWave::new(660.0)
                            .take_duration(Duration::from_millis(duration))
                            .amplify(0.16),
                    );
                    sink.sleep_until_end();
                    thread::sleep(Duration::from_millis(85));
                }
                thread::sleep(Duration::from_millis(220));
            }
        });
    }

    pub fn stop() {
        STOP_AUDIO.store(true, Ordering::Relaxed);
    }
}

#[cfg(feature = "audio")]
pub fn play_morse(patterns: Vec<String>) { enabled::play(patterns); }

#[cfg(feature = "audio")]
pub fn stop_morse() { enabled::stop(); }

#[cfg(not(feature = "audio"))]
pub fn play_morse(_patterns: Vec<String>) {}

#[cfg(not(feature = "audio"))]
pub fn stop_morse() {}
