# Fondos de escena

Coloca aquí las imágenes que quieras usar como fondos de la escena del teseracto.

Formatos admitidos: `.png`, `.jpg`, `.jpeg` y `.webp`.

El programa carga todas las imágenes de esta carpeta al iniciar y cambia de fondo
aproximadamente cada 22 segundos. No se incluye ninguna imagen de *Interstellar*;
usa únicamente imágenes que tengas derecho a utilizar.
