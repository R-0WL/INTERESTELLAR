# Teseracto Interestelar — Simulador Morse en Rust

Recreación en Rust del flujo principal de `MorseCodeSimulator` (entrada de pulsos,
separación de letras y palabras, traducción Morse, reproducción, borrado y guía de
referencia), adaptada como minijuego de transmisión a Murph.

La ventana se dibuja en un búfer de píxeles por CPU mediante `minifb`; no usa una
API de renderizado GPU. La interfaz y la tabla Morse se generan desde el código.
No necesita una imagen del alfabeto Morse.

## Requisitos

- Rust estable y Cargo.
- Una fuente TTF instalada en el sistema (Segoe UI/Arial en Windows o DejaVu Sans
  en Linux). El programa intenta localizarla automáticamente.
- Windows, Linux o macOS con soporte de ventana para `minifb`.

## Ejecutar

```bash
cargo run --release
```

En Windows también puedes iniciar con doble clic en `run.bat` (requiere que Cargo
esté disponible en el PATH).

El audio Morse está habilitado por defecto. Si no necesitas audio o tu sistema no
tiene un dispositivo de salida compatible, puedes compilar sin él:

```bash
cargo run --release --no-default-features
```

## Fondos personalizados

Copia varias imágenes de la escena del teseracto en `assets/backgrounds/`.
Se aceptan PNG, JPG, JPEG y WEBP. El programa las carga automáticamente y cambia
de imagen aproximadamente cada 22 segundos. La carpeta se deja sin imágenes
intencionalmente: debes añadir las imágenes que tengas derecho a utilizar.

## Controles

| Entrada | Acción |
|---|---|
| Mantener `Espacio` menos de 2 segundos | Punto `.` |
| Mantener `Espacio` 2 segundos o más | Raya `-` |
| `J` | Insertar un punto instantáneo |
| `K` | Insertar una raya instantánea |
| Pausa de 0.9 segundos | Cerrar la letra actual |
| Pausa de 2.3 segundos | Separar palabras |
| `Backspace` corto | Borrar la letra anterior |
| Mantener `Backspace` más de 3 segundos | Borrar toda la misión y empezar de nuevo |
| `Enter` | Enviar el mensaje actual a Murph |
| `Esc` | Abrir/cerrar el panel de controles |

Cada frase se envía por separado. La exactitud que determina las estrellas se
calcula comparando el texto recibido con **la totalidad de los cinco mensajes**,
no dando una puntuación independiente a cada frase. Se usa similitud basada en
distancia de edición para admitir errores y mensajes incompletos.

## Objetivos exactos

1. `STAY!`
2. `DON'T LET ME LEAVE, MURPH!`
3. `NO! NO! NO! NO!`
4. `Las coordenadas de la NASA son: 38° 52′ 59″ N  77° 00′ 59″ O`
5. `Enviando ecuación de gravedad y datos cuanticos del agujero negro`

La representación Morse normaliza las vocales acentuadas a su vocal base; `°`
se transmite como `DEG`; prima `′` se representa con apóstrofo y doble prima `″`
con comillas. La frase objetivo se sigue mostrando con su escritura original.

## Estrellas según exactitud global

| Estrellas | Exactitud |
|---:|---:|
| 5 | 90–100 % |
| 4 | 70–89 % |
| 3 | 50–69 % |
| 2 | 26–49 % |
| 1 | 15–25 % |
| 0 | 0–14 % |

## Estructura

```text
InterstellarMorseRust/
├── Cargo.toml
├── README.md
├── assets/
│   └── backgrounds/       # Añade aquí tus imágenes
└── src/
    ├── main.rs            # Ventana, controles y bucle principal
    ├── render.rs          # Renderizado CPU, interfaz y tabla Morse dinámica
    ├── morse.rs           # Alfabeto, codificación y decodificación
    ├── game.rs            # Secuencia de mensajes, temporizadores y puntuación global
    └── audio.rs            # Reproducción de tono opcional
```

## Notas de implementación

- `minifb` presenta un búfer de píxeles escrito por la CPU; no se usa OpenGL,
  Vulkan, Direct3D ni shaders.
- Las letras y números de la guía se generan iterando la tabla `MORSE_PAIRS`.
- La separación automática permite introducir una letra con pulsos cercanos y
  pasar de palabra con una pausa más larga. `Enter` cierra el mensaje actual.
- La frase de coordenadas conserva los símbolos Unicode en pantalla y usa una
  transcripción inequívoca para Morse, indicada en el panel de ayuda.
