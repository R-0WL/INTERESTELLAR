use crate::game::{GameState, ModuleStatus};
use crate::render::Framebuffer;

const CYAN: u32 = 0x45D9D2;
const CYAN_DIM: u32 = 0x1A7978;
const WHITE: u32 = 0xD7E5E5;
const MUTED: u32 = 0x779293;
const GREEN: u32 = 0x36D58A;
const AMBER: u32 = 0xF4B942;
const ORANGE: u32 = 0xF07836;
const RED: u32 = 0xF04455;
const PANEL: u32 = 0x06171B;
const GRID: u32 = 0x16454A;

pub fn draw_hud(frame: &mut Framebuffer, game: &GameState) {
    let panel_w = ((frame.width as f32 * 0.46) as i32).clamp(420, 540);
    let panel_h = 398;
    let px = frame.width as i32 - panel_w - 14;
    let py = frame.height as i32 - panel_h - 12;

    frame.alpha_rect(px, py, panel_w, panel_h, PANEL, 0.91);
    frame.rect(px, py, panel_w, panel_h, CYAN_DIM);
    frame.line(px + 1, py + 25, px + panel_w - 1, py + 25, GRID);

    frame.text(px + 12, py + 8, "ENDURANCE // FLIGHT SYSTEMS", CYAN, 1);
    let system = if game.lost { "SYSTEM FAILURE" } else if game.won { "ESCAPE CONFIRMED" } else { "SYSTEM ONLINE" };
    let status_color = if game.lost { RED } else if game.won { GREEN } else { GREEN };
    frame.text(px + panel_w - (system.len() as i32 * 8) - 12, py + 8, system, status_color, 1);

    let mut y = py + 32;
    frame.text(px + 12, y, "AUXILIARY SYSTEM MENU-2", MUTED, 1);
    frame.text(px + panel_w - 150, y, "GARGANTUA APPROACH", MUTED, 1);
    y += 16;

    let card_h = 52;
    for (i, module) in game.modules.iter().enumerate() {
        let card_y = y + i as i32 * (card_h + 3);
        let selected = game.selected_module == i;
        let state = match module.status {
            ModuleStatus::Attached if i == 2 => "ACTIVE",
            ModuleStatus::Attached => "ATTACHED",
            ModuleStatus::Detaching => "DETACHING",
            ModuleStatus::Detached => "RELEASED",
        };
        let state_color = match module.status {
            ModuleStatus::Detached => MUTED,
            ModuleStatus::Detaching => AMBER,
            ModuleStatus::Attached if i == 2 => GREEN,
            ModuleStatus::Attached => CYAN,
        };
        frame.alpha_rect(px + 7, card_y, panel_w - 14, card_h, 0x0A2529, if selected { 0.9 } else { 0.58 });
        frame.rect(px + 7, card_y, panel_w - 14, card_h, if selected { CYAN } else { GRID });
        frame.text(px + 15, card_y + 6, &format!("0{}  {}", i + 1, module.name), WHITE, 1);
        frame.text(px + panel_w - (state.len() as i32 * 8) - 18, card_y + 6, state, state_color, 1);
        draw_schematic(frame, px + 17, card_y + 24, i, module.status == ModuleStatus::Detached);

        let detail = match i {
            0 => "RGT / LFT MAIN [ENG]   LANDER-1 THRUSTERS",
            1 => "FWD / LWR MAIN [ENG]   RANGER-2 PROPULSION",
            _ => "MAIN PROPULSION [ENG]   ORIENTATION SYSTEM",
        };
        frame.text(px + 77, card_y + 24, detail, if module.status == ModuleStatus::Detached { MUTED } else { WHITE }, 1);
        let fuel_label = format!("FUEL {:05.1}%", module.fuel_percent);
        frame.text(px + 77, card_y + 37, &fuel_label, MUTED, 1);
        bar(frame, px + panel_w - 100, card_y + 39, 79, 5, module.fuel_percent, CYAN);
    }

    let telemetry_y = y + 3 * (card_h + 3) + 5;
    frame.line(px + 8, telemetry_y, px + panel_w - 8, telemetry_y, GRID);
    frame.text(px + 12, telemetry_y + 7, "FLIGHT TELEMETRY", WHITE, 1);
    let col_w = (panel_w - 32) / 2;
    let metrics = [
        ("VELOCITY", game.speed, 100.0, format!("{:05.1} %", game.speed)),
        ("ENGINE POWER", game.engine_power, 100.0, format!("{:05.1} %", game.engine_power)),
        ("TOTAL FUEL", game.total_fuel_percent(), 100.0, format!("{:05.1} %", game.total_fuel_percent())),
        ("SHIP MASS", game.attached_mass(), 240.0, format!("{:05.1} T", game.attached_mass())),
        ("GRAVITY PROXIMITY", game.gravity_proximity, 100.0, format!("{:05.1} %", game.gravity_proximity)),
        ("ESCAPE TRAJECTORY", game.escape_progress, 100.0, format!("{:05.1} %", game.escape_progress)),
    ];
    for (i, (label, value, max, number)) in metrics.iter().enumerate() {
        let col = i % 2;
        let row = i / 2;
        let x = px + 12 + col as i32 * col_w;
        let yy = telemetry_y + 23 + row as i32 * 21;
        frame.text(x, yy, label, MUTED, 1);
        let value_x = x + col_w - (number.len() as i32 * 8);
        frame.text(value_x, yy, number, WHITE, 1);
        let color = if *label == "GRAVITY PROXIMITY" { risk_color(*value) } else { CYAN };
        bar(frame, x, yy + 10, col_w - 8, 5, *value / *max * 100.0, color);
    }

    let seq_y = telemetry_y + 92;
    frame.line(px + 8, seq_y, px + panel_w - 8, seq_y, GRID);
    frame.text(px + 12, seq_y + 7, "MANEUVER CONTROL", WHITE, 1);
    let stage = game.stage_label();
    frame.text(px + panel_w - (stage.len() as i32 * 8) - 12, seq_y + 7, &stage, CYAN, 1);

    let labels = ["LANDER", "RANGER 2", "ENDURANCE"];
    let cell_gap = 4;
    let cell_w = (panel_w - 32 - cell_gap * 2) / 3;
    for i in 0..3 {
        let x = px + 12 + i as i32 * (cell_w + cell_gap);
        let color = match game.modules[i].status {
            ModuleStatus::Detached => MUTED,
            ModuleStatus::Detaching => AMBER,
            ModuleStatus::Attached if i == game.selected_module => CYAN,
            ModuleStatus::Attached => GRID,
        };
        frame.rect(x, seq_y + 24, cell_w, 19, color);
        frame.text(x + 5, seq_y + 30, labels[i], if game.selected_module == i { WHITE } else { MUTED }, 1);
    }
    let next = game.next_action();
    let next_color = if game.current_window() { GREEN } else { AMBER };
    frame.text(px + 12, seq_y + 49, next, next_color, 1);
    let window_status = game.separation_window_status();
    let window_color = if game.current_window() { GREEN }
        else if window_status.contains("MISSED") { RED }
        else { AMBER };
    frame.text(px + 12, seq_y + 64, &window_status, window_color, 1);

    if game.show_diagnostics {
        let bottom = py - 102;
        frame.alpha_rect(px, bottom, panel_w, 92, 0x071A20, 0.94);
        frame.rect(px, bottom, panel_w, 92, CYAN_DIM);
        frame.text(px + 10, bottom + 8, "FLIGHT DIAGNOSTICS // MODULE STATUS", CYAN, 1);
        let l = &game.modules[0];
        let r = &game.modules[1];
        let e = &game.modules[2];
        let module_line = format!("LND {:04.1}T {:02.0}% | RNG {:04.1}T {:02.0}% | END {:04.1}T {:02.0}%",
            l.dry_mass + l.fuel_capacity * l.fuel_percent / 100.0 * 0.65, l.fuel_percent,
            r.dry_mass + r.fuel_capacity * r.fuel_percent / 100.0 * 0.65, r.fuel_percent,
            e.dry_mass + e.fuel_capacity * e.fuel_percent / 100.0 * 0.65, e.fuel_percent);
        frame.text(px + 10, bottom + 25, &module_line, WHITE, 1);
        frame.text(px + 10, bottom + 42, &format!("TRAJECTORY {:+05.1} DEG   ATTITUDE {:+05.1} DEG   HORIZON {:05.1}", game.trajectory_angle, game.orientation, game.distance_to_horizon), WHITE, 1);
        frame.text(px + 10, bottom + 61, "W/S POWER   A/D TRAJECTORY   Q/E ATTITUDE   SPACE RELEASE", MUTED, 1);
        frame.text(px + 10, bottom + 76, "SHIFT BOOST   1-3 / ARROWS SELECT   TAB CLOSE DIAGNOSTICS", MUTED, 1);
    }

    if game.notice_seconds > 0.0 {
        let notice_w = (game.notice.len() as i32 * 8 + 22).min(frame.width as i32 - 24);
        let nx = 12;
        let ny = frame.height as i32 - 34;
        frame.alpha_rect(nx, ny, notice_w, 22, 0x071A20, 0.92);
        frame.rect(nx, ny, notice_w, 22, if game.lost { RED } else { CYAN_DIM });
        frame.text(nx + 9, ny + 7, &game.notice, if game.lost { RED } else { CYAN }, 1);
    }

    if game.won || game.lost {
        let title = if game.won { "ESCAPE SUCCESSFUL" } else { "MISSION FAILED" };
        let color = if game.won { GREEN } else { RED };
        let w = title.len() as i32 * 16 + 36;
        let x = (frame.width as i32 - w) / 2;
        let yy = frame.height as i32 / 2 - 28;
        frame.alpha_rect(x, yy, w, 58, 0x061318, 0.95);
        frame.rect(x, yy, w, 58, color);
        frame.text(x + 18, yy + 14, title, color, 2);
        frame.text(x + 18, yy + 38, "PRESS ESC TO EXIT", WHITE, 1);
    }
}

fn draw_schematic(frame: &mut Framebuffer, x: i32, y: i32, module: usize, released: bool) {
    let c = if released { 0x3B5557 } else { CYAN_DIM };
    match module {
        0 => {
            frame.line(x + 4, y + 1, x + 18, y + 1, c);
            frame.line(x + 4, y + 1, x + 11, y + 17, c);
            frame.line(x + 18, y + 1, x + 11, y + 17, c);
            frame.line(x + 7, y + 7, x + 15, y + 7, c);
            frame.circle(x + 11, y + 9, 2, c);
        }
        1 => {
            frame.rect(x + 2, y + 5, 23, 8, c);
            frame.line(x + 2, y + 5, x - 2, y + 1, c);
            frame.line(x + 25, y + 5, x + 29, y + 1, c);
            frame.line(x + 2, y + 13, x - 2, y + 17, c);
            frame.line(x + 25, y + 13, x + 29, y + 17, c);
        }
        _ => {
            frame.circle(x + 13, y + 9, 10, c);
            frame.circle(x + 13, y + 9, 5, c);
            frame.line(x + 13, y - 2, x + 13, y + 20, c);
            frame.line(x + 2, y + 9, x + 24, y + 9, c);
        }
    }
}

fn bar(frame: &mut Framebuffer, x: i32, y: i32, w: i32, h: i32, value: f32, color: u32) {
    frame.fill_rect(x, y, w, h, 0x153B3E);
    let filled = ((w as f32) * value.clamp(0.0, 100.0) / 100.0) as i32;
    frame.fill_rect(x, y, filled, h, color);
    // Segmentos discretos para conservar la estética de instrumental.
    let mut sx = x + 11;
    while sx < x + w {
        frame.fill_rect(sx, y, 1, h, 0x082126);
        sx += 12;
    }
}

fn risk_color(value: f32) -> u32 {
    if value < 35.0 { CYAN } else if value < 58.0 { AMBER } else if value < 78.0 { ORANGE } else { RED }
}
