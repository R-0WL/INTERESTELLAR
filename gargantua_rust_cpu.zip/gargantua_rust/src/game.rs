use glam::Vec3;
use minifb::Key;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ModuleStatus { Attached, Detaching, Detached }

#[derive(Clone, Debug)]
pub struct ModuleState {
    pub name: &'static str,
    pub model_key: &'static str,
    pub status: ModuleStatus,
    pub dry_mass: f32,
    pub fuel_capacity: f32,
    pub fuel_percent: f32,
    pub attached_offset: Vec3,
    pub detached_position: Vec3,
    pub detached_velocity: Vec3,
    pub detaching_seconds: f32,
    pub scale: f32,
}

pub struct GameState {
    pub modules: Vec<ModuleState>,
    pub selected_module: usize,
    pub speed: f32,
    pub engine_power: f32,
    pub trajectory_angle: f32,
    pub orientation: f32,
    pub distance_to_horizon: f32,
    pub gravity_proximity: f32,
    pub escape_progress: f32,
    pub boost_seconds: f32,
    pub elapsed: f32,
    pub won: bool,
    pub lost: bool,
    pub show_diagnostics: bool,
    pub notice: String,
    pub notice_seconds: f32,
    pub ship_position: Vec3,
}

impl GameState {
    pub fn new() -> Self {
        Self {
            modules: vec![
                ModuleState {
                    name: "LANDER", model_key: "lander", status: ModuleStatus::Attached,
                    dry_mass: 18.0, fuel_capacity: 20.0, fuel_percent: 72.0,
                    attached_offset: Vec3::new(23.0, 4.0, 0.0),
                    detached_position: Vec3::ZERO, detached_velocity: Vec3::ZERO, detaching_seconds: 0.0, scale: 3.0,
                },
                ModuleState {
                    name: "RANGER 2", model_key: "ranger", status: ModuleStatus::Attached,
                    dry_mass: 31.0, fuel_capacity: 34.0, fuel_percent: 68.0,
                    attached_offset: Vec3::new(14.0, -1.0, 0.0),
                    detached_position: Vec3::ZERO, detached_velocity: Vec3::ZERO, detaching_seconds: 0.0, scale: 1.2,
                },
                ModuleState {
                    name: "ENDURANCE", model_key: "endurance", status: ModuleStatus::Attached,
                    dry_mass: 72.0, fuel_capacity: 100.0, fuel_percent: 84.0,
                    attached_offset: Vec3::ZERO,
                    detached_position: Vec3::ZERO, detached_velocity: Vec3::ZERO, detaching_seconds: 0.0, scale: 0.52,
                },
            ],
            selected_module: 0,
            speed: 14.0,
            engine_power: 54.0,
            trajectory_angle: 0.0,
            orientation: 0.0,
            distance_to_horizon: 120.0,
            gravity_proximity: 0.0,
            escape_progress: 14.0,
            boost_seconds: 0.0,
            elapsed: 0.0,
            won: false,
            lost: false,
            show_diagnostics: false,
            notice: "FLIGHT SYSTEMS ONLINE // AWAITING MANEUVER".to_string(),
            notice_seconds: 5.0,
            ship_position: Vec3::new(0.0, 0.0, 18.0),
        }
    }

    pub fn current_stage(&self) -> usize {
        self.modules.iter().filter(|m| m.status == ModuleStatus::Detached).count()
    }

    pub fn attached_mass(&self) -> f32 {
        self.modules.iter().filter(|m| m.status == ModuleStatus::Attached)
            .map(|m| m.dry_mass + m.fuel_capacity * (m.fuel_percent / 100.0) * 0.65).sum()
    }

    pub fn total_fuel_percent(&self) -> f32 {
        // El denominador conserva la capacidad inicial: el combustible de un módulo
        // liberado deja de estar disponible para Endurance.
        let initial_capacity: f32 = self.modules.iter().map(|m| m.fuel_capacity).sum();
        if initial_capacity <= 0.0 { return 0.0; }
        let available: f32 = self.modules.iter()
            .filter(|m| m.status == ModuleStatus::Attached)
            .map(|m| m.fuel_capacity * m.fuel_percent / 100.0)
            .sum();
        (available / initial_capacity * 100.0).clamp(0.0, 100.0)
    }

    pub fn current_window(&self) -> bool {
        if self.modules.iter().any(|m| m.status == ModuleStatus::Detaching) { return false; }
        let stage = self.current_stage();
        let (min_speed, max_speed, max_gravity) = match stage {
            0 => (27.0, 60.0, 58.0),
            1 => (59.0, 91.0, 84.0),
            _ => return false,
        };
        let alignment = self.trajectory_angle.abs() <= 17.0;
        self.speed >= min_speed && self.speed <= max_speed
            && self.gravity_proximity <= max_gravity && alignment && self.total_fuel_percent() > 3.0
    }

    pub fn separation_window_status(&self) -> String {
        if self.modules.iter().any(|m| m.status == ModuleStatus::Detaching) {
            return "SEP WINDOW: SEPARATION SETTLING".to_string();
        }
        let stage = self.current_stage();
        let (min_speed, max_speed, max_gravity) = match stage {
            0 => (27.0, 60.0, 58.0),
            1 => (59.0, 91.0, 84.0),
            _ => return "SEP WINDOW: N/A // ENDURANCE FINAL STAGE".to_string(),
        };
        if self.total_fuel_percent() <= 3.0 {
            return "SEP WINDOW: LOCKED // LOW PROPELLANT".to_string();
        }
        if self.trajectory_angle.abs() > 17.0 {
            return "SEP WINDOW: ALIGN TRAJECTORY WITHIN +/-17 DEG".to_string();
        }
        if self.gravity_proximity >= max_gravity {
            return "SEP WINDOW: MISSED // GRAVITY LIMIT".to_string();
        }
        if self.speed > max_speed {
            return "SEP WINDOW: MISSED // SPEED LIMIT".to_string();
        }
        let alignment = (1.0 - self.trajectory_angle.abs() / 55.0).clamp(0.2, 1.0);
        let acceleration = (self.engine_power / 100.0) * 2.65 * (125.0 / self.attached_mass().max(28.0)) * alignment;
        if acceleration < 0.015 {
            return "SEP WINDOW: INCREASE ENGINE POWER".to_string();
        }
        if self.speed < min_speed {
            let seconds = (min_speed - self.speed) / acceleration;
            return format!("SEP WINDOW: OPENS IN T-{seconds:04.1}s");
        }
        let speed_seconds = (max_speed - self.speed).max(0.0) / acceleration;
        let approach_rate = 0.34 + self.speed * 0.0055 + self.trajectory_angle.abs() * 0.006;
        let gravity_rate = approach_rate * (100.0 / 92.0);
        let gravity_seconds = (max_gravity - self.gravity_proximity).max(0.0) / gravity_rate.max(0.01);
        let seconds = speed_seconds.min(gravity_seconds);
        format!("SEP WINDOW: OPEN // CLOSES IN T-{seconds:04.1}s")
    }

    pub fn next_module_index(&self) -> Option<usize> {
        match self.current_stage() { 0 => Some(0), 1 => Some(1), _ => None }
    }

    pub fn handle_key(&mut self, key: Key) {
        match key {
            Key::Key1 => self.selected_module = 0,
            Key::Key2 => self.selected_module = 1,
            Key::Key3 => self.selected_module = 2,
            Key::Left => self.selected_module = self.selected_module.saturating_sub(1),
            Key::Right => self.selected_module = (self.selected_module + 1).min(2),
            Key::Tab => self.show_diagnostics = !self.show_diagnostics,
            Key::Space => self.release_selected(),
            Key::LeftShift | Key::RightShift => self.activate_boost(),
            _ => {}
        }
    }

    pub fn release_selected(&mut self) {
        let Some(required) = self.next_module_index() else {
            self.set_notice("SEPARATION SEQUENCE COMPLETE // ENDURANCE ONLY", 3.0);
            return;
        };
        if self.selected_module != required {
            self.set_notice(format!("SEQUENCE LOCK // SELECT {} FIRST", self.modules[required].name), 2.5);
            return;
        }
        if !self.current_window() {
            self.set_notice("RELEASE INHIBITED // CONDITIONS OUTSIDE SAFE WINDOW", 2.8);
            return;
        }

        let module_name = self.modules[required].name;
        {
            let module = &mut self.modules[required];
            module.status = ModuleStatus::Detaching;
            module.detaching_seconds = 0.35; // Estado lógico provisional; el movimiento visual se añadirá después.
            let side = if required == 0 { 1.0 } else { -1.0 };
            module.detached_position = self.ship_position + module.attached_offset;
            module.detached_velocity = Vec3::new(side * 1.4, 0.25, -0.4);
        }
        self.selected_module = (required + 1).min(2);
        self.set_notice(format!("{module_name} DETACHING // MASS RECALCULATED"), 3.0);
    }

    fn activate_boost(&mut self) {
        if self.lost || self.won { return; }
        if self.boost_seconds > 0.0 {
            self.set_notice("BOOST ALREADY ACTIVE", 1.8);
        } else if self.total_fuel_percent() < 8.0 {
            self.set_notice("BOOST DENIED // INSUFFICIENT PROPELLANT", 2.0);
        } else {
            self.boost_seconds = 4.5;
            self.set_notice("AUXILIARY FUEL INJECTION // BOOST ACTIVE", 2.5);
        }
    }

    pub fn update(&mut self, dt: f32, keys: &[Key]) {
        if self.won || self.lost { return; }
        let dt = dt.clamp(0.0, 0.05);
        self.elapsed += dt;
        if self.notice_seconds > 0.0 { self.notice_seconds -= dt; }

        let mut throttle = 0.0;
        if keys.contains(&Key::W) { throttle += 1.0; }
        if keys.contains(&Key::S) { throttle -= 1.0; }
        self.engine_power = (self.engine_power + throttle * 38.0 * dt).clamp(0.0, 100.0);

        let mut steering = 0.0;
        if keys.contains(&Key::A) { steering -= 1.0; }
        if keys.contains(&Key::D) { steering += 1.0; }
        self.trajectory_angle = (self.trajectory_angle + steering * 19.0 * dt).clamp(-42.0, 42.0);

        let mut attitude = 0.0;
        if keys.contains(&Key::Q) { attitude -= 1.0; }
        if keys.contains(&Key::E) { attitude += 1.0; }
        self.orientation = (self.orientation + attitude * 24.0 * dt).clamp(-90.0, 90.0);

        let mass = self.attached_mass().max(28.0);
        let fuel_fraction = self.total_fuel_percent() / 100.0;
        let boost_multiplier = if self.boost_seconds > 0.0 { 1.9 } else { 1.0 };
        let alignment = (1.0 - self.trajectory_angle.abs() / 55.0).clamp(0.2, 1.0);
        let acceleration = (self.engine_power / 100.0) * 2.65 * (125.0 / mass) * alignment * boost_multiplier;
        if fuel_fraction > 0.0 && self.engine_power > 0.0 {
            self.speed += acceleration * dt;
            let burn = (self.engine_power / 100.0) * 0.78 * boost_multiplier * dt;
            // Los depósitos conectados alimentan el conjunto de propulsión.
            // Al separar un módulo, su combustible residual sale del inventario útil.
            for module in &mut self.modules {
                if module.status == ModuleStatus::Attached {
                    module.fuel_percent = (module.fuel_percent - burn).max(0.0);
                }
            }
        }
        if self.boost_seconds > 0.0 { self.boost_seconds = (self.boost_seconds - dt).max(0.0); }

        // El acercamiento al horizonte aumenta con la velocidad y con una trayectoria desalineada.
        let approach_rate = 0.34 + self.speed * 0.0055 + self.trajectory_angle.abs() * 0.006;
        self.distance_to_horizon = (self.distance_to_horizon - approach_rate * dt).max(0.0);
        self.gravity_proximity = ((120.0 - self.distance_to_horizon) / 92.0 * 100.0).clamp(0.0, 100.0);
        let approach = 120.0 - self.distance_to_horizon;
        self.ship_position = Vec3::new(
            self.trajectory_angle * 0.08,
            self.orientation * 0.025,
            18.0 - approach * 0.45 - self.elapsed * 0.01,
        );
        let alignment_factor = (1.0 - self.trajectory_angle.abs() / 48.0).clamp(0.0, 1.0);
        self.escape_progress = (self.speed * alignment_factor).clamp(0.0, 100.0);

        let mut separation_completed = false;
        let current_ship_position = self.ship_position;
        for module in &mut self.modules {
            match module.status {
                ModuleStatus::Detaching => {
                    module.detached_position = current_ship_position + module.attached_offset;
                    module.detaching_seconds -= dt;
                    if module.detaching_seconds <= 0.0 {
                        module.status = ModuleStatus::Detached;
                        separation_completed = true;
                    }
                }
                ModuleStatus::Detached => {
                    module.detached_position += module.detached_velocity * dt;
                }
                ModuleStatus::Attached => {}
            }
        }
        if separation_completed {
            self.set_notice("MODULE CLEAR // NEXT STAGE AVAILABLE", 2.0);
        }

        if self.current_stage() == 2 && self.speed >= 100.0 && self.distance_to_horizon > 19.0 && self.trajectory_angle.abs() < 16.0 {
            self.won = true;
            self.set_notice("ESCAPE VELOCITY ACHIEVED // MANEUVER SUCCESS", 30.0);
        } else if self.distance_to_horizon <= 9.0 {
            self.lost = true;
            self.set_notice("CRITICAL LIMIT // EVENT HORIZON CROSSED", 30.0);
        } else if self.total_fuel_percent() <= 0.0 && self.speed < 100.0 {
            self.lost = true;
            self.set_notice("PROPELLANT DEPLETED // ESCAPE FAILED", 30.0);
        }
    }

    pub fn set_notice(&mut self, message: impl Into<String>, seconds: f32) {
        self.notice = message.into();
        self.notice_seconds = seconds;
    }

    pub fn stage_label(&self) -> String {
        format!("STAGE {:02} / 03", (self.current_stage() + 1).min(3))
    }

    pub fn next_action(&self) -> &'static str {
        if self.won { return "MISSION STATUS: ESCAPE CONFIRMED"; }
        if self.lost { return "MISSION STATUS: FLIGHT TERMINATED"; }
        if self.modules.iter().any(|m| m.status == ModuleStatus::Detaching) {
            return "SEPARATION IN PROGRESS // STAND BY";
        }
        match self.next_module_index() {
            Some(0) if self.current_window() => "NEXT ACTION: RELEASE LANDER NOW",
            Some(0) => "NEXT ACTION: ALIGN / BUILD VELOCITY",
            Some(1) if self.current_window() => "NEXT ACTION: RELEASE RANGER 2 NOW",
            Some(1) => "NEXT ACTION: PREPARE RANGER SEPARATION",
            _ if self.won => "MISSION STATUS: ESCAPE CONFIRMED",
            _ if self.lost => "MISSION STATUS: FLIGHT TERMINATED",
            _ => "NEXT ACTION: FINAL ENDURANCE BURN",
        }
    }
}


#[cfg(test)]
mod tests {
    use super::*;

    fn open_lander_window(game: &mut GameState) {
        game.speed = 40.0;
        game.engine_power = 50.0;
        game.gravity_proximity = 20.0;
        game.trajectory_angle = 0.0;
    }

    #[test]
    fn space_does_not_skip_the_lander_stage() {
        let mut game = GameState::new();
        open_lander_window(&mut game);
        game.selected_module = 1;
        game.release_selected();
        assert_eq!(game.modules[0].status, ModuleStatus::Attached);
        assert_eq!(game.modules[1].status, ModuleStatus::Attached);
    }

    #[test]
    fn separation_is_individual_and_reduces_mass() {
        let mut game = GameState::new();
        open_lander_window(&mut game);
        let before = game.attached_mass();
        game.release_selected();
        assert_eq!(game.modules[0].status, ModuleStatus::Detaching);
        assert!(game.attached_mass() < before);
        assert_eq!(game.modules[1].status, ModuleStatus::Attached);
        for _ in 0..8 { game.update(0.05, &[]); }
        assert_eq!(game.modules[0].status, ModuleStatus::Detached);
        assert_eq!(game.current_stage(), 1);
    }

    #[test]
    fn release_is_denied_outside_the_window() {
        let mut game = GameState::new();
        game.speed = 14.0;
        game.release_selected();
        assert_eq!(game.modules[0].status, ModuleStatus::Attached);
    }
}
