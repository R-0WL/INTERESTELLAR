use glam::{Mat4, Vec2, Vec3};
use gltf::image::Format;
use std::path::Path;

#[derive(Clone, Copy, Debug)]
pub struct Vertex {
    pub position: Vec3,
    pub normal: Vec3,
    pub uv: Vec2,
}

#[derive(Clone, Debug)]
pub struct Triangle {
    pub vertices: [Vertex; 3],
    pub color: [f32; 4],
    pub texture: Option<usize>,
}

#[derive(Clone, Debug)]
pub struct Texture {
    pub width: usize,
    pub height: usize,
    pub pixels: Vec<[u8; 4]>,
}

impl Texture {
    pub fn sample(&self, uv: Vec2) -> [f32; 4] {
        if self.width == 0 || self.height == 0 || self.pixels.is_empty() {
            return [1.0, 1.0, 1.0, 1.0];
        }
        let u = uv.x.rem_euclid(1.0);
        let v = uv.y.rem_euclid(1.0);
        let x = ((u * self.width as f32) as usize).min(self.width - 1);
        let y = (((1.0 - v) * self.height as f32) as usize).min(self.height - 1);
        let c = self.pixels[y * self.width + x];
        [c[0] as f32 / 255.0, c[1] as f32 / 255.0, c[2] as f32 / 255.0, c[3] as f32 / 255.0]
    }
}

#[derive(Clone, Debug)]
pub struct Model {
    pub name: String,
    pub triangles: Vec<Triangle>,
    pub textures: Vec<Texture>,
}

impl Model {
    pub fn load(path: impl AsRef<Path>, name: &str, triangle_limit: usize) -> Result<Self, String> {
        let path = path.as_ref();
        let (document, buffers, images) = gltf::import(path)
            .map_err(|e| format!("No se pudo abrir {}: {e}", path.display()))?;

        let textures: Vec<Texture> = images.iter().map(convert_image).collect();
        let mut model = Self { name: name.to_string(), triangles: Vec::new(), textures };
        let scene = document.default_scene().or_else(|| document.scenes().next())
            .ok_or_else(|| format!("{} no contiene una escena GLB", path.display()))?;

        for node in scene.nodes() {
            collect_node(node, Mat4::IDENTITY, &buffers, triangle_limit, &mut model)?;
        }

        if model.triangles.is_empty() {
            return Err(format!("{} no contiene triángulos renderizables", path.display()));
        }

        // Recentrar la geometría sin modificar las proporciones del GLB.
        let mut min = Vec3::splat(f32::INFINITY);
        let mut max = Vec3::splat(f32::NEG_INFINITY);
        for tri in &model.triangles {
            for v in tri.vertices {
                min = min.min(v.position);
                max = max.max(v.position);
            }
        }
        let center = (min + max) * 0.5;
        for tri in &mut model.triangles {
            for v in &mut tri.vertices {
                v.position -= center;
            }
        }
        Ok(model)
    }
}

fn collect_node(
    node: gltf::Node<'_>,
    parent: Mat4,
    buffers: &[gltf::buffer::Data],
    triangle_limit: usize,
    output: &mut Model,
) -> Result<(), String> {
    let local = Mat4::from_cols_array_2d(&node.transform().matrix());
    let world = parent * local;

    if let Some(mesh) = node.mesh() {
        for primitive in mesh.primitives() {
            if primitive.mode() != gltf::mesh::Mode::Triangles {
                continue;
            }
            let reader = primitive.reader(|buffer| Some(&buffers[buffer.index()]));
            let Some(positions_iter) = reader.read_positions() else { continue; };
            let positions: Vec<Vec3> = positions_iter.map(Vec3::from_array).collect();
            let normals: Option<Vec<Vec3>> = reader.read_normals()
                .map(|iter| iter.map(Vec3::from_array).collect());
            let uvs: Option<Vec<Vec2>> = reader.read_tex_coords(0)
                .map(|iter| iter.into_f32().map(Vec2::from_array).collect());
            let indices: Vec<u32> = reader.read_indices()
                .map(|iter| iter.into_u32().collect())
                .unwrap_or_else(|| (0..positions.len() as u32).collect());

            let material = primitive.material().pbr_metallic_roughness();
            let color = material.base_color_factor();
            let texture = material.base_color_texture().map(|info| info.texture().source().index());
            let face_count = indices.len() / 3;
            if face_count == 0 { continue; }
            let already = output.triangles.len();
            let remaining = triangle_limit.saturating_sub(already);
            if remaining == 0 { return Ok(()); }
            let stride = ((face_count + remaining - 1) / remaining).max(1);

            for face in (0..face_count).step_by(stride) {
                let idx = [indices[face * 3] as usize, indices[face * 3 + 1] as usize, indices[face * 3 + 2] as usize];
                if idx.iter().any(|&i| i >= positions.len()) { continue; }
                let p = [
                    world.transform_point3(positions[idx[0]]),
                    world.transform_point3(positions[idx[1]]),
                    world.transform_point3(positions[idx[2]]),
                ];
                let face_normal = (p[1] - p[0]).cross(p[2] - p[0]).normalize_or_zero();
                let mut vertices = [
                    Vertex { position: p[0], normal: face_normal, uv: Vec2::ZERO },
                    Vertex { position: p[1], normal: face_normal, uv: Vec2::ZERO },
                    Vertex { position: p[2], normal: face_normal, uv: Vec2::ZERO },
                ];
                for corner in 0..3 {
                    if let Some(ns) = &normals {
                        if idx[corner] < ns.len() {
                            vertices[corner].normal = world.transform_vector3(ns[idx[corner]]).normalize_or_zero();
                        }
                    }
                    if let Some(tex) = &uvs {
                        if idx[corner] < tex.len() { vertices[corner].uv = tex[idx[corner]]; }
                    }
                }
                output.triangles.push(Triangle { vertices, color, texture });
                if output.triangles.len() >= triangle_limit { return Ok(()); }
            }
        }
    }

    for child in node.children() {
        collect_node(child, world, buffers, triangle_limit, output)?;
    }
    Ok(())
}

fn convert_image(image: &gltf::image::Data) -> Texture {
    let mut pixels = Vec::with_capacity(image.width as usize * image.height as usize);
    match image.format {
        Format::R8 => {
            for &v in image.pixels.iter() { pixels.push([v, v, v, 255]); }
        }
        Format::R8G8 => {
            for p in image.pixels.chunks_exact(2) { pixels.push([p[0], p[0], p[0], p[1]]); }
        }
        Format::R8G8B8 => {
            for p in image.pixels.chunks_exact(3) { pixels.push([p[0], p[1], p[2], 255]); }
        }
        Format::R8G8B8A8 => {
            for p in image.pixels.chunks_exact(4) { pixels.push([p[0], p[1], p[2], p[3]]); }
        }
        Format::R16 => {
            for p in image.pixels.chunks_exact(2) { let v = p[1]; pixels.push([v, v, v, 255]); }
        }
        Format::R16G16 => {
            for p in image.pixels.chunks_exact(4) { pixels.push([p[1], p[1], p[1], p[3]]); }
        }
        Format::R16G16B16 => {
            for p in image.pixels.chunks_exact(6) { pixels.push([p[1], p[3], p[5], 255]); }
        }
        Format::R16G16B16A16 => {
            for p in image.pixels.chunks_exact(8) { pixels.push([p[1], p[3], p[5], p[7]]); }
        }
        Format::R32G32B32FLOAT => {
            for p in image.pixels.chunks_exact(12) {
                let r = f32::from_le_bytes([p[0], p[1], p[2], p[3]]);
                let g = f32::from_le_bytes([p[4], p[5], p[6], p[7]]);
                let b = f32::from_le_bytes([p[8], p[9], p[10], p[11]]);
                pixels.push([(r.clamp(0.0, 1.0) * 255.0) as u8, (g.clamp(0.0, 1.0) * 255.0) as u8, (b.clamp(0.0, 1.0) * 255.0) as u8, 255]);
            }
        }
        Format::R32G32B32A32FLOAT => {
            for p in image.pixels.chunks_exact(16) {
                let r = f32::from_le_bytes([p[0], p[1], p[2], p[3]]);
                let g = f32::from_le_bytes([p[4], p[5], p[6], p[7]]);
                let b = f32::from_le_bytes([p[8], p[9], p[10], p[11]]);
                let a = f32::from_le_bytes([p[12], p[13], p[14], p[15]]);
                pixels.push([(r.clamp(0.0, 1.0) * 255.0) as u8, (g.clamp(0.0, 1.0) * 255.0) as u8, (b.clamp(0.0, 1.0) * 255.0) as u8, (a.clamp(0.0, 1.0) * 255.0) as u8]);
            }
        }
    }
    Texture { width: image.width as usize, height: image.height as usize, pixels }
}
