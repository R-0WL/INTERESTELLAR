mod game;
mod hud;
mod model;
mod render;

use game::{GameState, ModuleStatus};
use glam::{Mat4, Quat, Vec3};
use minifb::{Key, KeyRepeat, UseGPU, Window, WindowOptions};
use model::Model;
use render::Framebuffer;
use std::collections::HashMap;
use std::time::Instant;

const WIDTH: usize = 1024;
const HEIGHT: usize = 576;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("GARGANTUA // CPU FRAMEBUFFER RENDERER");
    println!("Loading GLB assets...");

    let mut models = HashMap::<&'static str, Model>::new();
    models.insert("blackhole", Model::load("assets/blackhole.glb", "Gargantua", 8_500)?);
    models.insert("endurance", Model::load("assets/interstellar__endurance.glb", "Endurance", 6_000)?);
    models.insert("ranger", Model::load("assets/ranger_ship_of_interstellar_free.glb", "Ranger 2", 2_200)?);
    models.insert("lander", Model::load("assets/lander.glb", "Lander", 1_500)?);

    for model in models.values() {
        println!("  {}: {} triangles / {} textures", model.name, model.triangles.len(), model.textures.len());
    }

    let options = WindowOptions {
        use_gpu: UseGPU::Disabled,
        ..WindowOptions::default()
    };
    let mut window = Window::new(
        "GARGANTUA // ORBITAL ESCAPE",
        WIDTH,
        HEIGHT,
        options,
    )?;
    window.set_target_fps(60);

    let mut frame = Framebuffer::new(WIDTH, HEIGHT);
    let mut game = GameState::new();
    let mut last_frame = Instant::now();

    while window.is_open() && !window.is_key_down(Key::Escape) {
        let now = Instant::now();
        let dt = now.duration_since(last_frame).as_secs_f32();
        last_frame = now;

        for key in window.get_keys_pressed(KeyRepeat::No) {
            game.handle_key(key);
        }
        let mut held = Vec::with_capacity(6);
        for key in [Key::W, Key::S, Key::A, Key::D, Key::Q, Key::E] {
            if window.is_key_down(key) { held.push(key); }
        }
        game.update(dt, &held);

        render_world(&mut frame, &models, &game);
        hud::draw_hud(&mut frame, &game);
        draw_help(&mut frame);

        window.update_with_buffer(&frame.color, WIDTH, HEIGHT)?;
    }
    Ok(())
}

fn render_world(frame: &mut Framebuffer, models: &HashMap<&'static str, Model>, game: &GameState) {
    frame.clear(0x02050B);
    draw_starfield(frame);

    let camera_position = Vec3::new(0.0, 22.0, 112.0);
    let camera_target = Vec3::new(0.0, 0.0, -18.0);
    let view = Mat4::look_at_rh(camera_position, camera_target, Vec3::Y);
    let projection = Mat4::perspective_rh(52.0_f32.to_radians(), WIDTH as f32 / HEIGHT as f32, 0.1, 500.0);
    let view_projection = projection * view;

    if let Some(blackhole) = models.get("blackhole") {
        let transform = Mat4::from_scale_rotation_translation(
            Vec3::splat(19.0),
            Quat::from_rotation_x(std::f32::consts::FRAC_PI_2),
            Vec3::new(0.0, 0.0, -28.0),
        );
        frame.draw_model(blackhole, transform, view_projection);
    }

    let ship_position = game.ship_position;

    // El casco principal conserva su modelo; los módulos siguen siendo objetos independientes.
    for module in &game.modules {
        let world_position = match module.status {
            ModuleStatus::Attached | ModuleStatus::Detaching => ship_position + module.attached_offset,
            ModuleStatus::Detached => module.detached_position,
        };
        let rotation = match module.model_key {
            "endurance" => Quat::from_rotation_y(std::f32::consts::FRAC_PI_2)
                * Quat::from_rotation_z(game.orientation.to_radians() * 0.18),
            "ranger" => Quat::from_rotation_y(0.35) * Quat::from_rotation_z(-0.12),
            _ => Quat::from_rotation_y(-0.35),
        };
        let scale = Vec3::splat(module.scale);
        let transform = Mat4::from_scale_rotation_translation(scale, rotation, world_position);
        if let Some(model) = models.get(module.model_key) {
            frame.draw_model(model, transform, view_projection);
        }
    }

    // Marcador discreto de la zona de navegación segura.
    draw_navigation_arc(frame, game.gravity_proximity);
}

fn draw_starfield(frame: &mut Framebuffer) {
    // Patrón determinista: no hace falta RNG ni memoria adicional por frame.
    for i in 0..210usize {
        let x = ((i * 197 + 73) % WIDTH) as i32;
        let y = ((i * 113 + i * i * 7 + 29) % HEIGHT) as i32;
        let brightness = 95 + ((i * 31) % 130) as u32;
        let color = (brightness << 16) | ((brightness / 3) << 8) | (brightness / 2);
        frame.pixel(x, y, color);
        if i % 29 == 0 { frame.pixel(x + 1, y, 0x668A9A); }
    }
}

fn draw_navigation_arc(frame: &mut Framebuffer, gravity: f32) {
    let cx = 170;
    let cy = 205;
    let radius = 68;
    let color = if gravity < 35.0 { 0x268C8C } else if gravity < 60.0 { 0xD39A35 } else if gravity < 80.0 { 0xE87538 } else { 0xE64050 };
    let mut previous: Option<(i32, i32)> = None;
    for degree in 205..336 {
        let a = (degree as f32).to_radians();
        let p = (cx + (a.cos() * radius as f32) as i32, cy + (a.sin() * radius as f32) as i32);
        if let Some(prev) = previous { frame.line(prev.0, prev.1, p.0, p.1, 0x18373E); }
        previous = Some(p);
    }
    let needle_angle = (205.0 + gravity * 1.3).clamp(205.0, 335.0).to_radians();
    frame.line(cx, cy, cx + (needle_angle.cos() * 54.0) as i32, cy + (needle_angle.sin() * 54.0) as i32, color);
    frame.circle(cx, cy, 4, 0x61DCD2);
    frame.text(cx - 47, cy + 77, "GRAVITY FIELD", 0x749194, 1);
    frame.text(cx - 25, cy + 89, &format!("{:03.0}%", gravity), color, 1);
}

fn draw_help(frame: &mut Framebuffer) {
    frame.alpha_rect(14, 14, 280, 76, 0x06171C, 0.72);
    frame.rect(14, 14, 280, 76, 0x16454A);
    frame.text(25, 24, "GARGANTUA // FLIGHT DIRECTOR", 0x45D9D2, 1);
    frame.text(25, 43, "W/S POWER    A/D TRAJECTORY", 0xA8C2C2, 1);
    frame.text(25, 58, "Q/E ATTITUDE   SPACE RELEASE", 0xA8C2C2, 1);
    frame.text(25, 73, "SHIFT BOOST   TAB SYSTEMS", 0xA8C2C2, 1);
}
