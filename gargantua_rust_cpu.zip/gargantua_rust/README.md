# GARGANTUA // Orbital Escape (Rust / CPU framebuffer)

Prototipo jugable de lanzamiento orbital por etapas. Renderiza los modelos GLB con un rasterizador de triángulos por software y presenta el resultado en una ventana `minifb`. No usa shaders, OpenGL, Vulkan, DirectX ni un pipeline de renderizado GPU.

## Estado de esta entrega

Implementado:

- Carga de `blackhole.glb`, `interstellar__endurance.glb`, `ranger_ship_of_interstellar_free.glb` y `lander.glb`.
- Rasterización por CPU con z-buffer, proyección en perspectiva, iluminación difusa y muestreo de texturas GLB.
- `minifb` recibe el framebuffer ya calculado por CPU y se configura con `UseGPU::Disabled` para solicitar presentación por software en los backends que exponen esa opción.
- Fondo espacial y modelo de Gargantúa.
- Nave compuesta por Endurance, Ranger 2 y Lander.
- Máquina de estados `Attached` → `Detaching` → `Detached` por módulo (el estado intermedio es lógico; aún no tiene movimiento visual).
- Separación individual con `SPACE`, bloqueada fuera de la ventana de seguridad, con estimación de apertura/cierre y validada en el orden Lander → Ranger 2.
- Los módulos liberados se conservan como objetos independientes y continúan su trayectoria.
- Recalculo de masa, combustible disponible y respuesta de aceleración al cambiar la configuración.
- Gestión de potencia, trayectoria, orientación, combustible e impulso.
- Condiciones de victoria y derrota asociadas a velocidad de escape, combustible y proximidad al horizonte.
- HUD de telemetría inspirado en la referencia proporcionada, con estados de módulos, motores, barras segmentadas, secuencia y alertas.
- Animaciones de transición de separación aplazadas intencionalmente. La separación lógica ocurre sin desplazamiento animado en esta entrega.

Pendiente para una siguiente iteración:

- Animación visual de desacoplamiento: la máquina de estados `Attached → Detaching → Detached` ya existe, pero el movimiento/efecto de transición se implementará en la última etapa.
- Ajuste fino de las posiciones relativas de Ranger 2 y Lander sobre Endurance. Los GLB son modelos independientes y no incluyen un archivo de ensamblaje común.
- Calibración de balance y rendimiento en la máquina objetivo.
- Soporte de mando: se deja fuera del prototipo, tal como se solicitó.

## Requisitos

- Rust estable y Cargo.
- Windows, Linux o macOS con soporte de ventana para `minifb`.

## Ejecutar

Desde esta carpeta:

```bash
cargo run --release
```

Para ejecutar las pruebas de lógica incluidas:

```bash
cargo test
```

Esta entrega no incluye `Cargo.lock`; Cargo resolverá las versiones compatibles de las dependencias al primer build.

El modo `--release` es importante para el rasterizador por software. Los modelos se cargan desde `assets/`, por lo que hay que ejecutar el programa desde la raíz del proyecto.

## Controles

| Tecla | Acción |
|---|---|
| `W` / `S` | Aumentar / reducir potencia |
| `A` / `D` | Ajustar trayectoria |
| `Q` / `E` | Ajustar orientación |
| `SPACE` | Liberar únicamente el módulo seleccionado y requerido por la secuencia |
| `SHIFT` | Impulso de combustible |
| `1` / `2` / `3` | Seleccionar Lander / Ranger 2 / Endurance |
| `←` / `→` | Cambiar módulo seleccionado |
| `TAB` | Mostrar / ocultar diagnóstico de controles |
| `ESC` | Salir |

### Mando (no implementado)

```text
Stick izquierdo: trayectoria
RT / LT: potencia
A (Xbox) / X (PlayStation): liberar módulo
B / Círculo: activar impulso
RB / LB: cambiar módulo seleccionado
```

## Notas técnicas

- El framebuffer usa 1024 × 576 píxeles.
- Los modelos se limitan a un presupuesto de triángulos al cargarse para reducir el coste de rasterización por CPU.
- Los materiales GLB conservan factor de color y textura base cuando existe.
- El renderizado 3D/2D se calcula por CPU y escribe directamente en el framebuffer. No hay shaders, OpenGL, Vulkan, DirectX ni pipeline GPU de renderizado. `UseGPU::Disabled` solicita escalado por CPU en los backends que respetan esa opción; minifb documenta que Wayland es el único backend que la consulta actualmente, X11 escala por software y Windows presenta mediante GDI, mientras que macOS usa GPU para la presentación nativa de la ventana. Esa presentación del sistema operativo no participa en el cálculo de los píxeles del juego.
- La física es un modelo arcade normalizado para el minijuego, no una simulación astrodinámica realista.
- El panel inferior derecho está construido con primitivas 2D dibujadas directamente sobre el mismo framebuffer.
