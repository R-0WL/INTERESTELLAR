use std::time::{Duration, Instant};

use crate::morse::{decode_code, normalize_text};

pub const TARGET_MESSAGES: [&str; 5] = [
    "STAY!",
    "DON'T LET ME LEAVE, MURPH!",
    "NO! NO! NO! NO!",
    "Las coordenadas de la NASA son: 38° 52′ 59″ N  77° 00′ 59″ O",
    "Enviando ecuación de gravedad y datos cuanticos del agujero negro",
];

const LETTER_GAP: Duration = Duration::from_millis(900);
const WORD_GAP: Duration = Duration::from_millis(2_300);

#[derive(Clone, Debug)]
enum InputToken {
    Letter(String),
    Space,
}

#[derive(Debug, Default)]
pub struct InputBuffer {
    tokens: Vec<InputToken>,
    current_code: String,
    last_pulse: Option<Instant>,
    word_gap_added: bool,
}

impl InputBuffer {
    pub fn push_dot(&mut self, now: Instant) {
        self.push_symbol_timed('.', now, now);
    }

    pub fn push_dash(&mut self, now: Instant) {
        self.push_symbol_timed('-', now, now);
    }

    /// Para la barra espaciadora: separa la pausa al comenzar la pulsación,
    /// pero marca el pulso al soltarla. Así una raya de más de 2 s no se convierte
    /// accidentalmente en un espacio de palabra mientras se mantiene la tecla.
    pub fn push_held_dot(&mut self, pressed_at: Instant, released_at: Instant) {
        self.push_symbol_timed('.', pressed_at, released_at);
    }

    pub fn push_held_dash(&mut self, pressed_at: Instant, released_at: Instant) {
        self.push_symbol_timed('-', pressed_at, released_at);
    }

    fn push_symbol_timed(&mut self, symbol: char, pause_check_at: Instant, pulse_at: Instant) {
        self.update(pause_check_at);
        self.current_code.push(symbol);
        self.last_pulse = Some(pulse_at);
        self.word_gap_added = false;
    }

    /// Cierra una letra tras una pausa y añade el separador de palabra tras una pausa mayor.
    pub fn update(&mut self, now: Instant) {
        let Some(last) = self.last_pulse else { return; };
        let elapsed = now.saturating_duration_since(last);

        if elapsed >= LETTER_GAP && !self.current_code.is_empty() {
            self.finish_letter();
        }
        if elapsed >= WORD_GAP && !self.word_gap_added {
            self.push_word_space();
            self.word_gap_added = true;
        }
    }

    pub fn finish_letter(&mut self) {
        if !self.current_code.is_empty() {
            self.tokens.push(InputToken::Letter(std::mem::take(&mut self.current_code)));
        }
    }

    fn push_word_space(&mut self) {
        if !self.current_code.is_empty() {
            self.finish_letter();
        }
        if !matches!(self.tokens.last(), Some(InputToken::Space)) {
            self.tokens.push(InputToken::Space);
        }
    }

    pub fn decoded_text(&self) -> String {
        let mut out = String::new();
        for token in &self.tokens {
            match token {
                InputToken::Letter(code) => out.push(decode_code(code).unwrap_or('#')),
                InputToken::Space => out.push(' '),
            }
        }
        if !self.current_code.is_empty() {
            out.push(decode_code(&self.current_code).unwrap_or('#'));
        }
        out
    }

    pub fn displayed_morse(&self) -> String {
        let mut chunks = Vec::new();
        for token in &self.tokens {
            match token {
                InputToken::Letter(code) => chunks.push(code.clone()),
                InputToken::Space => chunks.push("/".to_string()),
            }
        }
        if !self.current_code.is_empty() {
            chunks.push(self.current_code.clone());
        }
        chunks.join("   ")
    }

    pub fn current_code(&self) -> &str {
        &self.current_code
    }

    pub fn is_empty(&self) -> bool {
        self.tokens.is_empty() && self.current_code.is_empty()
    }

    /// Elimina la letra en edición; si no hay una, elimina primero un separador `/`
    /// pendiente y, en la siguiente pulsación, la letra completa anterior.
    pub fn delete_previous_letter(&mut self) {
        if !self.current_code.is_empty() {
            self.current_code.clear();
            self.last_pulse = None;
            self.word_gap_added = false;
            return;
        }

        match self.tokens.last() {
            Some(InputToken::Space) => { self.tokens.pop(); }
            Some(InputToken::Letter(_)) => { self.tokens.pop(); }
            None => {}
        }
        self.last_pulse = None;
        self.word_gap_added = false;
    }

    pub fn clear(&mut self) {
        self.tokens.clear();
        self.current_code.clear();
        self.last_pulse = None;
        self.word_gap_added = false;
    }

    pub fn finish_message(&mut self) -> String {
        self.finish_letter();
        self.decoded_text().trim().to_string()
    }

    pub fn patterns_for_playback(&self) -> Vec<String> {
        let mut result = Vec::new();
        for token in &self.tokens {
            match token {
                InputToken::Letter(code) => result.push(code.clone()),
                InputToken::Space => result.push("/".to_string()),
            }
        }
        if !self.current_code.is_empty() {
            result.push(self.current_code.clone());
        }
        result
    }
}

#[derive(Debug)]
pub struct GameState {
    pub input: InputBuffer,
    pub submitted: Vec<String>,
}

impl Default for GameState {
    fn default() -> Self {
        Self { input: InputBuffer::default(), submitted: Vec::new() }
    }
}

impl GameState {
    pub fn current_message_index(&self) -> usize {
        self.submitted.len().min(TARGET_MESSAGES.len())
    }

    pub fn is_finished(&self) -> bool {
        self.submitted.len() >= TARGET_MESSAGES.len()
    }

    pub fn send_current(&mut self) {
        if self.is_finished() { return; }
        let message = self.input.finish_message();
        self.submitted.push(message);
        self.input.clear();
    }

    /// Borra toda la sesión, incluidas las transmisiones ya enviadas.
    pub fn clear_all(&mut self) {
        self.submitted.clear();
        self.input.clear();
    }

    pub fn accuracy(&self) -> f32 {
        let expected = TARGET_MESSAGES
            .iter()
            .map(|message| normalize_text(message))
            .collect::<Vec<_>>()
            .join(" ");

        let mut actual_parts = self.submitted.clone();
        if !self.is_finished() {
            let live = self.input.decoded_text().trim().to_string();
            if !live.is_empty() || actual_parts.is_empty() {
                actual_parts.push(live);
            }
        }
        let actual = actual_parts
            .iter()
            .map(|message| normalize_text(message))
            .collect::<Vec<_>>()
            .join(" ");

        if actual.is_empty() { return 0.0; }
        let expected_chars: Vec<char> = expected.chars().collect();
        let actual_chars: Vec<char> = actual.chars().collect();
        let denominator = expected_chars.len().max(actual_chars.len()).max(1);
        let distance = levenshtein(&expected_chars, &actual_chars);
        (1.0 - distance as f32 / denominator as f32).clamp(0.0, 1.0) * 100.0
    }

    pub fn stars(&self) -> u8 {
        let accuracy = self.accuracy().floor();
        if accuracy >= 90.0 { 5 }
        else if accuracy >= 70.0 { 4 }
        else if accuracy >= 50.0 { 3 }
        else if accuracy >= 26.0 { 2 }
        else if accuracy >= 15.0 { 1 }
        else { 0 }
    }

    pub fn progress_fraction(&self) -> f32 {
        let expected_len: usize = TARGET_MESSAGES.iter().map(|m| normalize_text(m).chars().count()).sum();
        let submitted_len: usize = self.submitted.iter().map(|m| m.chars().count()).sum();
        let current_len = self.input.decoded_text().chars().count();
        ((submitted_len + current_len) as f32 / expected_len.max(1) as f32).clamp(0.0, 1.0)
    }
}

fn levenshtein(a: &[char], b: &[char]) -> usize {
    if a.is_empty() { return b.len(); }
    if b.is_empty() { return a.len(); }

    let mut previous: Vec<usize> = (0..=b.len()).collect();
    let mut current = vec![0usize; b.len() + 1];
    for (i, ca) in a.iter().enumerate() {
        current[0] = i + 1;
        for (j, cb) in b.iter().enumerate() {
            let substitution = previous[j] + usize::from(ca != cb);
            let insertion = current[j] + 1;
            let deletion = previous[j + 1] + 1;
            current[j + 1] = substitution.min(insertion).min(deletion);
        }
        std::mem::swap(&mut previous, &mut current);
    }
    previous[b.len()]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn backspace_removes_word_separator_before_previous_letter() {
        let mut input = InputBuffer::default();
        let now = Instant::now();
        input.push_dot(now);
        input.finish_letter();
        input.tokens.push(InputToken::Space);

        input.delete_previous_letter();
        assert_eq!(input.displayed_morse(), ".");
        assert_eq!(input.decoded_text(), "E");
    }

    #[test]
    fn backspace_removes_the_previous_letter_after_separator_is_gone() {
        let mut input = InputBuffer::default();
        let now = Instant::now();
        input.push_dot(now);
        input.finish_letter();
        input.tokens.push(InputToken::Space);

        input.delete_previous_letter();
        input.delete_previous_letter();
        assert!(input.is_empty());
    }

    #[test]
    fn backspace_clears_the_letter_being_edited() {
        let mut input = InputBuffer::default();
        let now = Instant::now();
        input.push_dot(now);
        input.push_dash(now + Duration::from_millis(10));

        input.delete_previous_letter();
        assert!(input.current_code().is_empty());
        assert!(input.is_empty());
    }

    #[test]
    fn global_accuracy_reaches_one_hundred_for_all_exact_messages() {
        let mut game = GameState::default();
        game.submitted = TARGET_MESSAGES.iter().map(|message| message.to_string()).collect();
        assert!((game.accuracy() - 100.0).abs() < 0.001);
        assert_eq!(game.stars(), 5);
    }

    #[test]
    fn accuracy_is_global_even_during_the_first_message() {
        let mut game = GameState::default();
        game.input.push_dot(Instant::now());
        assert!(game.accuracy() <= 1.0);
    }
}
