# Cambios de interfaz, escala y movimiento orbital (v3)

## Escala gigante

Los radios de los cuerpos principales se multiplicaron por `PLANET_SCALE = 4.0` respecto de v2. La nave mantiene su tamaño, por lo que es claramente pequeña frente a los mundos y puede maniobrar alrededor de ellos.

| Cuerpo | Radio v2 | Radio v3 |
|---|---:|---:|
| Tierra | 180 | 720 |
| Luna | 54 | 216 |
| Marte | 105 | 420 |
| Júpiter | 350 | 1,400 |
| Saturno | 300 | 1,200 |
| Sol | 300 | 1,200 |
| Gargantúa | 185 | 740 |
| Miller | 135 | 540 |
| Mann | 115 | 460 |
| Edmund | 125 | 500 |

Las distancias entre centros también se ampliaron deliberadamente. El recorrido no sigue unidades astronómicas reales: usa un corredor más largo y legible para evitar que los planetas gigantes se amontonen.

## Movimiento orbital

Las posiciones se actualizan cada frame de simulación, no solo se dibujan las órbitas.

- Tierra, Marte, Júpiter y Saturno orbitan el Sol.
- La Luna orbita la Tierra.
- Miller, Mann y Edmund orbitan Gargantúa.
- Los planetas exteriores tienen velocidades angulares menores; la velocidad tangencial resultante mantiene un desplazamiento lento pero perceptible.
- El minimapa, la detección de proximidad, el HUD y las distancias de aterrizaje consultan las posiciones actualizadas.
- Si la nave está aterrizada, se desplaza con el planeta mientras este completa su órbita.

Los movimientos son circulares y simplificados, adecuados para el proyecto didáctico; no representan una simulación gravitatoria astronómica.

## Minimapa

- `M` muestra u oculta el minimapa de la esquina superior derecha.
- La posición de la nave y los cuerpos se actualiza junto con la simulación.
- Las guías circulares reflejan los radios orbitales actuales del sistema.
- El mapa cambia de centro (Sol / Gargantúa) después del agujero de gusano.

## Menú

- `↑` / `↓` cambian el modo seleccionado.
- `Enter` abre el modo seleccionado.
- Exploración inicia el recorrido libre. Historia y Niveles siguen siendo pantallas de presentación hasta desarrollar sus campañas.
- `Backspace` vuelve al menú principal durante la exploración.
