//! Journey data and flight simulation, separated from drawing code.

use crate::math::{clamp, distance, length, normalize, smoothstep, vec3, Vec3};

/// Current visual scale: each major celestial body uses 15 times its base
/// radius (rather than the previous 4x pass). The ship intentionally stays small.
pub const PLANET_SCALE: f32 = 15.0;
/// One astronomical unit is compressed to this many game-world units.
/// Increasing it alongside PLANET_SCALE preserves generous clearance between
/// the enlarged planets while keeping the real relative orbital distances.
pub const AU_SCALE: f32 = 30_000.0;
/// Stylized orbital radii around Gargantua. They leave a large empty central
/// volume for a dedicated black-hole OBJ and keep the planets outside its disk.
pub const GARGANTUA_MILLER_ORBIT: f32 = 85_000.0;
pub const GARGANTUA_MANN_ORBIT: f32 = 155_000.0;
pub const GARGANTUA_EDMUND_ORBIT: f32 = 235_000.0;
pub const EARTH_ORBIT_PERIOD_SECONDS: f32 = 300.0;
pub const ASTEROID_BELT_INNER_AU: f32 = 2.1;
pub const ASTEROID_BELT_OUTER_AU: f32 = 3.3;
pub const GARGANTUA_RADIUS: f32 = 185.0 * PLANET_SCALE;
pub fn gargantua_position() -> Vec3 { vec3(0.0, -112.0, -1_125_000.0) }
/// Enter the second system outside Edmund's orbit, then fly inward toward the
/// central black hole and its widely spaced orbital worlds.
pub fn wormhole_exit() -> Vec3 { gargantua_position() + vec3(0.0, 12.0, 275_000.0) }

/// The wormhole stays beyond Saturn's enlarged rings and accompanies the planet.
fn wormhole_saturn_offset() -> Vec3 { vec3(18_000.0, 3_900.0, 0.0) }

fn solar_z(orbital_radius_au: f32) -> f32 {
    AU_SCALE - orbital_radius_au * AU_SCALE
}

fn kepler_period_seconds(orbital_radius_au: f32) -> f32 {
    EARTH_ORBIT_PERIOD_SECONDS * orbital_radius_au.powf(1.5)
}

fn angular_speed_for_period(period_seconds: f32) -> f32 {
    std::f32::consts::TAU / period_seconds
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PlanetKind {
    Mercury,
    Venus,
    Earth,
    Sun,
    Moon,
    Mars,
    AsteroidBelt,
    Jupiter,
    Saturn,
    Uranus,
    Neptune,
    Wormhole,
    Docking,
    MillerWater,
    MannIce,
    EdmundHabitable,
    Gargantua,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum GamePhase {
    Launch,
    Cruise,
    Flyby,
    Transition,
    Arrival,
    Landed,
    Destroyed,
    Completed,
}

impl GamePhase {
    pub fn label(self) -> &'static str {
        match self {
            Self::Launch => "LAUNCH",
            Self::Cruise => "CRUISE",
            Self::Flyby => "FLYBY",
            Self::Transition => "WORMHOLE",
            Self::Arrival => "ARRIVAL",
            Self::Landed => "LANDED",
            Self::Destroyed => "DESTROYED",
            Self::Completed => "COMPLETED",
        }
    }
}

#[derive(Clone, Debug)]
pub struct SpaceBody {
    pub id: &'static str,
    pub label: &'static str,
    pub kind: PlanetKind,
    pub position: Vec3,
    pub radius: f32,
    pub landable: bool,
    pub description: &'static str,
    pub reveal_distance: f32,
}

pub fn journey_bodies() -> Vec<SpaceBody> {
    // Planet positions are initialized on the same radial line to make the
    // whole route easy to read from the starting point. Their orbital radii
    // follow approximate real AU ratios, compressed by AU_SCALE.
    let belt_center_au = (ASTEROID_BELT_INNER_AU + ASTEROID_BELT_OUTER_AU) * 0.5;
    vec![
        SpaceBody {
            id: "earth", label: "EARTH", kind: PlanetKind::Earth,
            position: vec3(0.0, 0.0, solar_z(1.0)), radius: 180.0 * PLANET_SCALE, landable: true,
            description: "Blue home world. The orbital reference completes one revolution every five minutes.",
            reveal_distance: 18_000.0,
        },
        SpaceBody {
            id: "moon", label: "MOON", kind: PlanetKind::Moon,
            position: vec3(6_500.0, 0.0, solar_z(1.0)), radius: 54.0 * PLANET_SCALE, landable: true,
            description: "A small grey companion world, cratered and airless.",
            reveal_distance: 10_000.0,
        },
        SpaceBody {
            id: "mercury", label: "MERCURY", kind: PlanetKind::Mercury,
            position: vec3(0.0, 0.0, solar_z(0.387)), radius: 70.0 * PLANET_SCALE, landable: true,
            description: "The innermost rocky planet, covered in ancient impact craters.",
            reveal_distance: 16_000.0,
        },
        SpaceBody {
            id: "venus", label: "VENUS", kind: PlanetKind::Venus,
            position: vec3(0.0, 0.0, solar_z(0.723)), radius: 171.0 * PLANET_SCALE, landable: true,
            description: "A dense golden atmosphere hides the volcanic surface below.",
            reveal_distance: 18_000.0,
        },
        SpaceBody {
            id: "mars", label: "MARS", kind: PlanetKind::Mars,
            position: vec3(0.0, 0.0, solar_z(1.524)), radius: 105.0 * PLANET_SCALE, landable: true,
            description: "Dusty red terrain, a thin atmosphere, and polar ice haze.",
            reveal_distance: 50_000.0,
        },
        SpaceBody {
            id: "asteroids", label: "ASTEROID BELT", kind: PlanetKind::AsteroidBelt,
            position: vec3(0.0, 0.0, solar_z(belt_center_au)), radius: 190.0 * PLANET_SCALE, landable: false,
            description: "A complete annular field of rocky fragments between Mars and Jupiter.",
            reveal_distance: 55_000.0,
        },
        SpaceBody {
            id: "jupiter", label: "JUPITER", kind: PlanetKind::Jupiter,
            position: vec3(0.0, 0.0, solar_z(5.203)), radius: 350.0 * PLANET_SCALE, landable: false,
            description: "An immense banded gas giant with a red storm system.",
            reveal_distance: 50_000.0,
        },
        SpaceBody {
            id: "sun", label: "THE SUN", kind: PlanetKind::Sun,
            position: vec3(0.0, 0.0, AU_SCALE), radius: 300.0 * PLANET_SCALE, landable: false,
            description: "The star at the center of the Solar System.",
            reveal_distance: f32::INFINITY,
        },
        SpaceBody {
            id: "saturn", label: "SATURN", kind: PlanetKind::Saturn,
            position: vec3(0.0, 0.0, solar_z(9.537)), radius: 300.0 * PLANET_SCALE, landable: false,
            description: "Pale gold atmosphere and a dense field of icy rings.",
            reveal_distance: 60_000.0,
        },
        SpaceBody {
            id: "uranus", label: "URANUS", kind: PlanetKind::Uranus,
            position: vec3(0.0, 0.0, solar_z(19.191)), radius: 263.0 * PLANET_SCALE, landable: false,
            description: "A distant ice giant with a blue-green atmosphere and a tilted axis.",
            reveal_distance: 85_000.0,
        },
        SpaceBody {
            id: "neptune", label: "NEPTUNE", kind: PlanetKind::Neptune,
            position: vec3(0.0, 0.0, solar_z(30.069)), radius: 255.0 * PLANET_SCALE, landable: false,
            description: "A deep blue ice giant at the edge of the planetary region.",
            reveal_distance: 110_000.0,
        },
        SpaceBody {
            id: "wormhole", label: "SOLAR SYSTEM WORMHOLE", kind: PlanetKind::Wormhole,
            position: vec3(18_000.0, 3_900.0, solar_z(9.537)), radius: 38.0 * PLANET_SCALE, landable: false,
            description: "A stable spacetime anomaly travelling beside Saturn.",
            reveal_distance: 75_000.0,
        },
        SpaceBody {
            id: "docking", label: "ENDURANCE DOCKING", kind: PlanetKind::Docking,
            position: gargantua_position() + vec3(1_500.0, 12.0, 265_000.0), radius: 20.0 * PLANET_SCALE, landable: false,
            description: "Docking rotation matched. A new galaxy lies ahead.",
            reveal_distance: 45_000.0,
        },
        SpaceBody {
            id: "gargantua", label: "GARGANTUA", kind: PlanetKind::Gargantua,
            position: gargantua_position(), radius: GARGANTUA_RADIUS, landable: false,
            description: "Event horizon, photon ring, and a violent accretion disk.",
            reveal_distance: 320_000.0,
        },
        SpaceBody {
            id: "miller", label: "MILLER'S PLANET", kind: PlanetKind::MillerWater,
            position: gargantua_position() + vec3(0.0, -58.0, GARGANTUA_MILLER_ORBIT), radius: 135.0 * PLANET_SCALE, landable: true,
            description: "A water world close enough to feel Gargantua's pull.",
            reveal_distance: 120_000.0,
        },
        SpaceBody {
            id: "mann", label: "MANN'S PLANET", kind: PlanetKind::MannIce,
            position: gargantua_position() + vec3(0.0, -132.0, GARGANTUA_MANN_ORBIT), radius: 115.0 * PLANET_SCALE, landable: true,
            description: "Frozen atmosphere, fractured ice crust, and a weak beacon.",
            reveal_distance: 160_000.0,
        },
        SpaceBody {
            id: "edmund", label: "EDMUND'S PLANET", kind: PlanetKind::EdmundHabitable,
            position: gargantua_position() + vec3(0.0, 120.0, GARGANTUA_EDMUND_ORBIT), radius: 125.0 * PLANET_SCALE, landable: true,
            description: "Habitable signatures detected. Journey endpoint acquired.",
            reveal_distance: 70_000.0,
        },
    ]
}

/// One body moving on a circular orbit in the XZ plane.
#[derive(Clone, Debug)]
struct OrbitalMotion {
    body_kind: PlanetKind,
    center_kind: PlanetKind,
    radius: f32,
    y_offset: f32,
    phase: f32,
    initial_phase: f32,
    angular_speed: f32,
}

fn build_orbits(bodies: &[SpaceBody]) -> Vec<OrbitalMotion> {
    let definitions = [
        // Kepler's third law: P^2 is proportional to a^3. With Earth set to
        // exactly 300 seconds, every other solar planet keeps that period ratio.
        (PlanetKind::Mercury, PlanetKind::Sun, angular_speed_for_period(kepler_period_seconds(0.387))),
        (PlanetKind::Venus, PlanetKind::Sun, angular_speed_for_period(kepler_period_seconds(0.723))),
        (PlanetKind::Earth, PlanetKind::Sun, angular_speed_for_period(EARTH_ORBIT_PERIOD_SECONDS)),
        (PlanetKind::Mars, PlanetKind::Sun, angular_speed_for_period(kepler_period_seconds(1.524))),
        (PlanetKind::Jupiter, PlanetKind::Sun, angular_speed_for_period(kepler_period_seconds(5.203))),
        (PlanetKind::Saturn, PlanetKind::Sun, angular_speed_for_period(kepler_period_seconds(9.537))),
        (PlanetKind::Uranus, PlanetKind::Sun, angular_speed_for_period(kepler_period_seconds(19.191))),
        (PlanetKind::Neptune, PlanetKind::Sun, angular_speed_for_period(kepler_period_seconds(30.069))),
        // The Moon's sidereal period is scaled by its real ratio to Earth's year.
        (PlanetKind::Moon, PlanetKind::Earth, angular_speed_for_period(EARTH_ORBIT_PERIOD_SECONDS * (27.321_661_f32 / 365.256_363_f32))),
        // The second-system planets are deliberately far from Gargantua so a
        // custom OBJ black-hole model and its compact accretion rings have room.
        // Their periods follow Kepler-like ratios from the innermost orbit.
        (PlanetKind::MillerWater, PlanetKind::Gargantua, angular_speed_for_period(2_100.0)),
        (PlanetKind::MannIce, PlanetKind::Gargantua, angular_speed_for_period(2_100.0 * (GARGANTUA_MANN_ORBIT / GARGANTUA_MILLER_ORBIT).powf(1.5))),
        (PlanetKind::EdmundHabitable, PlanetKind::Gargantua, angular_speed_for_period(2_100.0 * (GARGANTUA_EDMUND_ORBIT / GARGANTUA_MILLER_ORBIT).powf(1.5))),
    ];

    definitions
        .iter()
        .filter_map(|(body_kind, center_kind, angular_speed)| {
            let body = bodies.iter().find(|body| body.kind == *body_kind)?;
            let center = bodies.iter().find(|body| body.kind == *center_kind)?;
            let offset = body.position - center.position;
            let radius = (offset.x * offset.x + offset.z * offset.z).sqrt();
            let phase = offset.z.atan2(offset.x);
            Some(OrbitalMotion {
                body_kind: *body_kind,
                center_kind: *center_kind,
                radius,
                y_offset: offset.y,
                phase,
                initial_phase: phase,
                angular_speed: *angular_speed,
            })
        })
        .collect()
}

#[derive(Clone, Copy, Debug, Default)]
pub struct InputState {
    pub forward: bool,
    pub back: bool,
    pub left: bool,
    pub right: bool,
    pub pitch_up: bool,
    pub pitch_down: bool,
    /// Hold Shift while thrusting to enable the regular boost.
    pub boost: bool,
    /// Hold B together with Shift and W to engage the 1000-speed superboost.
    pub superboost: bool,
    pub interact_pressed: bool,
    pub wormhole_pressed: bool,
    pub takeoff_pressed: bool,
    pub screenshot_pressed: bool,
}

#[derive(Clone, Debug)]
pub struct HudState {
    pub title: String,
    pub body: String,
    pub phase: String,
    pub speed: f32,
    pub distance: f32,
    pub target: String,
    pub prompt: String,
    pub warning: String,
    pub scan_progress: f32,
}

#[derive(Clone, Debug)]
pub struct Game {
    pub bodies: Vec<SpaceBody>,
    orbits: Vec<OrbitalMotion>,
    pub position: Vec3,
    pub velocity: Vec3,
    pub yaw: f32,
    pub pitch: f32,
    pub speed: f32,
    /// Exposed to the renderer so boost visuals remain separate from simulation.
    pub boost_active: bool,
    pub superboost_active: bool,
    pub phase: GamePhase,
    pub crossed_wormhole: bool,
    pub landed_body: Option<usize>,
    pub destroyed: bool,
    pub transition_timer: f32,
    pub clock: f32,
    pub capture_notice: f32,
}

impl Game {
    pub fn new() -> Self {
        let bodies = journey_bodies();
        let orbits = build_orbits(&bodies);
        Self {
            bodies,
            orbits,
            // Start in the clear corridor between Earth and Venus, facing Earth.
            position: vec3(0.0, 80.0, 4_000.0),
            velocity: vec3(0.0, 0.0, -46.0),
            yaw: 0.0,
            pitch: -0.03,
            speed: 58.0,
            boost_active: false,
            superboost_active: false,
            phase: GamePhase::Launch,
            crossed_wormhole: false,
            landed_body: None,
            destroyed: false,
            transition_timer: 0.0,
            clock: 0.0,
            capture_notice: 0.0,
        }
    }

    pub fn forward(&self) -> Vec3 {
        let cos_pitch = self.pitch.cos();
        normalize(vec3(
            -self.yaw.sin() * cos_pitch,
            self.pitch.sin(),
            -self.yaw.cos() * cos_pitch,
        ))
    }

    pub fn right(&self) -> Vec3 {
        normalize(vec3(self.yaw.cos(), 0.0, -self.yaw.sin()))
    }

    pub fn up(&self) -> Vec3 {
        normalize(crate::math::cross(self.right(), self.forward()))
    }

    pub fn update(&mut self, dt: f32, input: InputState) {
        let dt = dt.clamp(0.0, 0.05);
        self.clock += dt;
        self.update_orbits(dt);
        self.capture_notice = (self.capture_notice - dt).max(0.0);
        let superboost_requested = input.boost && input.superboost && input.forward;
        self.boost_active = input.boost && input.forward;
        self.superboost_active = superboost_requested;

        if input.screenshot_pressed {
            self.capture_notice = 2.5;
        }

        if self.destroyed {
            self.boost_active = false;
            self.superboost_active = false;
            self.phase = GamePhase::Destroyed;
            self.speed = 0.0;
            self.velocity = vec3(0.0, 0.0, 0.0);
            if input.takeoff_pressed {
                self.restart();
            }
            return;
        }

        if let Some(body_index) = self.landed_body {
            self.boost_active = false;
            self.superboost_active = false;
            self.phase = GamePhase::Landed;
            if input.takeoff_pressed {
                let body = &self.bodies[body_index];
                let direction = normalize(self.position - body.position);
                self.position = body.position + direction * (body.radius + 95.0);
                self.velocity = direction * 72.0;
                self.speed = 72.0;
                self.boost_active = false;
                self.superboost_active = false;
                self.landed_body = None;
                self.phase = GamePhase::Launch;
            }
            return;
        }

        if self.phase == GamePhase::Transition {
            self.boost_active = false;
            self.superboost_active = false;
            self.transition_timer += dt;
            self.speed = damp(self.speed, 360.0, 3.0, dt);
            self.position += vec3(0.0, 0.0, -1.0) * (self.speed * dt);
            self.yaw += dt * 1.2;
            if self.transition_timer > 2.35 {
                self.position = wormhole_exit();
                self.velocity = vec3(16.0, 2.0, -92.0);
                self.speed = 92.0;
                self.transition_timer = 0.0;
                self.phase = GamePhase::Arrival;
                self.crossed_wormhole = true;
            }
            return;
        }

        let yaw_input = (input.left as i32 - input.right as i32) as f32 * 1.35;
        let pitch_input = (input.pitch_up as i32 - input.pitch_down as i32) as f32 * 1.05;
        self.yaw += yaw_input * dt;
        self.pitch = clamp(self.pitch + pitch_input * dt, -1.25, 1.25);

        let forward = self.forward();
        let right = self.right();
        let up = self.up();

        let target_speed = if input.back {
            (self.speed - 140.0 * dt).max(8.0)
        } else if input.forward {
            if superboost_requested {
                1_000.0
            } else if input.boost {
                390.0
            } else {
                215.0
            }
        } else {
            (self.speed * 0.996).max(32.0)
        };
        self.speed = damp(
            self.speed,
            target_speed,
            if superboost_requested { 3.2 } else if input.forward || input.back { 2.4 } else { 0.45 },
            dt,
        );

        let mut desired_velocity = forward * self.speed;
        desired_velocity += right * ((input.right as i32 - input.left as i32) as f32 * 7.0);
        desired_velocity += up * ((input.pitch_up as i32 - input.pitch_down as i32) as f32 * 5.0);
        let alpha = 1.0 - (-dt * 1.8).exp();
        self.velocity += (desired_velocity - self.velocity) * alpha;
        let configured_limit = if superboost_requested { 1_000.0 } else if input.boost { 420.0 } else { 260.0 };
        // When superboost is released, lower the cap alongside the damped
        // scalar speed instead of snapping the ship immediately down to 420/260.
        let maximum_velocity = configured_limit.max(self.speed.min(1_000.0));
        let velocity_length = length(self.velocity);
        if velocity_length > maximum_velocity {
            self.velocity = normalize(self.velocity) * maximum_velocity;
        }
        self.position += self.velocity * dt;

        if self.crossed_wormhole {
            let to_black_hole = gargantua_position() - self.position;
            let center_distance = length(to_black_hole);
            let kill_radius = GARGANTUA_RADIUS * 1.08;
            let gravity_radius = GARGANTUA_RADIUS * 3.25;
            if center_distance < kill_radius {
                self.destroyed = true;
                self.phase = GamePhase::Destroyed;
                return;
            } else if center_distance < gravity_radius {
                let pull = 1.0 - smoothstep(kill_radius, gravity_radius, center_distance);
                self.velocity += normalize(to_black_hole) * (pull * 90.0 * dt);
                self.speed = self.speed.max(length(self.velocity));
            }
        }

        // Prevent a direct collision with the Sun, while allowing a close fly-by.
        if let Some(sun) = self.bodies.iter().find(|body| body.kind == PlanetKind::Sun) {
            let from_sun = self.position - sun.position;
            let minimum_distance = sun.radius + 900.0;
            if length(from_sun) < minimum_distance {
                let away = if length(from_sun) > 0.001 { normalize(from_sun) } else { vec3(0.0, 0.0, 1.0) };
                self.position = sun.position + away * minimum_distance;
                self.velocity += away * (80.0 * dt);
                self.speed = self.speed.min(118.0);
            }
        }

        if !self.crossed_wormhole {
            if let Some(wormhole) = self.bodies.iter().find(|body| body.kind == PlanetKind::Wormhole) {
                let surface_distance = (distance(wormhole.position, self.position) - wormhole.radius).max(0.0);
                if input.wormhole_pressed && surface_distance < 380.0 {
                    self.phase = GamePhase::Transition;
                    self.transition_timer = 0.0;
                    return;
                }
            }
        }

        let nearest_landing = self.nearest_landable();
        if input.interact_pressed {
            if let Some((body_index, surface_distance)) = nearest_landing {
                if surface_distance < 220.0 {
                    let body = &self.bodies[body_index];
                    let outward = normalize(self.position - body.position);
                    self.position = body.position + outward * (body.radius + 18.0);
                    self.speed = 0.0;
                    self.velocity = vec3(0.0, 0.0, 0.0);
                    self.landed_body = Some(body_index);
                    self.phase = GamePhase::Landed;
                    return;
                }
            }
        }

        self.phase = if self.nearest_visible_body().map(|(_, d)| d < 420.0).unwrap_or(false) {
            GamePhase::Flyby
        } else if self.crossed_wormhole && self.position.z < gargantua_position().z - 25_000.0 {
            GamePhase::Completed
        } else if self.crossed_wormhole && distance(self.position, gargantua_position()) > 18_000.0 {
            GamePhase::Arrival
        } else if self.position.z > -120.0 && !self.crossed_wormhole {
            GamePhase::Launch
        } else {
            GamePhase::Cruise
        };
    }

    /// Advance all orbital bodies. The positions are updated before flight
    /// logic so visibility, landing distances, the HUD and the minimap all use
    /// the same moving coordinates. A landed ship is carried along with its
    /// world instead of being left behind while the planet orbits.
    fn update_orbits(&mut self, dt: f32) {
        let attached_before = self.landed_body.map(|index| self.bodies[index].position);

        for orbit in &mut self.orbits {
            orbit.phase = (orbit.phase + orbit.angular_speed * dt).rem_euclid(std::f32::consts::TAU);
            let Some(center_position) = self.bodies.iter()
                .find(|body| body.kind == orbit.center_kind)
                .map(|body| body.position) else {
                    continue;
                };
            let (sin_phase, cos_phase) = orbit.phase.sin_cos();
            let position = center_position + vec3(
                orbit.radius * cos_phase,
                orbit.y_offset,
                orbit.radius * sin_phase,
            );
            if let Some(body) = self.bodies.iter_mut().find(|body| body.kind == orbit.body_kind) {
                body.position = position;
            }
        }

        // The wormhole is a companion landmark, not a ninth planet: keep its
        // local offset fixed so it remains visibly beside Saturn throughout the orbit.
        if let Some(saturn_position) = self.bodies.iter()
            .find(|body| body.kind == PlanetKind::Saturn)
            .map(|body| body.position)
        {
            if let Some(wormhole) = self.bodies.iter_mut()
                .find(|body| body.kind == PlanetKind::Wormhole)
            {
                wormhole.position = saturn_position + wormhole_saturn_offset();
            }
        }

        if let (Some(index), Some(previous_center)) = (self.landed_body, attached_before) {
            let current_center = self.bodies[index].position;
            self.position += current_center - previous_center;
        }
    }

    pub fn restart(&mut self) {
        // Restart the orbital clock as well as the ship, returning the planets
        // to their authored starting positions and phases.
        for orbit in &mut self.orbits {
            orbit.phase = orbit.initial_phase;
        }
        self.update_orbits(0.0);
        self.position = vec3(0.0, 80.0, 4_000.0);
        self.velocity = vec3(0.0, 0.0, -46.0);
        self.yaw = 0.0;
        self.pitch = -0.03;
        self.speed = 58.0;
        self.boost_active = false;
        self.superboost_active = false;
        self.phase = GamePhase::Launch;
        self.crossed_wormhole = false;
        self.landed_body = None;
        self.destroyed = false;
        self.transition_timer = 0.0;
    }

    pub fn body_is_visible(&self, body: &SpaceBody) -> bool {
        let in_solar_system = matches!(
            body.kind,
            PlanetKind::Mercury | PlanetKind::Venus | PlanetKind::Earth | PlanetKind::Sun |
            PlanetKind::Moon | PlanetKind::Mars | PlanetKind::AsteroidBelt | PlanetKind::Jupiter |
            PlanetKind::Saturn | PlanetKind::Uranus | PlanetKind::Neptune | PlanetKind::Wormhole
        );
        let in_gargantua_system = matches!(
            body.kind,
            PlanetKind::Docking | PlanetKind::Gargantua | PlanetKind::MillerWater |
            PlanetKind::MannIce | PlanetKind::EdmundHabitable
        );
        if self.crossed_wormhole != in_gargantua_system {
            return false;
        }
        if body.kind == PlanetKind::Earth || body.kind == PlanetKind::Sun {
            return true;
        }
        if !in_solar_system && !in_gargantua_system {
            return false;
        }
        let surface_distance = (distance(body.position, self.position) - body.radius).max(0.0);
        surface_distance < body.reveal_distance
    }

    pub fn nearest_visible_body(&self) -> Option<(usize, f32)> {
        self.bodies
            .iter()
            .enumerate()
            .filter(|(_, body)| self.body_is_visible(body))
            .map(|(index, body)| (index, (distance(body.position, self.position) - body.radius).max(0.0)))
            .min_by(|a, b| a.1.total_cmp(&b.1))
    }

    pub fn nearest_landable(&self) -> Option<(usize, f32)> {
        self.bodies
            .iter()
            .enumerate()
            .filter(|(_, body)| body.landable && self.body_is_visible(body))
            .map(|(index, body)| (index, (distance(body.position, self.position) - body.radius).max(0.0)))
            .min_by(|a, b| a.1.total_cmp(&b.1))
    }

    pub fn camera(&self) -> (Vec3, Vec3) {
        if self.destroyed {
            let eye = self.position + vec3(18.0, 12.0, 26.0);
            return (eye, gargantua_position());
        }
        if let Some(body_index) = self.landed_body {
            let _body = &self.bodies[body_index];
            let eye = self.position + vec3(0.0, 7.5, 18.0);
            let target = self.position + vec3(0.0, 2.6, -16.0);
            return (eye, target);
        }
        let direction = if length(self.velocity) > 2.0 {
            normalize(self.velocity)
        } else {
            self.forward()
        };
        let camera_right = normalize(crate::math::cross(direction, vec3(0.0, 1.0, 0.0)));
        let eye = self.position - direction * 28.0 + vec3(0.0, 10.0, 0.0) + camera_right * 3.0;
        let target = self.position + direction * 22.0;
        (eye, target)
    }

    pub fn hud(&self) -> HudState {
        if self.destroyed {
            return HudState {
                title: "GARGANTUA COLLISION".to_string(),
                body: "The ship was torn apart by the event horizon.".to_string(),
                phase: GamePhase::Destroyed.label().to_string(),
                speed: 0.0,
                distance: distance(self.position, gargantua_position()),
                target: "GARGANTUA".to_string(),
                prompt: "PRESS R TO RESTART NEAR EARTH".to_string(),
                warning: "CRITICAL".to_string(),
                scan_progress: 0.0,
            };
        }

        if let Some(body_index) = self.landed_body {
            let body = &self.bodies[body_index];
            return HudState {
                title: format!("SURFACE: {}", body.label),
                body: landing_description(body.kind).to_string(),
                phase: GamePhase::Landed.label().to_string(),
                speed: 0.0,
                distance: 0.0,
                target: body.label.to_string(),
                prompt: "PRESS R TO TAKE OFF".to_string(),
                warning: String::new(),
                scan_progress: 0.0,
            };
        }

        let (target_name, target_distance, target_description) =
            if let Some((index, distance)) = self.nearest_visible_body() {
                let body = &self.bodies[index];
                (body.label.to_string(), distance, body.description.to_string())
            } else {
                ("DEEP SPACE".to_string(), 0.0, "No nearby navigation beacon.".to_string())
            };

        let wormhole_is_close = self.bodies.iter()
            .find(|body| body.kind == PlanetKind::Wormhole)
            .map(|body| (distance(body.position, self.position) - body.radius).max(0.0) < 380.0)
            .unwrap_or(false);
        let prompt = if self.phase == GamePhase::Transition {
            "WORMHOLE TRANSIT - HOLD STEADY".to_string()
        } else if !self.crossed_wormhole && wormhole_is_close {
            "PRESS SPACE TO CROSS THE WORMHOLE".to_string()
        } else if let Some((index, distance)) = self.nearest_landable() {
            if distance < 220.0 {
                format!("PRESS E TO LAND ON {}", self.bodies[index].label)
            } else {
                "FREE FLIGHT: STEER AND APPROACH A LANDABLE WORLD".to_string()
            }
        } else if target_name == "THE SUN" {
            "THE SUN IS A VISUAL LANDMARK, NOT A LANDING TARGET".to_string()
        } else if self.superboost_active {
            "SUPERBOOST ONLINE: 1000 MAX SPEED".to_string()
        } else if self.boost_active {
            "BOOST ACTIVE: HOLD W + SHIFT".to_string()
        } else {
            "FREE FLIGHT: W/S THRUST, SHIFT BOOST, SHIFT+B SUPERBOOST".to_string()
        };

        let warning = if self.crossed_wormhole {
            let distance_to_black_hole = distance(self.position, gargantua_position());
            if distance_to_black_hole < GARGANTUA_RADIUS * 3.25 { "GRAVITY WARNING".to_string() } else { String::new() }
        } else {
            String::new()
        };

        HudState {
            title: target_name.clone(),
            body: target_description,
            phase: self.phase.label().to_string(),
            speed: self.speed,
            distance: target_distance,
            target: target_name,
            prompt,
            warning,
            scan_progress: 0.0,
        }
    }
}

fn landing_description(kind: PlanetKind) -> &'static str {
    match kind {
        PlanetKind::Mercury => "Baked crater fields, long shadows, and a black sky.",
        PlanetKind::Venus => "Dense golden cloud cover and an intensely hot rocky surface.",
        PlanetKind::Earth => "Blue atmospheric horizon and distant cloud bands.",
        PlanetKind::Moon => "Airless grey regolith, sharp craters, and Earth on the horizon.",
        PlanetKind::Mars => "Amber sky, scattered basalt rocks, and a cold horizon.",
        PlanetKind::MillerWater => "A shallow reflective ocean with slow tidal walls.",
        PlanetKind::MannIce => "White-grey ice flats, frozen ridges, and drifting snow.",
        PlanetKind::EdmundHabitable => "Rock, moss-green vegetation, and warm light.",
        _ => "Surface contact established.",
    }
}

fn damp(current: f32, target: f32, lambda: f32, dt: f32) -> f32 {
    current + (target - current) * (1.0 - (-lambda * dt).exp())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ship_starts_facing_negative_z() {
        let game = Game::new();
        assert!(game.forward().z < -0.99);
    }

    #[test]
    fn earth_is_visible_at_start() {
        let game = Game::new();
        let earth = game.bodies.iter().find(|body| body.kind == PlanetKind::Earth).unwrap();
        assert!(game.body_is_visible(earth));
    }

    #[test]
    fn giant_earth_and_moon_have_clearance_between_surfaces() {
        let game = Game::new();
        let earth = game.bodies.iter().find(|body| body.kind == PlanetKind::Earth).unwrap();
        let moon = game.bodies.iter().find(|body| body.kind == PlanetKind::Moon).unwrap();
        assert!(earth.radius >= 2_600.0);
        assert!(moon.radius >= 800.0);
        assert!(distance(earth.position, moon.position) > earth.radius + moon.radius);
    }

    #[test]
    fn ship_starts_outside_the_enlarged_earth() {
        let game = Game::new();
        let earth = game.bodies.iter().find(|body| body.kind == PlanetKind::Earth).unwrap();
        assert!(distance(game.position, earth.position) > earth.radius);
    }

    #[test]
    fn orbital_bodies_move_slowly_but_visibly() {
        let mut game = Game::new();
        let before = game.bodies.iter().find(|body| body.kind == PlanetKind::Earth).unwrap().position;
        for _ in 0..120 {
            game.update(0.05, InputState::default());
        }
        let after = game.bodies.iter().find(|body| body.kind == PlanetKind::Earth).unwrap().position;
        // At 1 AU and a five-minute period, six simulated seconds move Earth
        // about 7.2 degrees along its 30,000-unit orbit.
        assert!(distance(before, after) > 3_700.0);
        assert!(distance(before, after) < 3_800.0);
    }

    #[test]
    fn orbital_radii_stay_constant_while_planets_move() {
        let mut game = Game::new();
        let sun = game.bodies.iter().find(|body| body.kind == PlanetKind::Sun).unwrap().position;
        let initial = game.bodies.iter().find(|body| body.kind == PlanetKind::Jupiter).unwrap().position;
        let initial_radius = distance(sun, initial);
        for _ in 0..240 {
            game.update(0.05, InputState::default());
        }
        let current = game.bodies.iter().find(|body| body.kind == PlanetKind::Jupiter).unwrap().position;
        let current_radius = distance(sun, current);
        assert!((initial_radius - current_radius).abs() < 1.0);
    }

    #[test]
    fn expanded_planets_have_clear_spacing() {
        let game = Game::new();
        let adjacent = [
            PlanetKind::Mercury, PlanetKind::Venus, PlanetKind::Earth, PlanetKind::Mars,
            PlanetKind::AsteroidBelt, PlanetKind::Jupiter, PlanetKind::Saturn,
            PlanetKind::Uranus, PlanetKind::Neptune,
        ];
        for pair in adjacent.windows(2) {
            let first = game.bodies.iter().find(|body| body.kind == pair[0]).unwrap();
            let second = game.bodies.iter().find(|body| body.kind == pair[1]).unwrap();
            assert!(distance(first.position, second.position) > first.radius + second.radius,
                "{} and {} overlap", first.label, second.label);
        }
    }

    #[test]
    fn starting_ship_is_clear_of_inner_planets() {
        let game = Game::new();
        for kind in [PlanetKind::Mercury, PlanetKind::Venus, PlanetKind::Earth, PlanetKind::Moon, PlanetKind::Sun] {
            let body = game.bodies.iter().find(|body| body.kind == kind).unwrap();
            assert!(distance(game.position, body.position) > body.radius, "ship starts inside {}", body.label);
        }
    }

    #[test]
    fn all_eight_solar_planets_are_present() {
        let game = Game::new();
        for kind in [
            PlanetKind::Mercury, PlanetKind::Venus, PlanetKind::Earth, PlanetKind::Mars,
            PlanetKind::Jupiter, PlanetKind::Saturn, PlanetKind::Uranus, PlanetKind::Neptune,
        ] {
            assert!(game.bodies.iter().any(|body| body.kind == kind), "missing {kind:?}");
        }
    }

    #[test]
    fn every_solar_planet_has_a_sun_orbit() {
        let game = Game::new();
        for kind in [
            PlanetKind::Mercury, PlanetKind::Venus, PlanetKind::Earth, PlanetKind::Mars,
            PlanetKind::Jupiter, PlanetKind::Saturn, PlanetKind::Uranus, PlanetKind::Neptune,
        ] {
            let orbit = game.orbits.iter().find(|orbit| orbit.body_kind == kind)
                .expect("every Solar System planet must move");
            assert_eq!(orbit.center_kind, PlanetKind::Sun);
            assert!(orbit.angular_speed > 0.0);
        }
    }

    #[test]
    fn earth_completes_one_orbit_in_five_minutes() {
        let mut game = Game::new();
        let initial = game.bodies.iter().find(|body| body.kind == PlanetKind::Earth).unwrap().position;
        let earth_orbit = game.orbits.iter().find(|orbit| orbit.body_kind == PlanetKind::Earth).unwrap();
        let period = std::f32::consts::TAU / earth_orbit.angular_speed;
        assert!((period - 300.0).abs() < 0.01);
        game.update_orbits(300.0);
        let after = game.bodies.iter().find(|body| body.kind == PlanetKind::Earth).unwrap().position;
        assert!(distance(initial, after) < 1.0);
    }

    #[test]
    fn planetary_periods_follow_kepler_ratios() {
        let game = Game::new();
        let period = |kind| {
            let orbit = game.orbits.iter().find(|orbit| orbit.body_kind == kind).unwrap();
            std::f32::consts::TAU / orbit.angular_speed
        };
        assert!(period(PlanetKind::Mercury) < period(PlanetKind::Venus));
        assert!(period(PlanetKind::Venus) < period(PlanetKind::Earth));
        assert!(period(PlanetKind::Earth) < period(PlanetKind::Mars));
        assert!(period(PlanetKind::Mars) < period(PlanetKind::Jupiter));
        assert!(period(PlanetKind::Jupiter) < period(PlanetKind::Saturn));
        assert!(period(PlanetKind::Saturn) < period(PlanetKind::Uranus));
        assert!(period(PlanetKind::Uranus) < period(PlanetKind::Neptune));
    }

    #[test]
    fn solar_orbital_distances_keep_approximate_au_ratios() {
        let game = Game::new();
        let sun = game.bodies.iter().find(|body| body.kind == PlanetKind::Sun).unwrap().position;
        for (kind, expected_au) in [
            (PlanetKind::Mercury, 0.387_f32), (PlanetKind::Venus, 0.723),
            (PlanetKind::Earth, 1.0), (PlanetKind::Mars, 1.524),
            (PlanetKind::Jupiter, 5.203), (PlanetKind::Saturn, 9.537),
            (PlanetKind::Uranus, 19.191), (PlanetKind::Neptune, 30.069),
        ] {
            let body = game.bodies.iter().find(|body| body.kind == kind).unwrap();
            let measured_au = distance(sun, body.position) / AU_SCALE;
            assert!((measured_au - expected_au).abs() < 0.02, "{kind:?}: {measured_au}");
        }
    }

    #[test]
    fn asteroid_belt_spans_a_full_annular_orbit() {
        assert!(ASTEROID_BELT_INNER_AU > 2.0);
        assert!(ASTEROID_BELT_OUTER_AU > ASTEROID_BELT_INNER_AU);
        let game = Game::new();
        let sun = game.bodies.iter().find(|body| body.kind == PlanetKind::Sun).unwrap().position;
        let belt = game.bodies.iter().find(|body| body.kind == PlanetKind::AsteroidBelt).unwrap();
        let radius_au = distance(sun, belt.position) / AU_SCALE;
        assert!((radius_au - 2.7).abs() < 0.01);
    }

    #[test]
    fn wormhole_remains_next_to_saturn_as_saturn_orbits() {
        let mut game = Game::new();
        let offset_before = {
            let saturn = game.bodies.iter().find(|body| body.kind == PlanetKind::Saturn).unwrap();
            let wormhole = game.bodies.iter().find(|body| body.kind == PlanetKind::Wormhole).unwrap();
            wormhole.position - saturn.position
        };
        assert!((length(offset_before) - (18_000.0_f32.powi(2) + 3_900.0_f32.powi(2)).sqrt()).abs() < 20.0);

        for _ in 0..240 {
            game.update(0.05, InputState::default());
        }

        let saturn = game.bodies.iter().find(|body| body.kind == PlanetKind::Saturn).unwrap();
        let wormhole = game.bodies.iter().find(|body| body.kind == PlanetKind::Wormhole).unwrap();
        let offset_after = wormhole.position - saturn.position;
        assert!(distance(offset_before, offset_after) < 1.0);
    }

    #[test]
    fn celestial_bodies_use_fifteen_times_base_scale() {
        let game = Game::new();
        assert_eq!(PLANET_SCALE, 15.0);
        let radius = |kind| game.bodies.iter().find(|body| body.kind == kind).unwrap().radius;
        assert_eq!(radius(PlanetKind::Earth), 180.0 * 15.0);
        assert_eq!(radius(PlanetKind::Sun), 300.0 * 15.0);
        assert_eq!(radius(PlanetKind::Wormhole), 38.0 * 15.0);
        assert_eq!(radius(PlanetKind::Gargantua), 185.0 * 15.0);
    }

    #[test]
    fn gargantua_planet_orbits_clear_the_central_model_and_disk_volume() {
        let game = Game::new();
        let miller = game.orbits.iter().find(|orbit| orbit.body_kind == PlanetKind::MillerWater).unwrap();
        let mann = game.orbits.iter().find(|orbit| orbit.body_kind == PlanetKind::MannIce).unwrap();
        let edmund = game.orbits.iter().find(|orbit| orbit.body_kind == PlanetKind::EdmundHabitable).unwrap();
        assert!(miller.radius >= GARGANTUA_RADIUS * 20.0);
        assert!(miller.radius < mann.radius && mann.radius < edmund.radius);
        assert!(miller.radius > 80_000.0);
        assert!(edmund.radius > 200_000.0);
    }

    #[test]
    fn wormhole_exit_is_outside_the_outer_gargantua_orbit() {
        let exit_distance = distance(wormhole_exit(), gargantua_position());
        assert!(exit_distance > GARGANTUA_EDMUND_ORBIT);
        assert!(exit_distance - GARGANTUA_EDMUND_ORBIT > 30_000.0);
    }

    #[test]
    fn saturn_wormhole_is_outside_the_enlarged_ring_system() {
        let game = Game::new();
        let saturn = game.bodies.iter().find(|body| body.kind == PlanetKind::Saturn).unwrap();
        let wormhole = game.bodies.iter().find(|body| body.kind == PlanetKind::Wormhole).unwrap();
        let center_gap = distance(saturn.position, wormhole.position);
        let conservative_combined_extent = saturn.radius * 2.5 + wormhole.radius * 3.0;
        assert!(center_gap > conservative_combined_extent);
    }

    #[test]
    fn inner_planets_and_sun_keep_surface_clearance() {
        let game = Game::new();
        let body = |kind| game.bodies.iter().find(|item| item.kind == kind).unwrap();
        for planet_kind in [PlanetKind::Mercury, PlanetKind::Venus] {
            let planet = body(planet_kind);
            assert!(distance(body(PlanetKind::Sun).position, planet.position)
                > body(PlanetKind::Sun).radius + planet.radius);
        }
    }

    #[test]
    fn superboost_reaches_but_never_exceeds_one_thousand() {
        let mut game = Game::new();
        let input = InputState {
            forward: true,
            boost: true,
            superboost: true,
            ..InputState::default()
        };
        for _ in 0..160 {
            game.update(0.05, input);
        }
        assert!(game.superboost_active);
        assert!(game.speed > 999.0, "speed was {}", game.speed);
        assert!(game.speed <= 1_000.0);
        assert!(length(game.velocity) <= 1_000.1);

        let speed_before_release = length(game.velocity);
        game.update(0.05, InputState::default());
        let speed_after_release = length(game.velocity);
        assert!(speed_after_release > speed_before_release * 0.90,
            "releasing superboost should decelerate smoothly, not snap: {speed_before_release} -> {speed_after_release}");
    }

    #[test]
    fn pressing_b_without_shift_does_not_enable_superboost() {
        let mut game = Game::new();
        let input = InputState {
            forward: true,
            boost: false,
            superboost: true,
            ..InputState::default()
        };
        game.update(0.05, input);
        assert!(!game.superboost_active);
        assert!(game.speed < 100.0);
    }

    #[test]
    fn restart_resets_wormhole_state() {
        let mut game = Game::new();
        game.crossed_wormhole = true;
        game.destroyed = true;
        game.restart();
        assert!(!game.crossed_wormhole);
        assert!(!game.destroyed);
        assert_eq!(game.phase, GamePhase::Launch);
    }
}
